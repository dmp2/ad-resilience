"""Old (preprocess/*, scan script) vs new (section_mapping) on the real AHRAv2 atlas and saved profiles."""
import json, sys
from pathlib import Path
import numpy as np
ROOT = Path("/cis/home/dpadova/Documents/git/ad-resilience")
for p in ("src", "src/config_setup", "src/preprocess", "src/scripts"):
    sys.path.insert(0, str(ROOT / p))
from config_setup.project_config import load_config, resolve_path
from config_setup.qnp_jobs import resolve_qnp_job
import scan_atlas_planes_for_qnp as OLD
import preprocess.qnp_stacking as OQS
import preprocess.qnp_stacking_xiv as OQX
import preprocess.anatomical_slab as OSL
from section_mapping import atlas as A, stacking as S
from section_mapping.alignment import Similarity2D

config = load_config(str(ROOT / "configs/project_config.yaml"))
job = resolve_qnp_job(config, "H20.33.034_MTG")
scan = job["atlas_scan"]
old = OLD.atlas_setup(config, scan)
new = A.load_atlas(resolve_path(config, scan["annotation_nifti"]), resolve_path(config, scan["terminology_csv"]),
                   white_matter_codes=scan["white_matter_codes"], drop_codes=scan["drop_codes"],
                   fine_regions=scan["fine_regions"], gray_regions=scan["anatomical_features"]["gray_regions"],
                   hemisphere=scan["hemisphere"])
for k in ("labels", "affine", "centroid"):
    assert np.array_equal(old[k], new[k]), k
for k in ("coarse", "fine", "anatomical"):
    assert list(old[k]) == list(new[k]) and all(np.array_equal(old[k][n], new[k][n]) for n in old[k]), k
assert old["region_extent_y"] == new["region_extent_y"] and old["names"] == new["names"]
print("load_atlas == atlas_setup")
prior = dict(scan["stacking"]["region_prior"])
for y in (-27.5, -24.5, -13.0, -62.25):
    for pr in (None, prior):
        a, b = OQS.plane_measure(old, scan, y, pr), A.plane_measure(new, scan, y, pr)
        assert all(np.array_equal(u, v) for u, v in zip(a, b)), ("plane", y)
    a, b = OQS.slab_measure(old, scan, y, 3.0, 0.5, prior), A.slab_measure(new, scan, y, 3.0, 0.5, prior)
    assert all(np.array_equal(u, v) for u, v in zip(a, b)), ("slab", y)
    a, b = OQX.atlas_plane(old, scan, y, 1.0), A.atlas_plane(new, scan, y, 1.0)
    for k in ("X", "nu", "nu_anat", "origin", "u", "v", "normal"):
        assert np.array_equal(a[k], b[k]), k
    assert np.array_equal(a["mtg"], b["anat"]) and a["plane_meta"] == {k: v for k, v in b["plane_meta"].items()}, "meta"
    for pitch, yaw in ((0, 0), (10, -5)):
        o1 = OLD.plane_geometry(old, pitch, yaw, y); o2 = A.plane_geometry(new, pitch, yaw, y)
        assert all(np.array_equal(u, v) for u, v in zip(o1, o2))
        p1 = OLD.plane_particles(old, scan, *o1[:3], 0.5, 2, "coarse"); p2 = A.plane_particles(new, scan, *o2[:3], 0.5, 2, "coarse")
        assert all(np.array_equal(u, v) for u, v in zip(p1, p2)), "plane_particles"
print("plane/slab/region-prior/atlas_plane measures identical at 4 depths")
rng = np.random.default_rng(0)
pts = rng.uniform(-30, 30, (3000, 2))
t = Similarity2D(127.0, 1.1, True, (3.0, -2.0))
regions = list(scan["fine_regions"]) + list(A.FINE_ORDER_TAIL)
for y in (-27.5, -13.0):
    o, u, v, _ = A.plane_geometry(new, 0, 0, y)
    assert OLD.landing_fractions(old, t, o, u, v, pts, regions) == A.landing_fractions(new, t, o, u, v, pts, regions)
    plane = A.atlas_plane(new, scan, y, 1.0)
    m = rng.uniform(0, 1, len(pts))
    assert OQX.landing(plane, old, t, pts, m, old["anatomical"]) == A.landing(plane, new, t, pts, m, new["anatomical"])
print("landing_fractions and landing identical")
cfg = scan["stacking"]["landmark_slab"]
lm_old = OSL.build_slab_prior(OSL.locate_landmark(old["labels"], old["affine"], cfg["landmark"], "left"), cfg)
lm_new = A.landmark_slab_prior(new, cfg, "left")
assert {k: lm_old[k] for k in lm_old} == {k: lm_new[k] for k in lm_old}
print("landmark:", lm_new["landmark"]["y_mm"], "interval", lm_new["search_interval"]["y_mm"], "candidates", len(lm_new["candidates"]))

# saved profiles: summarize_level reproduces saved profile_*.json summaries
for jobname in ("H20.33.034_MTG", "H20.33.043_MTG"):
    base = ROOT / f"results/registrations/qnp_{jobname}_stacking"
    for sub in ("", "landmark_slab", "region_prior__landmark_slab"):
        folder = base / sub
        prev = None
        for lv in ("h1.5", "h1.0", "500um"):
            if not (folder / f"profile_{lv}.json").exists():
                continue
            saved = json.loads((folder / f"profile_{lv}.json").read_text())
            rows = OLD._read_rows(folder / f"profile_{lv}.csv")
            for r in rows:
                r["flip"] = r["flip"] == "True" if isinstance(r["flip"], str) else r["flip"]
            inherit = None
            if prev is None and sub:
                wide = base / f"profile_{lv}.json"
                inherit = ((set(json.loads(wide.read_text()).get("flat_anchors", [])), f"inherited from the unconstrained first level ({wide.name})")
                           if wide.exists() else (set(), "x"))
            got = S.summarize_level(lv, rows, prev, step_mm=0.5, delta_top=20, inherit_flat=inherit)
            for k in ("delta", "flat_anchors", "union_window_y", "window_shrink_vs_previous_mm", "stop_escalating"):
                if k in saved:
                    assert json.loads(json.dumps(got.get(k))) == saved[k], (jobname, sub, lv, k, got.get(k), saved[k])
            for a, w in saved["anchors"].items():
                g = json.loads(json.dumps(got["anchors"][a]))
                for k in ("best_y", "best_score", "window_y", "width_mm", "flat", "flat_rule", "contiguous"):
                    assert g[k] == w[k], (jobname, sub, lv, a, k, g[k], w[k])
                bt = {k: (str(v) if k == "flip" else v) for k, v in g["best_transform"].items()}
                assert all(str(bt[k]) == str(w["best_transform"][k]) for k in bt), (a, bt, w["best_transform"])
            if "windows_at_prior_bound" in saved:
                assert S.windows_at_bound(saved, saved["landmark_slab_bound_y_mm"], 0.5) == saved["windows_at_prior_bound"]
            prev = saved
            print(f"summarize_level reproduces {jobname}/{sub or '.'}/profile_{lv}.json "
                  f"windows { {a: w['window_y'] for a, w in saved['anchors'].items()} }")
