"""Compare regenerated stage outputs (scratch copy) with the saved originals."""
import json, sys
from pathlib import Path
ROOT = Path("/cis/home/dpadova/Documents/git/ad-resilience/results/registrations")
E = Path("/cis/home/dpadova/tmp/consolidation/e2e")

def diff(a, b, path="", tol=1e-6, out=None):
    out = [] if out is None else out
    if isinstance(a, dict) and isinstance(b, dict):
        for k in sorted(set(a) | set(b)):
            if k not in a or k not in b:
                out.append(f"{path}/{k}: only in {'saved' if k in a else 'new'}")
            else:
                diff(a[k], b[k], f"{path}/{k}", tol, out)
    elif isinstance(a, list) and isinstance(b, list) and len(a) == len(b):
        for i, (x, y) in enumerate(zip(a, b)):
            diff(x, y, f"{path}[{i}]", tol, out)
    elif isinstance(a, (int, float)) and isinstance(b, (int, float)) and not isinstance(a, bool):
        if abs(a - b) > tol * max(1.0, abs(a)):
            out.append(f"{path}: {a} -> {b}")
    elif a != b:
        out.append(f"{path}: {str(a)[:80]} -> {str(b)[:80]}")
    return out

for name in sys.argv[1:]:
    for job in ("H20.33.034_MTG", "H20.33.043_MTG"):
        for sub in ("", "landmark_slab", "region_prior", "region_prior__landmark_slab"):
            saved = ROOT / f"qnp_{job}_stacking" / sub / name
            new = E / f"qnp_{job}_stacking" / sub / name
            if not saved.exists() or not new.exists():
                continue
            if saved.stat().st_mtime_ns == new.stat().st_mtime_ns and saved.read_bytes() == new.read_bytes():
                pass
            d = diff(json.loads(saved.read_text()), json.loads(new.read_text()))
            print(f"{job}/{sub or '.'}/{name}: {'IDENTICAL (tol 1e-6)' if not d else str(len(d)) + ' differences'}")
            for line in d[:12]:
                print("   ", line)
