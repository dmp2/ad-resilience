# Section mapping before the 2026-11-24 consolidation

The modules, scripts, tests, skill (with evidence.md) and config as they were just before
`src/section_mapping` replaced them. Kept as provenance for the saved runs under
`results/registrations/qnp_*_stacking*`, which this code produced. Not importable from the
repository; extract it elsewhere and put `src` first on PYTHONPATH (over a copy of the current
`src`, so that the unchanged helpers such as `particle_utils` resolve).

`equivalence_checks/` holds the one-off scripts that compared old and new code:
- `equivalence_atlas.py`: atlas, plane, slab, landing and landmark functions on AHRAv2, bitwise;
  `summarize_level` against every saved profile.
- `compare_outputs.py`: regenerated stage outputs against the saved JSON.

The durable form of these checks is `src/tests/test_mapping_regression.py`.
