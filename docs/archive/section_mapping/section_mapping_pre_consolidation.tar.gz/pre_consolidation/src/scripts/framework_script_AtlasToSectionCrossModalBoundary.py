#!/usr/bin/env python3
"""Atlas plane -> MERFISH section registration with xIV-LDDMM and support censoring.

Scientific role
===============
The source is a provisional 2-D plane cut from a 3-D atlas label; the target is a
binned MERFISH section.  The two measures have different feature spaces (atlas
regions vs cell classes) and different supports (the atlas plane covers much more
tissue than the section).  The model therefore follows
``vendor/xIV-LDDMM-Particle/examples/old/framework_script_densSupport_halfBrainBarSeqToAllen.py``:

    L = gamma*H(p, q) + D_var(phi . S restricted by support, T; pi_ST)
        + gamma*0.1/log(F) * KL(pi_ST) + gamma*R(lambda),

with ``xmodmap.model.CrossModalityBoundary``.  ``LossVarifoldNormBoundary_Partial``
multiplies each deformed source particle by a support weight computed from the local
density of target particles (min-max normalized over the current source particles).
In 2-D, xmodmap's slab normals are zero, so this density weight is the whole support
model and ``lambda`` has no effect; ``lambda`` is therefore held fixed.

Deformation stages
------------------
H is chosen by name (``xmodmap.deformation.TRANSFORMS``): ``rigid``, ``affine``
(rotation + translation + one scale, i.e. a similarity in 2-D), ``diffeo``,
``rigid+diffeo`` or ``affine+diffeo`` (the default, identical to the pre-2026-11
Hamiltonian).  ``model.stages`` lists ``{transform, steps}`` fits run in order: each
starts from the previous stage's deformed source and learned ``pi_ST``, with fresh
momenta, the same data loss and the same support.  The forward map is the composition
of the stage flows; target points are pulled back through them in reverse order.
Without ``model.stages`` there is one stage, ``model.transform`` for ``model.steps``.

Anatomical supervision (optional; off by default)
-------------------------------------------------
``record.anatomical_supervision`` adds a second image-varifold term on the *same* deformed
atlas (one flow, shared momenta, gradients summed; ``xmodmap.model.CrossModalityBoundaryMultiTerm``):

    E = gamma*H + lambda_struct * D_var(...as above...) + KL + R + lambda_anat * D_anat,
    D_anat = 1/2 | A . (phi . mu_S^MTG) - mu_T^annot |^2_W        (no pi: a fixed 1-to-1 map)

* mu_S^MTG: the atlas MTG gray-matter channel, i.e. the fixed ``mtg_gm`` projection of
  ``nu_Anat`` carried on the structural source particles as a mass fraction of their weight.
* mu_T^annot: the positively HALO-annotated tissue area per target particle (``nu_Anat``'s
  counterpart on the target, ``nu_Annot``; ``preprocess/qnp_annotation_features.py``).
  Unannotated tissue has mass 0 here and is *unknown*, not negative: it stays in the
  structural term only.
* A: the annotation mask, a fixed Gaussian-smoothed indicator of the annotated tissue
  (``xmodmap.distance.SmoothedIndicatorField``, width ``annotation_sigma_mm``).  Atlas MTG
  outside it is unobserved, so it is neither matched nor penalised.  A is distinct from the
  structural term's tissue support (``LossVarifoldNormBoundary_Partial.densityWeight``),
  which is untouched and not applied to D_anat.
* ``censoring`` (default ``annotation``, the above).  ``none`` drops A: the ordinary varifold
  distance |phi.mu_S^MTG - mu_T^annot|^2.  The annotation still defines the target measure
  (unannotated tissue carries no anatomical mass), but atlas MTG away from it now costs, so a
  disjoint start keeps a gradient from the multiscale kernels.  Opt-in until validated.
* Kernels: ``sigma_var_mm`` defaults to the model's; ``annotation_sigma_mm`` to
  ``dens_sigma_mm``.  Normalisation ``target`` (default) divides each scale by the
  annotated target's own norm, so D_anat = sum 0.6/sigma at a complete miss whatever the
  start; ``initial`` is the structural term's per-start normalisation.

``weight`` (lambda_anat) defaults to 0: then no term is built, and the model, objective
and results are exactly the original.  A section whose target archive records no
annotation also runs the original objective.  Atlas MTG disjoint from the annotation gives
no gradient (a plateau at the complete-miss value), so the term ranks placements but does
not pull a fit across from a disjoint start.

Structural feature map
----------------------
``record.structural_feature_map`` is ``learned`` (default: pi_ST is optimised with its KL
regulariser, as for genuinely different feature spaces) or ``identity``: source and target
features are the same classes (QNP and atlas gray/white), so pi_ST is fixed to I_F as in
``xmodmap.model.SingleModality``.  Nothing else changes: the data term, its tissue support,
the kernels and the flow are the same; pi is simply not a variable and its KL is not evaluated.

What this script is *not*
-------------------------
With one atlas feature, ``pi_ST`` is a single-region aggregate, not a regional feature
law.  ``source_feature_projection`` (unset = the archive's ``feature_key``, gray/white for
QNP) swaps in a fixed projection of the one-hot anatomical atlas channels (``gmwm``,
``mtg_gm``, ``anatomical``; ``preprocess/atlas_features.py``) without changing the
objective; ``gmwm`` reproduces the gray/white source exactly.  The atlas plane is a hand-chosen hypothesis, so a good fit does not locate the
section in MNI space.  Level 2 (geometric plausibility) is never certified here; the
outputs support a manual assessment.

Stages
------
``support-check``  evaluate the density support and data-loss gradients at the
                   reference start, after a 0.5 mm shift, and after a small
                   deformation; fail loudly on non-finite or constant weights.
``single``         fit one start (``--init``, default ``reference_initialization``).
``multistart``     fit every configured start and rank them with a fixed-scale
                   score, because xmodmap's training loss normalizes each start
                   differently.
``qc``             (re)write ``registration_qc.png`` / ``.json`` for finished fits (``--init``,
                   default: every finished start) without refitting.  Rows: gray/white
                   features; anatomical channels and the HALO annotation; what each term
                   counts (tissue support, annotation mask) and where annotated tissue lands;
                   pi_ST, transform, losses, masses.  Fits write it themselves at the end.

Initialization ids ``rDDD_fK``: the centered target is reflected (``y -> -y``) when
K = 1, then rotated by DDD degrees.  This is discrete preprocessing, not part of the
diffeomorphic flow, and is recorded in ``transform_chain.json``.

Usage::

    PYTHONPATH=src:src/config_setup python src/scripts/framework_script_AtlasToSectionCrossModalBoundary.py \
        --config configs/project_config.yaml \
        --registration ahrav2_mtg_plane_to_strip_1194111462 --stage support-check
"""

from __future__ import annotations

import argparse
import csv
import json
import random
import shutil
from pathlib import Path
from typing import Any

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
from scipy.spatial import ConvexHull

from config_setup.project_config import load_config, resolve_path, write_resolved_config
from preprocess.particle_utils import load_particle_archive, varifold_score_mm
from preprocess.section_alignment import FootprintScorer
from preprocess.xmodmap_compat import (
    instantiate_model,
    load_xmodmap,
    save_atlas_outputs,
    write_particle_vtk_xyz,
    write_vtk_xyz,
)
from scripts.view_xiv_trajectory import load_trajectory, render_registration, write_trajectory
from scripts.framework_script_HighFieldToLowFieldIndividual import (
    _registration_record,
    _save_original,
    _save_target,
    _torch_dtype,
)

DEPTH_BINS_MM = [(0.0, 1.0), (1.0, 2.0), (2.0, 3.0), (3.0, 5.0)]
CLASS_COLORS = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#6250d6"]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--config", required=True, help="Project YAML configuration.")
    parser.add_argument("--registration", required=True, help="Named record under registrations.")
    parser.add_argument("--stage", required=True, choices=["support-check", "single", "multistart", "qc"])
    parser.add_argument("--init", help="Initialization id for --stage single (default: reference).")
    parser.add_argument("--steps", type=int, help="Override the steps of every stage (short feasibility runs).")
    parser.add_argument("--overwrite", action="store_true", help="Replace a completed initialization.")
    return parser.parse_args()


# --------------------------------------------------------------------------------------
# Inputs and the discrete initial transform
# --------------------------------------------------------------------------------------

def initial_transform(init_id: str) -> np.ndarray:
    """2x2 matrix M for ``rDDD_fK``: reflect y when K = 1, then rotate by DDD degrees."""

    rotation, reflection = init_id.split("_")
    angle = np.deg2rad(float(rotation[1:]))
    R = np.array([[np.cos(angle), -np.sin(angle)], [np.sin(angle), np.cos(angle)]])
    F = np.diag([1.0, -1.0]) if reflection == "f1" else np.eye(2)
    return R @ F


def project_source_features(archive, projection: str) -> tuple[np.ndarray, list[str]]:
    """Source masses as a fixed projection of the archive's one-hot anatomical features.

    ``record.source_feature_projection`` (unset by default) selects ``gmwm`` (must equal the
    archive's ``nu_Sub`` exactly, else this refuses), ``mtg_gm`` or ``anatomical``; see
    ``preprocess/atlas_features.py``.  The projection is fixed; any source/target feature
    mismatch is left to ``pi_ST`` exactly as for the gray/white source.
    """

    from preprocess.atlas_features import project, projection_matrix

    if "nu_Anat" not in archive.files:
        raise KeyError("source_feature_projection needs a source archive with nu_Anat; re-run "
                       "scan_atlas_planes_for_qnp.py --stage export")
    nu_anat = np.asarray(archive["nu_Anat"])
    names, M = projection_matrix(projection, [str(v) for v in archive["anatomical_feature_names"]])
    nu = project(nu_anat, M)
    if projection == "gmwm" and not np.array_equal(nu, np.asarray(archive["nu_Sub"])):
        raise ValueError("gmwm projection of nu_Anat differs from nu_Sub; the archive is inconsistent")
    return nu, list(names)


ANATOMICAL_DEFAULTS = {"weight": 0.0, "structural_weight": 1.0, "source_projection": "mtg_gm",
                       "target_key": "nu_Annot", "normalization": "target", "censoring": "annotation"}
# censoring "annotation": the atlas MTG measure is multiplied by the smoothed annotation mask A
# (positive-only; zero gradient when atlas MTG and annotation are disjoint).  "none": the ordinary
# varifold distance |phi.mu_S^MTG - mu_T^annot|^2 (xmodmap's LossVarifoldNorm); unannotated target
# tissue still carries no anatomical mass, but atlas MTG away from the annotation now costs.
ANATOMICAL_CENSORING = ("annotation", "none")
# Kernel widths are not given new defaults: they inherit the structural term's.
ANATOMICAL_INHERITED = {"sigma_var_mm": "sigma_var_mm", "annotation_sigma_mm": "dens_sigma_mm"}


def anatomical_settings(record: dict) -> dict[str, Any]:
    """``record.anatomical_supervision`` with defaults (weight 0 = the original objective)."""

    block = dict(record.get("anatomical_supervision") or {})
    unknown = set(block) - set(ANATOMICAL_DEFAULTS) - set(ANATOMICAL_INHERITED)
    if unknown:
        raise ValueError(f"Unknown anatomical_supervision keys {sorted(unknown)}; expected "
                         f"{sorted(set(ANATOMICAL_DEFAULTS) | set(ANATOMICAL_INHERITED))}.")
    settings = {**ANATOMICAL_DEFAULTS, **block}
    model = record.get("model") or {}
    for key, model_key in ANATOMICAL_INHERITED.items():
        settings.setdefault(key, model.get(model_key))
        settings[f"{key}_from"] = "anatomical_supervision" if key in block else f"model.{model_key}"
    settings["weight"], settings["structural_weight"] = float(settings["weight"]), float(settings["structural_weight"])
    if settings["sigma_var_mm"] is not None:
        settings["sigma_var_mm"] = [float(v) for v in settings["sigma_var_mm"]]
    if settings["annotation_sigma_mm"] is not None:
        settings["annotation_sigma_mm"] = float(settings["annotation_sigma_mm"])
    if settings["normalization"] not in ("target", "initial"):
        raise ValueError("anatomical_supervision.normalization must be 'target' or 'initial'.")
    if settings["censoring"] not in ANATOMICAL_CENSORING:
        raise ValueError(f"anatomical_supervision.censoring must be one of {ANATOMICAL_CENSORING}.")
    if settings["weight"] < 0 or settings["structural_weight"] < 0:
        raise ValueError("anatomical_supervision weights must be non-negative.")
    return settings


def load_anatomical(source_archive, target_archive, target_meta: dict, settings: dict, keep: np.ndarray,
                    nu_S: np.ndarray, nu_T: np.ndarray) -> tuple[dict[str, Any] | None, str]:
    """Masses of the anatomical term: atlas MTG gray (fixed projection) and annotated target tissue.

    Returns ``(None, reason)`` when the term cannot apply: the section has no annotation, or the
    archives predate the anatomical features.  ``keep`` is the structural source particle mask.
    """

    key = settings["target_key"]
    status = (target_meta.get("annotation_supervision") or {}).get("status")
    if key not in target_archive.files:
        if status == "no_annotation":
            return None, "section has no HALO annotation"
        return None, f"target archive has no {key!r} (re-export with export.annotation_maps)"
    if "nu_Anat" not in source_archive.files:
        return None, "source archive has no nu_Anat (re-export)"
    nu_T_anat = np.asarray(target_archive[key], dtype=np.float64)
    if nu_T_anat.shape != (len(nu_T), 1):
        raise ValueError(f"{key} must be (N_target, 1) (all annotated layers combined); got {nu_T_anat.shape}.")
    if not np.all(nu_T_anat <= nu_T.sum(axis=1, keepdims=True) * (1 + 1e-5) + 1e-9) or np.any(nu_T_anat < 0):
        raise ValueError(f"{key} must lie between 0 and each target particle's tissue mass.")
    if not np.any(nu_T_anat > 0):
        return None, "section has no HALO annotation"
    nu_S_anat, source_names = project_source_features(source_archive, settings["source_projection"])
    nu_S_anat = nu_S_anat[keep].astype(np.float64)
    if nu_S_anat.shape[1] != 1:
        raise ValueError("anatomical source_projection must give one channel (e.g. mtg_gm).")
    if not np.all(nu_S_anat <= nu_S.sum(axis=1, keepdims=True) * (1 + 1e-6) + 1e-9):
        raise ValueError("the anatomical source channel is not part of the structural source mass; use a "
                         "structural feature set that contains it (gray/white, gmwm or anatomical).")
    target_names = [str(v) for v in target_archive["annotation_feature_names"]] \
        if "annotation_feature_names" in target_archive.files else [key]
    with_nu_anat = {"nu_Anat": np.asarray(source_archive["nu_Anat"], dtype=np.float64)[keep],
                    "nu_Anat_names": [str(v) for v in source_archive["anatomical_feature_names"]]}
    return {"nu_S": nu_S_anat, "nu_T": nu_T_anat, "source_names": source_names, "target_names": target_names,
            **with_nu_anat}, "available"


def load_inputs(config: dict, record: dict) -> dict[str, Any]:
    """Load 2-D source/target measures, center each, and read the QC strip cells."""

    source_file = resolve_path(config, record["source_particles"])
    target_file = resolve_path(config, record["target_particles"])
    S, nu_S, source_meta = load_particle_archive(source_file, record.get("feature_key", "nu_Sub"))
    T, nu_T, target_meta = load_particle_archive(target_file, record.get("feature_key", "nu_Sub"))
    settings = anatomical_settings(record)
    with np.load(target_file, allow_pickle=False) as target_archive, \
            np.load(source_file, allow_pickle=False) as archive:
        target_names = [str(v) for v in target_archive["coarse_feature_names"]]
        source_names = [str(v) for v in archive["coarse_feature_names"]]
        keep = np.ones(len(S), dtype=bool)
        projection = record.get("source_feature_projection")
        if projection is not None:
            nu_S, source_names = project_source_features(archive, str(projection))
            # A particle is a particle only where it carries mass (label_class_masses keeps
            # nu.sum > 0); a sub-channel projection (mtg_gm) empties the others, whose feature
            # composition would be 0/0 in makePQ.  gmwm / anatomical drop nothing.
            keep = nu_S.sum(axis=1) > 0
            S, nu_S = S[keep], nu_S[keep]
        # Read whenever the archives carry it: post-fit diagnostics use it even at weight 0.
        # The objective uses it only when weight > 0 (build_model).
        anatomical, anatomical_status = load_anatomical(archive, target_archive, target_meta, settings, keep,
                                                        np.asarray(nu_S, np.float64), np.asarray(nu_T, np.float64))
    if settings["weight"] == 0:
        term_status = "off (weight 0): original structural objective"
    elif anatomical is None:
        term_status = f"inactive ({anatomical_status}): original structural objective"
        if anatomical_status != "section has no HALO annotation":
            raise ValueError(f"anatomical_supervision.weight > 0 but {anatomical_status}.")
        print(f"WARNING: anatomical term requested but {anatomical_status}; running the structural objective.")
    else:
        term_status = "active"
    for name, X in (("source", S), ("target", T)):
        if not np.allclose(X[:, 2], 0):
            raise ValueError(f"{name} particles are not planar (z != 0); prepare them first.")
    if source_meta.get("coordinate_space") != "mni_icbm2009b_symmetric_plane":
        raise ValueError(f"Unexpected source space {source_meta.get('coordinate_space')!r}.")
    expected_target_space = record.get("target_coordinate_space", "seaad_section_mm")
    if target_meta.get("coordinate_space") != expected_target_space:
        raise ValueError(f"Unexpected target space {target_meta.get('coordinate_space')!r}; "
                         f"record expects {expected_target_space!r}.")

    mode = record.get("target_feature_mode", "classes")
    if mode == "total_mass":
        nu_T = nu_T.sum(axis=1, keepdims=True)
        target_names = ["total_mass"]
    elif mode != "classes":
        raise ValueError("target_feature_mode must be 'classes' or 'total_mass'.")

    with np.load(resolve_path(config, record["qc_strip_cells"]), allow_pickle=False) as archive:
        strip_X, strip_depth = archive["X"][:, :2].astype(np.float64), archive["depth_from_pia_um"].astype(np.float64)

    S2, T2 = S[:, :2].astype(np.float64), T[:, :2].astype(np.float64)
    source_center, target_center = S2.mean(axis=0), T2.mean(axis=0)
    # "shared_target": both measures were already placed in one frame (e.g. a rigid scan
    # result), so subtract the same center and keep that placement.
    center_mode = record.get("center_mode", "independent")
    if center_mode == "shared_target":
        source_center = target_center
    elif center_mode != "independent":
        raise ValueError("center_mode must be 'independent' or 'shared_target'.")
    return {
        "source_file": source_file, "target_file": target_file,
        "source_meta": source_meta, "target_meta": target_meta,
        "S": S2 - source_center, "nu_S": nu_S.astype(np.float64),
        "T": T2 - target_center, "nu_T": nu_T.astype(np.float64),
        "source_center": source_center, "target_center": target_center,
        "strip_X": strip_X - target_center, "strip_depth_um": strip_depth,
        "source_names": source_names, "target_names": target_names, "mode": mode,
        "source_feature_projection": record.get("source_feature_projection"),
        "anatomical": anatomical, "anatomical_settings": settings, "anatomical_term": term_status,
        "structural_feature_map": str(record.get("structural_feature_map", "learned")),
    }


# --------------------------------------------------------------------------------------
# Model construction (shared by every stage)
# --------------------------------------------------------------------------------------

def build_model(api, inputs: dict, model: dict, init_id: str, device, dtype) -> dict[str, Any]:
    xmodmap = api.xmodmap
    M = initial_transform(init_id)
    as_tensor = lambda a: torch.as_tensor(np.ascontiguousarray(a), dtype=dtype, device=device)
    S, nu_S = as_tensor(inputs["S"]), as_tensor(inputs["nu_S"])
    T, nu_T = as_tensor(inputs["T"] @ M.T), as_tensor(inputs["nu_T"])
    csqpi, csqlamb = float(model["csqpi"]), float(model["csqlamb"])
    lamb_init = torch.tensor(float(model["lamb_init"]), dtype=dtype, device=device)

    (w_S, w_T, zeta_S, zeta_T, _q0, _p0, _numS, S_tilde, T_tilde, s, m, pi_init, _lamb0) = api.make_pq(
        S, nu_S, T, nu_T, Csqpi=csqpi, lambInit=lamb_init, Csqlamb=csqlamb
    )
    s_mm = float(s)
    if not np.isfinite(s_mm) or s_mm <= 0:
        raise ValueError("makePQ returned a degenerate joint scale.")
    to_unit = lambda values: [float(v) / s_mm for v in values]
    sigma_var, sigma_rkhs = to_unit(model["sigma_var_mm"]), to_unit(model["sigma_rkhs_mm"])
    dens_sigma = float(model["dens_sigma_mm"]) / s_mm
    gamma = float(model["gamma"])
    geometry_only = inputs["mode"] == "total_mass"
    if geometry_only:
        pi_init = torch.ones((1, 1), dtype=dtype, device=device)
    # structural_feature_map "identity": source and target features are the same classes (QNP gray/white
    # = atlas gray/white), so pi_ST is fixed to I_F as in xmodmap.model.SingleModality -- not learned,
    # no KL regulariser -- instead of the cross-modal learned map ("learned", the default).
    feature_map = str(inputs.get("structural_feature_map", "learned"))
    if feature_map not in ("learned", "identity"):
        raise ValueError("structural_feature_map must be 'learned' or 'identity'.")
    fixed_identity = feature_map == "identity" and not geometry_only
    # The structural term is normalised (normalize_across_scale) by its start mismatch under makePQ's initial pi.
    # The identity map keeps that same normalisation constant, so switching the map changes pi only, not the
    # term's weight against the anatomical term (normalising with I instead raised it 7-45x per kernel at the
    # reference start on H20.33.034; docs/qnp_anatomical_supervision.md).
    pi_normalisation = pi_init
    if fixed_identity:
        if list(inputs["source_names"]) != list(inputs["target_names"]):
            raise ValueError(f"structural_feature_map 'identity' needs identical source and target features; got "
                             f"{inputs['source_names']} vs {inputs['target_names']}.")
        pi_init = torch.eye(len(inputs["source_names"]), dtype=dtype, device=device)
    pi_fixed = geometry_only or fixed_identity

    data_loss = xmodmap.distance.LossVarifoldNormBoundary_Partial(sigma_var, w_T, zeta_T, T_tilde, dens_sigma)
    data_loss.normalize_across_scale(S_tilde, w_S, zeta_S, pi_normalisation, lamb_init)
    # inputs built by hand (tests, older callers) carry no anatomical keys: the original objective
    settings = inputs.get("anatomical_settings") or {"structural_weight": 1.0}
    data_loss.weight = settings["structural_weight"]  # lambda_struct; 1.0 unless configured
    terms = []
    if inputs.get("anatomical_term") == "active":
        terms.append(build_anatomical_term(xmodmap, inputs["anatomical"], settings, settings["weight"], S_tilde,
                                           T_tilde, w_S, s_mm, as_tensor))

    pi_loss = xmodmap.distance.PiRegularizationSystem(zeta_S, zeta_T, w_T)
    # F = 1 (geometry-only): no feature law to regularize; pi is fixed to identity below.
    pi_loss.weight = 0.0 if pi_fixed else gamma * 0.1 / float(np.log(nu_T.shape[-1]))
    lamb_loss = xmodmap.distance.SupportRestrictionReg(torch.tensor(float(model["eta0"]), dtype=dtype, device=device))
    lamb_loss.weight = gamma

    k_scale = torch.tensor(float(model.get("precondition_scale", 1.0)), dtype=dtype, device=device)
    variables = {
        "qx": S_tilde.clone().detach().requires_grad_(True),
        "qw": w_S.clone().detach().requires_grad_(True),
        "px": torch.zeros_like(S_tilde).requires_grad_(True),
        "pw": torch.zeros_like(w_S).requires_grad_(True),
        # Square-root parameterization: the loss sees (pi_ST * csqpi)^2 = pi.
        # (fixed identity: preconditioner 1 and the variable is I_F itself, so the loss sees exactly I_F)
        "pi_ST": (torch.sqrt(pi_init) if fixed_identity else
                  (1.0 / csqpi) * torch.sqrt(pi_init)).clone().detach().requires_grad_(not pi_fixed),
        "zeta_S": zeta_S,
        # lambda is inert for 2-D density support; fixed at lamb_init, not optimized.
        "lamb": (lamb_init.sqrt() / csqlamb).clone().detach(),
    }
    pi_precond = 1.0 if fixed_identity else csqpi
    precond = {"px": torch.rsqrt(k_scale), "pw": torch.rsqrt(k_scale) / 2.0 / w_S, "pi_ST": pi_precond, "lamb": csqlamb}
    to_optimize = ["px", "pw"] if pi_fixed else ["px", "pw", "pi_ST"]
    return {
        "M": M, "S": S, "T": T, "nu_S": nu_S, "nu_T": nu_T, "w_S": w_S, "w_T": w_T,
        "zeta_S": zeta_S, "zeta_T": zeta_T, "S_tilde": S_tilde, "T_tilde": T_tilde, "s": s, "m": m,
        "pi_init": pi_init, "lamb_init": lamb_init, "data_loss": data_loss, "pi_loss": pi_loss,
        "lamb_loss": lamb_loss, "variables": variables, "precond": precond, "to_optimize": to_optimize,
        "sigma_var_unit": sigma_var, "sigma_rkhs_unit": sigma_rkhs, "dens_sigma_unit": dens_sigma,
        "geometry_only": geometry_only, "gamma": gamma, "csqpi": csqpi, "k_scale": k_scale, "terms": terms,
        "structural_feature_map": "identity" if fixed_identity else ("geometry-only" if geometry_only else "learned"),
        "pi_fixed": pi_fixed, "pi_precond": pi_precond,
        "nt": int(model.get("shooting_time_steps", 10)),
        "deformation": dict(cA=float(model["c_rotation"]), cS=float(model["c_nonrigid"]),
                            cT=float(model["c_translation"]), dimEff=2, single=False),
    }


def build_anatomical_term(xmodmap, anatomical: dict, settings: dict, weight: float, S_tilde, T_tilde, w_S,
                          s_mm: float, as_tensor, normalization: str | None = None, censoring: str | None = None):
    """The anatomical ``VarifoldTerm`` (see the module docstring), in xmodmap's unit box.

    Source features: the MTG mass as a fraction of each atlas particle's (shared) weight, so the
    term rides the same transported weights as the structural term.  Target: annotated tissue
    masses; the annotation mask is built from them alone.  ``censoring`` (default: the settings')
    "annotation" censors the atlas by the mask; "none" gives the ordinary varifold distance
    (``LossVarifoldNormCensored`` without censors is ``LossVarifoldNorm``).
    """

    if settings["sigma_var_mm"] is None or settings["annotation_sigma_mm"] is None:
        raise ValueError("anatomical term needs sigma_var_mm and annotation_sigma_mm (or model.sigma_var_mm and "
                         "model.dens_sigma_mm to inherit).")
    nu_S_anat = as_tensor(anatomical["nu_S"])
    zeta_A = torch.where(w_S > 0, nu_S_anat / torch.where(w_S > 0, w_S, torch.ones_like(w_S)),
                         torch.zeros_like(w_S))
    a_T = as_tensor(anatomical["nu_T"])
    sigma_var = [v / s_mm for v in settings["sigma_var_mm"]]
    mask = xmodmap.distance.SmoothedIndicatorField(T_tilde, a_T / s_mm ** 2, settings["annotation_sigma_mm"] / s_mm)
    censors = [mask] if (censoring or settings.get("censoring", "annotation")) == "annotation" else []
    loss = xmodmap.distance.LossVarifoldNormCensored(sigma_var, a_T, torch.ones_like(a_T), T_tilde, censors=censors)
    one = torch.ones((1, 1), dtype=a_T.dtype, device=a_T.device)
    if (normalization or settings["normalization"]) == "target":
        loss.normalize_to_target()
    else:
        loss.normalize_across_scale(S_tilde, w_S, zeta_A, one)
    return xmodmap.model.VarifoldTerm("anatomical", loss, zeta_A, pi_ST=one, weight=weight)


def stage_plan(api, model: dict, steps_override: int | None) -> list[dict[str, Any]]:
    """Named deformation stages, run in order (see the module docstring)."""

    stages = model.get("stages") or [{"transform": model.get("transform", "affine+diffeo"),
                                      "steps": model.get("steps", 150)}]
    plan = []
    for stage in stages:
        transform = str(stage["transform"])
        if transform not in api.transforms:
            raise ValueError(f"Unknown transform {transform!r}; xmodmap accepts {list(api.transforms)}.")
        steps = steps_override if steps_override is not None else stage.get("steps", model.get("steps", 150))
        plan.append({"transform": transform, "steps": int(steps)})
    return plan


def run_stages(api, built: dict, plan: list[dict], output_dir: Path) -> list[dict[str, Any]]:
    """Fit each stage from the previous stage's end point; return the flows and optima."""

    xmodmap = api.xmodmap
    qx0, qw0 = built["S_tilde"], built["w_S"]
    pi_var = built["variables"]["pi_ST"]
    stages = []
    for index, stage in enumerate(plan):
        hamiltonian = xmodmap.deformation.Hamiltonian(built["sigma_rkhs_unit"], qx0, transform=stage["transform"],
                                                      **built["deformation"])
        hamiltonian.weight = built["gamma"]
        shooting = xmodmap.deformation.Shooting(hamiltonian, nt=built["nt"])
        variables = dict(
            built["variables"],
            qx=qx0.clone().detach().requires_grad_(True),
            qw=qw0.clone().detach().requires_grad_(True),
            px=torch.zeros_like(qx0).requires_grad_(True),
            pw=torch.zeros_like(qw0).requires_grad_(True),
            pi_ST=pi_var.clone().detach().requires_grad_(not built["pi_fixed"]),
        )
        precond = dict(built["precond"], pw=torch.rsqrt(built["k_scale"]) / 2.0 / qw0)
        stage_dir = output_dir if len(plan) == 1 else output_dir / f"stage{index}_{stage['transform']}"
        components = (hamiltonian, shooting, built["data_loss"], built["pi_loss"], built["lamb_loss"])
        if built["terms"] or built["structural_feature_map"] == "identity":
            # also for a fixed identity map without extra terms: this model skips the weight-0 pi regulariser
            loss = instantiate_model(xmodmap.model.CrossModalityBoundaryMultiTerm, *components, built["terms"])
        else:  # the original model, exactly
            loss = instantiate_model(xmodmap.model.CrossModalityBoundary, *components)
        loss.init(variables, built["to_optimize"], precond=precond, savedir=str(stage_dir))
        start_components = loss.components() if built["terms"] else None
        loss.optimize(stage["steps"])
        if not loss.log:
            raise RuntimeError(f"Stage {index} ({stage['transform']}) finished without a recorded loss.")
        optimized = loss.get_variables_optimized()
        flow = shooting(optimized["px"], optimized["pw"], optimized["qx"], optimized["qw"])
        # Keep the graph on the shot state: ShootingBackwards differentiates the Hamiltonian.
        shot = flow[-1]
        components_record = {"start": start_components, "end": loss.components()} if built["terms"] else None
        stop = getattr(loss, "stop_reason", None)
        stages.append({**stage, "loss": loss, "optimized": optimized, "shot": shot, "components": components_record,
                       "stop_reason": None if stop is None else {k: stop[k] for k in ("kind", "iteration")},
                       "frames": [(state[2].detach(), state[3].detach()) for state in flow],
                       "shooting_back": xmodmap.deformation.ShootingBackwards(hamiltonian, nt=built["nt"])})
        qx0, qw0 = shot[2].detach(), shot[3].detach()
        pi_var = optimized["pi_ST"].detach() / built["pi_precond"]
    return stages


def _plane_axis_labels(plane: dict | None) -> tuple[str, str]:
    """Axis labels for in-plane coordinates: the parallel MNI axis when u or v is aligned with one."""

    labels = []
    for key, fallback in (("u_axis", "u (mm)"), ("v_axis", "v (mm)")):
        axis = np.asarray((plane or {}).get(key, []), float)
        name = fallback
        if axis.shape == (3,) and np.max(np.abs(axis)) > 0.999:
            name = f"{'xyz'[int(np.argmax(np.abs(axis)))]} (mm)"
        labels.append(name)
    return labels[0], labels[1]


def save_trajectory(api, built: dict, stages: list[dict], pi: torch.Tensor, path: Path, inputs: dict) -> None:
    """Save the forward flow in mm for ``view_xiv_trajectory.py`` (xmodmap.plot viewers).

    Frames run through every stage in order (stage boundaries repeat one state). Positions
    are in the initialized target frame, like ``atlas_deformationSummary``.
    """

    to_mm = lambda q: api.resize_data(q, built["s"], built["m"])
    measures = {"S": to_mm(built["S_tilde"]), "w_S": built["w_S"], "zeta_S": built["zeta_S"],
                "T": to_mm(built["T_tilde"]), "w_T": built["w_T"], "zeta_T": built["zeta_T"]}
    write_trajectory(path, measures, [(to_mm(q), w) for stage in stages for q, w in stage["frames"]], pi_ST=pi,
                     stages=[stage["transform"] for stage in stages],
                     frame_stage=[k for k, stage in enumerate(stages) for _ in stage["frames"]],
                     units="mm, initialized target frame",
                     source_names=[n.replace("_", " ") for n in inputs["source_names"]],
                     target_names=[n.replace("_", " ") for n in inputs["target_names"]],
                     axis_labels=_plane_axis_labels(inputs["source_meta"].get("plane")),
                     panel_titles=("Atlas plane (template)", "Section (target)", "Deformed atlas plane"))


def _render_panels(api, output_dir: Path) -> None:
    """Write the labelled source | target | deformed figure at t = 1 (upstream's 2-D viewer).

    This is the main visual check of a fit, but a rendering failure only warns: the fit
    and its numeric outputs are already saved.
    """

    import warnings

    import xmodmap.plot  # noqa: F401  (registers api.xmodmap.plot)

    try:
        render_registration(api.xmodmap, load_trajectory(output_dir / "trajectory.pt"), output_dir,
                            times=(1.0,), viewer="2d")
    except Exception as error:  # noqa: BLE001 - figure output must not discard a finished fit
        warnings.warn(f"registration figure not written: {error!r}")


def pull_back(stages: list[dict], points: torch.Tensor, weights: torch.Tensor):
    """Carry target-frame points (unit box) back to the source plane through every stage."""

    for stage in reversed(stages):
        px1, pw1, qx1, qw1 = stage["shot"]
        *_, points, weights = stage["shooting_back"](px1, pw1, qx1, qw1, points, weights)[-1]
        points, weights = points.detach(), weights.detach()
    return points, weights


def raw_density(data_loss, qx: torch.Tensor) -> torch.Tensor:
    """Unnormalized target density at qx (what densityWeight min-max normalizes)."""

    ones = torch.ones((qx.shape[0], 1), dtype=qx.dtype, device=qx.device)
    return data_loss.Kd(qx, data_loss.Ttilde, ones, data_loss.w_T)


# --------------------------------------------------------------------------------------
# Stage: support-check
# --------------------------------------------------------------------------------------

def support_check(built: dict, output_dir: Path) -> dict[str, Any]:
    s = float(built["s"])
    S0 = built["S_tilde"].detach()
    center = S0.mean(dim=0, keepdim=True)
    shift = torch.tensor([[0.5 / s, 0.0]], dtype=S0.dtype, device=S0.device)
    wavelength = 10.0 / s  # 10 mm
    bump = (0.5 / s) * torch.sin(2.0 * np.pi * (S0 - center).flip(-1) / wavelength)
    cases = {
        "initial": S0,
        "rigid_shift_0.5mm": S0 + shift,
        "scale_1.1_plus_0.5mm_sinusoid": center + 1.1 * (S0 - center) + bump,
    }
    preconditioned = {key: value * built["precond"].get(key, 1.0) for key, value in built["variables"].items()}
    report: dict[str, Any] = {"weights_are": "relative (min-max over current source particles), not coverage probabilities"}
    failures = []
    for name, positions in cases.items():
        qx = positions.clone().requires_grad_(True)
        qw = built["w_S"].clone().detach().requires_grad_(True)
        density = raw_density(built["data_loss"], qx.detach())
        weights = built["data_loss"].supportWeight(qx.detach(), preconditioned["lamb"] ** 2)
        loss = built["data_loss"](qx, qw, built["zeta_S"], preconditioned["pi_ST"].detach(), preconditioned["lamb"])
        loss.backward()
        d = density.detach().cpu().numpy().ravel()
        w = weights.detach().cpu().numpy().ravel()
        gx, gw = qx.grad.detach().cpu().numpy(), qw.grad.detach().cpu().numpy()
        entry = {
            "density_min": float(d.min()), "density_max": float(d.max()),
            "density_relative_range": float((d.max() - d.min()) / max(abs(d.max()), 1e-30)),
            "weight_min": float(w.min()), "weight_max": float(w.max()), "weight_std": float(w.std()),
            "weight_fraction_above_0.5": float(np.mean(w > 0.5)),
            "data_loss": float(loss.detach()),
            "grad_qx_norm": float(np.linalg.norm(gx)), "grad_qw_norm": float(np.linalg.norm(gw)),
        }
        checks = {
            "weights_finite": bool(np.all(np.isfinite(w))),
            "density_range_nonzero": entry["density_relative_range"] > 1e-6,
            "weights_vary": entry["weight_std"] > 0,
            "loss_finite": bool(np.isfinite(entry["data_loss"])),
            "gradients_finite": bool(np.all(np.isfinite(gx)) and np.all(np.isfinite(gw))),
            "gradients_nonzero": entry["grad_qx_norm"] > 0 and entry["grad_qw_norm"] > 0,
        }
        entry["checks"] = checks
        failures += [f"{name}: {key}" for key, ok in checks.items() if not ok]
        report[name] = entry
    for term in built["terms"]:  # extra terms (anatomical): same cases, same particles
        report[term.name] = {}
        for name, positions in cases.items():
            qx = positions.clone().requires_grad_(True)
            qw = built["w_S"].clone().detach().requires_grad_(True)
            value = term.value(qx, qw)
            value.backward()
            mask = term.loss.censor_weight(qx.detach()).detach().cpu().numpy().ravel()
            gx, gw = qx.grad.detach().cpu().numpy(), qw.grad.detach().cpu().numpy()
            entry = {"loss_unweighted": float(value.detach()), "weight": term.weight,
                     "complete_miss_value": float(sum(0.6 / sig for sig in term.loss.sigmaVar)),
                     "mask_fraction_above_0.5": float(np.mean(mask > 0.5)), "mask_max": float(mask.max()),
                     "grad_qx_norm": float(np.linalg.norm(gx)), "grad_qw_norm": float(np.linalg.norm(gw))}
            checks = {"loss_finite": bool(np.isfinite(entry["loss_unweighted"])),
                      "mask_in_unit_interval": bool(mask.min() >= 0 and mask.max() <= 1),
                      "gradients_finite": bool(np.all(np.isfinite(gx)) and np.all(np.isfinite(gw)))}
            entry["checks"] = checks
            failures += [f"{term.name}/{name}: {key}" for key, ok in checks.items() if not ok]
            report[term.name][name] = entry
    report["failures"] = failures
    (output_dir / "support_check.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    return report


# --------------------------------------------------------------------------------------
# Stage: fit one initialization
# --------------------------------------------------------------------------------------

def _pad3(points: torch.Tensor | np.ndarray):
    if torch.is_tensor(points):
        return torch.cat([points, torch.zeros_like(points[:, :1])], dim=1) if points.shape[1] == 2 else points
    points = np.asarray(points)
    return np.column_stack([points, np.zeros(len(points))]) if points.shape[1] == 2 else points


def _writers(api, convention: str):
    def writeVTK(points, arrays, names, filename, *args, **kwargs):
        write_vtk_xyz(api, _pad3(points), arrays, names, filename, coordinate_convention=convention)

    def writeParticleVTK(points, feature_mass, filename, norm=True, condense=False, featNames=None, sW=None,
                         *args, **kwargs):
        write_particle_vtk_xyz(api, _pad3(points), feature_mass, filename, coordinate_convention=convention,
                               norm=norm, condense=condense, feature_names=featNames, support_weights=sW)

    return writeVTK, writeParticleVTK


def _write_matrix_csv(path: Path, matrix: np.ndarray, rows: list[str], columns: list[str], comment: str) -> None:
    with open(path, "w", newline="", encoding="utf-8") as stream:
        stream.write(f"# {comment}\n")
        writer = csv.writer(stream)
        writer.writerow(["source_feature", *columns])
        for name, values in zip(rows, matrix):
            writer.writerow([name, *[f"{v:.6g}" for v in values]])


def _hull_area(points: np.ndarray) -> float | None:
    return float(ConvexHull(points).volume) if len(points) >= 3 else None


def _qc_warp(path, D, support, T, nu_T, target_names, points_back, S_plane, axis_labels):
    """Deformed atlas over the section (shaded by support) | QC points pulled back to the atlas plane."""

    xlabel, ylabel = axis_labels
    fig, axes = plt.subplots(1, 2, figsize=(13, 6), constrained_layout=True)
    ax = axes[0]
    dominant = np.argmax(nu_T, axis=1)
    for index, name in enumerate(target_names):
        sel = dominant == index
        if np.any(sel):
            ax.scatter(T[sel, 0], T[sel, 1], s=14, marker="s", color=CLASS_COLORS[index % 7],
                       linewidths=0, alpha=0.5, label=f"section: {name.replace('_', ' ')}")
    shown = ax.scatter(D[:, 0], D[:, 1], s=5, c=support, cmap="Greys", vmin=0, vmax=1,
                       edgecolors="#1a1a19", linewidths=0.2, label="deformed atlas")
    fig.colorbar(shown, ax=ax, shrink=0.6, label="support weight")
    ax.set_aspect("equal")
    ax.set_title("Deformed atlas plane on section", fontsize=11)
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    ax.legend(loc="upper left", bbox_to_anchor=(0, -0.08), fontsize=8, frameon=False, ncol=3)

    ax = axes[1]
    ax.scatter(S_plane[:, 0], S_plane[:, 1], s=5, marker="s", color="#c3c2b7", linewidths=0, label="atlas plane")
    shown = ax.scatter(points_back[:, 0], points_back[:, 1], s=1, c=points_back[:, 2], cmap="viridis", linewidths=0)
    fig.colorbar(shown, ax=ax, shrink=0.6, label="depth from pia (mm)")
    ax.set_aspect("equal")
    ax.set_title("Cortical QC points pulled back to atlas plane", fontsize=11)
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    ax.legend(loc="upper left", bbox_to_anchor=(0, -0.08), fontsize=8, frameon=False)
    fig.savefig(path, dpi=200)
    plt.close(fig)


def fit_initialization(api, config, record, inputs, model, init_id, plan, output_dir, device, dtype) -> dict:
    convention = str(record.get("vtk_coordinate_convention", "xyz"))
    writeVTK, writeParticleVTK = _writers(api, convention)
    built = build_model(api, inputs, model, init_id, device, dtype)
    s, m = built["s"], built["m"]

    _save_original(writeVTK, built["S"], built["nu_S"], built["T"], built["nu_T"], output_dir)
    stages = run_stages(api, built, plan, output_dir)
    loss, optimized = stages[-1]["loss"], stages[-1]["optimized"]

    # One stage keeps the historical flat keys; several are prefixed "stage<k>.".
    prefix = (lambda k: "") if len(stages) == 1 else (lambda k: f"stage{k}.")
    torch.save({prefix(k) + name: (v.detach() if torch.is_tensor(v) else v)
                for k, stage in enumerate(stages) for name, v in stage["optimized"].items()},
               output_dir / "optimized_variables.pt")
    qx1, qw1 = stages[-1]["shot"][2].detach(), stages[-1]["shot"][3].detach()
    pi = (optimized["pi_ST"].detach() ** 2)
    save_trajectory(api, built, stages, pi, output_dir / "trajectory.pt", inputs)
    _render_panels(api, output_dir)
    support = built["data_loss"].supportWeight(qx1, optimized["lamb"].detach() ** 2).detach()
    density = raw_density(built["data_loss"], qx1).detach()

    # Deformed source in the (initialized) target frame, mm.
    D = api.resize_data(qx1, s, m)
    nu_D = torch.squeeze(qw1)[..., None] * built["zeta_S"]
    nu_Dpi = nu_D @ pi
    mass_ratio = api.get_mass_ratio(D, built["nu_S"], nu_D)
    save_atlas_outputs(writeParticleVTK, writeVTK, api.get_entropy,
                       {"D": D, "nu_D": nu_D, "nu_Dpi": nu_Dpi, "mass_ratio_proxy": mass_ratio,
                        "relative_support_weight": support, "raw_density": density},
                       output_dir, inputs["source_names"], inputs["target_names"])

    # Target bins and strip cells carried back to the atlas plane.
    Td, wTd = pull_back(stages, built["T_tilde"], built["w_T"])
    _save_target(writeParticleVTK, writeVTK, api.get_mass_ratio, api.get_entropy, api.resize_data,
                 Td, wTd, built["zeta_T"], built["w_T"], s, m, output_dir)
    strip_init = torch.as_tensor(inputs["strip_X"] @ built["M"].T, dtype=dtype, device=device)
    strip_tilde = (strip_init - m) / s
    strip_w = torch.ones((len(strip_tilde), 1), dtype=dtype, device=device)
    strip_back, _ = pull_back(stages, strip_tilde, strip_w)
    strip_back_plane = api.resize_data(strip_back, s, m).cpu().numpy() + inputs["source_center"]
    np.savez_compressed(output_dir / "qc_points_pulled_back.npz", X_plane=strip_back_plane,
                        depth=inputs["strip_depth_um"], coordinate_space=np.asarray("source plane mm"))

    # ---- canonical-frame scores (fixed scales and support; comparable across starts and models) ----
    M = built["M"]
    D_canon = D.cpu().numpy() @ M  # undo the discrete transform (M orthogonal)
    sw = support.cpu().numpy()
    nu_Dpi_np = nu_Dpi.cpu().numpy()
    T_canon, nu_T_np = inputs["T"], inputs["nu_T"]
    sigmas = [float(v) for v in model.get("score_sigmas_mm", [2.0, 1.0, 0.5])]
    # The model's own support depends on dens_sigma_mm, so scoring with it would reward
    # heavier censoring. Scores use the rigid scan's fixed section footprint instead.
    footprint_sigma = float(model.get("score_footprint_sigma_mm", 0.5))
    score_w = FootprintScorer(T_canon, nu_T_np, footprint_sigma_mm=footprint_sigma).footprint(D_canon)[:, None]
    scores = {
        "score_total_mass": varifold_score_mm(D_canon, nu_Dpi_np.sum(1, keepdims=True) * score_w,
                                              T_canon, nu_T_np.sum(1, keepdims=True), sigmas),
        "score_classes": (None if built["geometry_only"]
                          else varifold_score_mm(D_canon, nu_Dpi_np * score_w, T_canon, nu_T_np, sigmas)),
        "score_sigmas_mm": sigmas,
        "score_footprint_sigma_mm": footprint_sigma,
        "labels": {"score_total_mass": "tissue mismatch", "score_classes": "gray/white mismatch"},
        "definition": "mean over sigma of |mu_src - mu_tgt|^2 / |mu_tgt|^2 (0 = identical, 1 = no overlap); "
                      "source = pi-mapped deformed atlas weighted by the section footprint (fixed sigma, as in "
                      "the rigid scan), not by the model's support; canonical (centered, untransformed) target frame",
    }
    final = [float(v) for v in loss.log[-1]]
    scores["native_losses"] = dict(zip(getattr(loss, "term_names", ["hamiltonian", "data", "pi", "lambda"]), final))
    if built["terms"]:
        scores["loss_components"] = {
            "definition": "unweighted data terms (structural 'data' and each extra term) at the start and end of "
                          "each stage; native_losses are weighted",
            "weights": {"data": built["data_loss"].weight, **{t.name: t.weight for t in built["terms"]}},
            "complete_miss": {t.name: float(sum(0.6 / sig for sig in t.loss.sigmaVar)) for t in built["terms"]},
            "censoring": {t.name: ("annotation" if t.loss.censors else "none") for t in built["terms"]},
            "stages": [{"transform": stage["transform"], **stage["components"]} for stage in stages]}
    scores["native_total_loss"] = float(sum(final))
    scores["native_losses_note"] = "final closure of the last stage"
    scores["optimizer_stops"] = [{"transform": stage["transform"], **(stage.get("stop_reason") or {})}
                                 for stage in stages]
    (output_dir / "scores.json").write_text(json.dumps(scores, indent=2) + "\n", encoding="utf-8")

    # ---- pi, in interpretable form ----
    pi_np = pi.cpu().numpy()
    _write_matrix_csv(output_dir / "pi_ST.csv", pi_np, inputs["source_names"], inputs["target_names"],
                      "learned non-negative cross-modal coefficients (squared pi_ST); row sums are not constrained"
                      + ("; fixed to identity (geometry-only)" if built["geometry_only"] else "")
                      + ("; FIXED identity (structural_feature_map: identity), not learned"
                         if built["structural_feature_map"] == "identity" else ""))
    row_sum = pi_np.sum(axis=1, keepdims=True)
    _write_matrix_csv(output_dir / "pi_ST_row_composition.csv", pi_np / np.where(row_sum > 0, row_sum, 1.0),
                      inputs["source_names"], inputs["target_names"],
                      "row-normalized pi; single-region aggregate; not a regional feature law")

    # ---- plausibility diagnostics (numbers only; Level 2 is a manual judgement) ----
    S_np, ratio = built["S"].cpu().numpy(), np.squeeze(mass_ratio.cpu().numpy())
    supported = sw.ravel() > 0.5
    support_area = float((nu_D.sum(-1).cpu().numpy() * sw.ravel()).sum())
    target_area = float(nu_T_np.sum())
    plane_keys = {tuple(k) for k in np.round((S_np + inputs["source_center"]) / 0.5).astype(int).tolist()}
    strip_keys = np.round(strip_back_plane / 0.5).astype(int)
    inside = np.array([tuple(k) in plane_keys for k in strip_keys.tolist()])
    depth_mm = inputs["strip_depth_um"] / 1000.0
    depth_profile = {}
    for low, high in DEPTH_BINS_MM:
        sel = (depth_mm >= low) & (depth_mm < high)
        depth_profile[f"{low:g}-{high:g}mm"] = {
            "cells": int(sel.sum()), "fraction_in_rasterized_label": float(inside[sel].mean()) if sel.any() else None,
        }
    quantiles = lambda values: dict(zip(["p5", "p50", "p95"], np.percentile(values, [5, 50, 95]).tolist()))
    plausibility = {
        "mass_ratio_proxy_all": quantiles(ratio),
        "mass_ratio_proxy_supported": quantiles(ratio[supported]) if supported.any() else None,
        "supported_particles_fraction": float(supported.mean()),
        "support_weighted_area_mm2": support_area,
        "target_area_mm2": target_area,
        "support_weighted_area_ratio": support_area / target_area,
        "hull_area_ratio_supported": (None if supported.sum() < 3 else
                                      _hull_area(D.cpu().numpy()[supported]) / _hull_area(S_np[supported])),
        "depth_stratified_post_fit_diagnostic": {
            "note": "not independent validation: the fit sees strip positions and classes, not depth; "
                    "'inside' = within the rasterized 0.5 mm label pixels of the atlas plane",
            "bins": depth_profile,
        },
        "relative_support_weight_note": "min-max normalized over current source particles; not coverage probability",
    }
    flags = []
    med = plausibility["mass_ratio_proxy_supported"] or plausibility["mass_ratio_proxy_all"]
    if not 0.5 <= med["p50"] <= 2.0 or med["p5"] < 0.25 or med["p95"] > 4.0:
        flags.append("mass_ratio_proxy outside [0.5, 2] median or [0.25, 4] tails")
    if not 0.5 <= plausibility["support_weighted_area_ratio"] <= 2.0:
        flags.append("support-weighted area ratio outside [0.5, 2]")
    (output_dir / "plausibility.json").write_text(json.dumps(plausibility, indent=2) + "\n", encoding="utf-8")

    # ---- transform chain ----
    chain = {
        "source_plane": inputs["source_meta"].get("plane"),
        "source_plane_to_mni": "MNI = origin + u * u_axis + v * v_axis",
        "source_center_plane_mm": inputs["source_center"].tolist(),
        "target_raw_to_mm_scale": inputs["target_meta"].get("coordinate_scale_from_raw"),
        "target_a_cell_mm2": inputs["target_meta"].get("a_cell_mm2"),
        "target_center_section_mm": inputs["target_center"].tolist(),
        "center_mode": record.get("center_mode", "independent"),
        "initialization": init_id,
        "initial_transform_matrix_M": M.tolist(),
        "initial_transform_convention": "T_init = (T_section_mm - target_center) @ M.T; reflection is "
                                        "preprocessing, not part of the LDDMM flow",
        "unit_box": {"s_mm": float(s), "m_mm": m.detach().cpu().numpy().tolist(),
                     "convention": "X_tilde = (X - m) / s"},
        "sigma_mm_to_unit": {"sigma_var": built["sigma_var_unit"], "sigma_rkhs": built["sigma_rkhs_unit"],
                             "dens_sigma": built["dens_sigma_unit"]},
        "optimized_variables": str(output_dir / "optimized_variables.pt"),
        "stages": [{"transform": stage["transform"], "steps": stage["steps"],
                    "closure_evaluations": len(stage["loss"].log)} for stage in stages],
        "forward": "for each stage in order, Shooting(px, pw, qx, qw) under its named Hamiltonian; the last "
                   "stage leaves the atlas plane in T_init; D = X_tilde * s + m",
        "inverse": "ShootingBackwards(px1, pw1, qx1, qw1, P, w_P) of each stage, last stage first, carries "
                   "target points to the atlas plane",
    }
    (output_dir / "transform_chain.json").write_text(json.dumps(chain, indent=2) + "\n", encoding="utf-8")
    steps = sum(stage["steps"] for stage in stages)
    torch.save({"s": s, "m": m, "model": model, "stages": plan, "steps": steps, "init": init_id,
                "sigma_var_unit": built["sigma_var_unit"], "sigma_rkhs_unit": built["sigma_rkhs_unit"],
                "dens_sigma_unit": built["dens_sigma_unit"]}, output_dir / "model_settings.pt")

    for k, stage in enumerate(stages):
        tag = "" if len(stages) == 1 else f"_stage{k}_{stage['transform']}"
        for name, log_scale in ((f"loss{tag}.png", False), (f"logloss{tag}.png", True)):
            figure = stage["loss"].print_log(logScale=log_scale)
            figure.axes[0].set_xlabel("closure evaluation")
            figure.axes[0].set_ylabel("log(1 + loss)" if log_scale else "loss")
            figure.savefig(output_dir / name, dpi=200, bbox_inches="tight")
            plt.close(figure)
    strip_back_qc = np.column_stack([strip_back_plane, depth_mm])
    _qc_warp(output_dir / "qc_warp.png", D_canon + inputs["target_center"], sw.ravel(),
             T_canon + inputs["target_center"], nu_T_np, inputs["target_names"], strip_back_qc,
             S_np + inputs["source_center"], _plane_axis_labels(inputs["source_meta"].get("plane")))

    # ---- Level 1: finite outputs that reload ----
    reloaded = [torch.load(output_dir / f, weights_only=False) for f in
                ("optimized_variables.pt", "atlas_deformationSummary.pt", "target_deformationSummary.pt")]
    finite = all(bool(torch.isfinite(v).all()) for blob in reloaded for v in blob.values() if torch.is_tensor(v))
    finite &= bool(np.isfinite(strip_back_plane).all()) and bool(np.isfinite(pi_np).all())
    completion = {
        "registration": record["_name"], "initialization": init_id, "steps": steps,
        "stages": [stage["transform"] for stage in stages],
        "closure_evaluations_logged": sum(len(stage["loss"].log) for stage in stages),
        "level1_passed": bool(finite),
        "numeric_flags": flags,
        "level2_assessment": "manual - see qc_warp.png, plausibility.json, and the geometry-only baseline",
        **{k: scores[k] for k in ("score_total_mass", "score_classes", "native_total_loss")},
    }
    (output_dir / "COMPLETED.json").write_text(json.dumps(completion, indent=2) + "\n", encoding="utf-8")
    # Last, so that no original output can depend on it.
    if inputs.get("anatomical") is not None:
        diagnostics = anatomical_diagnostics(api, built, inputs, stages, Td, device, dtype)
        (output_dir / "anatomical_diagnostics.json").write_text(json.dumps(diagnostics, indent=2) + "\n",
                                                                 encoding="utf-8")
    write_registration_qc(api, built, inputs, output_dir, device, dtype,
                          title=f"{record['_name']}  {init_id}  ({' -> '.join(TRANSFORM_LABELS.get(s['transform'], s['transform']) for s in plan)})")
    return completion


def anatomical_diagnostics(api, built: dict, inputs: dict, stages: list[dict], Td: torch.Tensor, device,
                           dtype) -> dict[str, Any]:
    """Read-only, post-fit: the anatomical term and where target mass lands on the atlas channels.

    Evaluated whenever the archives carry the anatomical masses, also at weight 0, with target
    normalisation (comparable across fits and starts).  Landing: each target particle pulled back
    through the fitted flow is given the dominant ``nu_Anat`` channel of the nearest undeformed atlas
    particle (``outside_atlas_plane`` beyond 0.75 x the atlas particle spacing).  When the term is
    active the annotated landing is what it optimised, not independent validation.
    """

    from scipy.spatial import cKDTree

    anatomical, settings = inputs["anatomical"], inputs["anatomical_settings"]
    as_tensor = lambda a: torch.as_tensor(np.ascontiguousarray(a), dtype=dtype, device=device)
    qx1, qw1 = stages[-1]["shot"][2].detach(), stages[-1]["shot"][3].detach()
    by_censoring = {}
    for mode in ANATOMICAL_CENSORING:
        term = build_anatomical_term(api.xmodmap, anatomical, settings, 1.0, built["S_tilde"], built["T_tilde"],
                                     built["w_S"], float(built["s"]), as_tensor, normalization="target", censoring=mode)
        miss = float(sum(0.6 / sig for sig in term.loss.sigmaVar))
        with torch.no_grad():
            values = {"start": float(term.value(built["S_tilde"], built["w_S"])), "end": float(term.value(qx1, qw1))}
        by_censoring[mode] = {**values, "complete_miss": miss,
                              **{f"relative_{k}": v / miss for k, v in values.items()}}
    start, end = by_censoring["annotation"]["start"], by_censoring["annotation"]["end"]
    term = build_anatomical_term(api.xmodmap, anatomical, settings, 1.0, built["S_tilde"], built["T_tilde"],
                                 built["w_S"], float(built["s"]), as_tensor, normalization="target",
                                 censoring="annotation")
    S0 = built["S_tilde"].detach().cpu().numpy()
    tree = cKDTree(S0)
    spacing = float(np.median(tree.query(S0, k=2)[0][:, 1]))
    distance, nearest = tree.query(Td.detach().cpu().numpy())
    names = anatomical["nu_Anat_names"]
    label = np.where(distance <= 0.75 * spacing, np.argmax(anatomical["nu_Anat"][nearest], axis=1), len(names))
    annotated = anatomical["nu_T"][:, 0]
    unannotated = inputs["nu_T"].sum(axis=1) - annotated

    def landing(mass):
        total = float(mass.sum())
        return {n: float(mass[label == k].sum() / total) for k, n in enumerate([*names, "outside_atlas_plane"])}

    return {
        "anatomical_term": inputs["anatomical_term"], "weight": settings["weight"],
        "structural_weight": settings["structural_weight"],
        "settings": {k: settings[k] for k in sorted(settings)},
        "D2_anatomical_target_normalised": {"start": start, "end": end,
                                            "complete_miss": float(sum(0.6 / sig for sig in term.loss.sigmaVar)),
                                            "note": "0 = annotated tissue fully explained by atlas MTG; complete_miss = "
                                                    "no atlas MTG inside the annotation mask"},
        "D2_anatomical_by_censoring": {
            **by_censoring, "censoring_in_objective": settings.get("censoring", "annotation"),
            "note": "target-normalised D2 for both censoring modes at the fit's start and end.  The absolute values "
                    "carry a factor of the joint unit-box scale s (it changes with the start and the atlas plane); "
                    "relative_* = D2 / complete_miss = the 1/sigma-weighted mean over kernels of "
                    "|mismatch|^2 / |mu_T^annot|^2, which does not.  Censored: 1 = no atlas MTG inside the mask.  "
                    "Uncensored: a disjoint atlas MTG gives 1 + |mu_S^MTG|^2 / |mu_T^annot|^2 (> 1)."},
        "annotated_tissue_landing": landing(annotated),
        "unannotated_tissue_landing": landing(unannotated),
        "landing_rule": "target particles pulled back to the undeformed atlas plane; dominant nu_Anat channel of the "
                        "nearest atlas particle within 0.75 x spacing",
        "independence": ("fitted: the anatomical term optimised the annotated landing" if settings["weight"] > 0
                         and inputs["anatomical_term"] == "active" else
                         "not fitted: the objective did not see the annotation"),
    }


# --------------------------------------------------------------------------------------
# Registration QC figure (both feature representations, their supports, the numbers)
# --------------------------------------------------------------------------------------

TRANSFORM_LABELS = {"affine": "similarity", "affine+diffeo": "similarity+diffeo"}


def _similarity_fit(A: np.ndarray, B: np.ndarray) -> dict[str, float]:
    """Least-squares B ~ s R A + t over corresponding particles; the residual is the non-similarity part."""

    a, b = A - A.mean(0), B - B.mean(0)
    U, sig, Vt = np.linalg.svd(a.T @ b)
    R = (U @ Vt).T
    det = float(np.linalg.det(R))
    scale = float(sig.sum() / (a ** 2).sum())
    residual = b - scale * a @ R.T
    return {"scale": scale, "rotation_deg": float(np.degrees(np.arctan2(R[1, 0], R[0, 0]))),
            "reflection": det < 0, "translation_mm": (B.mean(0) - A.mean(0)).tolist(),
            "residual_rms_mm": float(np.sqrt((residual ** 2).sum(1).mean())),
            "residual_max_mm": float(np.sqrt((residual ** 2).sum(1)).max())}


def registration_qc_payload(api, built: dict, inputs: dict, fit_dir: Path, device, dtype,
                            title: str = "") -> dict[str, Any]:
    """Everything the QC figure draws, from a finished fit's saved outputs and the model's own losses.

    Positions and masses are the saved flow (``trajectory.pt``, first and last frame, mm in the
    initialized target frame).  The structural support at the end is the saved
    ``relative_support_weight``; its start value, the anatomical mask A and the MTG fraction are the
    model's own loss fields evaluated at those positions.  ``built`` must be the fit's model (or
    ``build_model`` of the same inputs and initialization: the unit box is checked).
    """

    from preprocess.atlas_features import projection_matrix
    from scipy.spatial import cKDTree
    from scripts.view_xiv_trajectory import load_trajectory

    trajectory = load_trajectory(fit_dir / "trajectory.pt")
    to_np = lambda x: x.detach().cpu().numpy() if torch.is_tensor(x) else np.asarray(x)
    (S0, w0), (S1, w1) = [(to_np(q).astype(np.float64), to_np(w).reshape(-1).astype(np.float64))
                          for q, w in (trajectory["frames"][0], trajectory["frames"][-1])]
    T, wT = to_np(trajectory["T"]).astype(np.float64), to_np(trajectory["w_T"]).reshape(-1).astype(np.float64)
    atlas = torch.load(fit_dir / "atlas_deformationSummary.pt", weights_only=False, map_location="cpu")
    target = torch.load(fit_dir / "target_deformationSummary.pt", weights_only=False, map_location="cpu")
    optimized = torch.load(fit_dir / "optimized_variables.pt", weights_only=False, map_location="cpu")
    settings = torch.load(fit_dir / "model_settings.pt", weights_only=False, map_location="cpu")
    scores = json.loads((fit_dir / "scores.json").read_text(encoding="utf-8"))
    chain = json.loads((fit_dir / "transform_chain.json").read_text(encoding="utf-8"))
    plausibility = json.loads((fit_dir / "plausibility.json").read_text(encoding="utf-8"))
    s, m = float(built["s"]), built["m"].detach()
    if abs(s - float(settings["s"])) > 1e-6 * s or not torch.allclose(m.cpu(), torch.as_tensor(settings["m"]).cpu()):
        raise ValueError("the rebuilt model's unit box differs from the fit's; wrong inputs or initialization")
    D = to_np(atlas["D"]).astype(np.float64)
    frame_check = float(np.abs(D - S1).max())  # saved summary vs last flow frame (same model output)
    unit = lambda X: (torch.as_tensor(X, dtype=dtype, device=device) - m) / s
    lamb = next(v for k, v in optimized.items() if k.endswith("lamb")).to(device=device, dtype=dtype)

    with torch.no_grad():
        support_start = to_np(built["data_loss"].supportWeight(unit(S0), lamb ** 2)).reshape(-1)
    support_end = to_np(atlas["relative_support_weight"]).reshape(-1).astype(np.float64)
    stages = [str(t) for t in trajectory["stages"]]
    nonlinear = any("diffeo" in t for t in stages)
    pi = to_np(trajectory["pi_ST"]).astype(np.float64)
    learned = "pi_ST" in built["to_optimize"]
    projection = inputs.get("source_feature_projection")
    payload: dict[str, Any] = {
        "title": title, "axis_labels": trajectory.get("axis_labels"),
        "transform_label": " -> ".join(TRANSFORM_LABELS.get(t, t) for t in stages),
        "source_start": S0, "w_source_start": w0, "source_end": S1, "w_source_end": w1, "target": T, "w_target": wT,
        "zeta_source": to_np(trajectory["zeta_S"]), "zeta_target": to_np(trajectory["zeta_T"]),
        "structural_source_names": list(inputs["source_names"]), "structural_target_names": list(inputs["target_names"]),
        "structural_support_start": support_start, "structural_support_end": support_end,
        "pi_structural": pi,
        "pi_structural_status": ("learned (optimised)" if learned else
                                 f"fixed identity I_{pi.shape[0]}, not learned" if built.get("structural_feature_map") == "identity"
                                 else "fixed identity (geometry-only)"),
        "pi_structural_initial": to_np(built["pi_init"]).astype(np.float64),
        "anatomical": None,
    }
    record: dict[str, Any] = {
        "frame": "mm, initialized target frame (as trajectory.pt)",
        "saved_summary_vs_last_frame_max_abs_mm": frame_check,
        "stages": stages,
        "initial_transform": {
            "qnp_to_plane_similarity": inputs["target_meta"].get("similarity_qnp_local_to_plane"),
            "xiv_initialization": chain.get("initialization"),
            "xiv_initialization_matrix_M": chain.get("initial_transform_matrix_M"),
        },
        "optimised_transform_fit": _similarity_fit(S0, S1),
        "optimizer_stops": scores.get("optimizer_stops"),
        "losses": {"native_weighted": scores.get("native_losses"), "components_unweighted": scores.get("loss_components"),
                   "score_total_mass": scores.get("score_total_mass"), "score_classes": scores.get("score_classes")},
        "structural_mass_mm2": {
            "atlas_start": float(w0.sum()), "atlas_end": float(w1.sum()), "target": float(wT.sum()),
            "atlas_counted_start (w*s)": float((w0 * support_start).sum()),
            "atlas_counted_end (w*s)": float((w1 * support_end).sum()),
            "particles_support_above_0.5_end": float(np.mean(support_end > 0.5)),
        },
        "feature_maps": {
            "structural_source_features": (f"fixed projection {projection!r} of nu_Anat" if projection else
                                           "archive feature_key (gray/white = the fixed gmwm projection of nu_Anat)"),
            "gmwm_projection": projection_matrix("gmwm", list(QC_CHANNELS))[1].tolist(),
            "structural_pi_ST_squared": pi.tolist(), "structural_pi_ST_initial": payload["pi_structural_initial"].tolist(),
            "structural_pi_ST_status": payload["pi_structural_status"],
        },
        "nonlinear": ({"mass_ratio_proxy_supported": plausibility.get("mass_ratio_proxy_supported"),
                       "hull_area_ratio_supported": plausibility.get("hull_area_ratio_supported"),
                       "target_mass_ratio_proxy_p50": float(np.median(to_np(target["mass_ratio_proxy"])))}
                      if nonlinear else "no diffeo stage: the flow is a similarity (residual_rms_mm ~ 0)"),
    }

    # Atlas channels are drawn whenever the source carries them, with or without a target annotation.
    payload["atlas_channels"] = None
    with np.load(inputs["source_file"], allow_pickle=False) as archive:
        if "nu_Anat" in archive.files and len(archive["nu_Anat"]) == len(S0):
            payload["atlas_channels"] = {"names": [str(v) for v in archive["anatomical_feature_names"]],
                                         "values": np.asarray(archive["nu_Anat"], np.float64)}
    anatomical = inputs.get("anatomical")
    if anatomical is not None:
        settings_a = inputs["anatomical_settings"]
        in_objective = bool(built["terms"])
        as_tensor = lambda a: torch.as_tensor(np.ascontiguousarray(a), dtype=dtype, device=device)
        term = built["terms"][0] if in_objective else build_anatomical_term(
            api.xmodmap, anatomical, settings_a, 0.0, built["S_tilde"], built["T_tilde"], built["w_S"], s, as_tensor,
            normalization="target")
        censoring = "annotation" if term.loss.censors else "none"
        zeta_mtg = to_np(term.zeta_S).reshape(-1).astype(np.float64)
        lo, hi = T.min(0) - 5.0, T.max(0) + 5.0
        step = 0.25
        gx, gy = np.meshgrid(np.arange(lo[0], hi[0], step), np.arange(lo[1], hi[1], step))
        # The annotation field A is drawn whatever the censoring; it censors the atlas only when censoring is
        # "annotation".  mask_* are the term's own weights on the atlas (all ones when uncensored).
        display = build_anatomical_term(api.xmodmap, anatomical, settings_a, 0.0, built["S_tilde"], built["T_tilde"],
                                        built["w_S"], s, as_tensor, normalization="target", censoring="annotation")
        with torch.no_grad():
            mask_end = to_np(term.loss.censor_weight(unit(S1))).reshape(-1).astype(np.float64)
            mask_start = to_np(term.loss.censor_weight(unit(S0))).reshape(-1).astype(np.float64)
            A_end = to_np(display.loss.censor_weight(unit(S1))).reshape(-1).astype(np.float64)
            A = to_np(display.loss.censor_weight(unit(np.column_stack([gx.ravel(), gy.ravel()])))).reshape(gx.shape)
        # landing: each target particle pulled back (saved Td) -> dominant channel of the nearest atlas particle
        names = list(anatomical["nu_Anat_names"])
        tree = cKDTree(S0)
        spacing = float(np.median(tree.query(S0, k=2)[0][:, 1]))
        distance, nearest = tree.query(to_np(target["Td"]).astype(np.float64))
        label = np.where(distance <= 0.75 * spacing, np.argmax(anatomical["nu_Anat"][nearest], axis=1), len(names))
        annotated = np.asarray(anatomical["nu_T"][:, 0], np.float64)
        fractions = {n: float(annotated[label == k].sum() / annotated.sum())
                     for k, n in enumerate([*names, "outside_atlas_plane"])}
        payload["anatomical"] = {
            "channel_names": names, "source_channels": np.asarray(anatomical["nu_Anat"]), "zeta_mtg": zeta_mtg,
            "target_annotated": annotated, "annotated_fraction": float(annotated.sum() / wT.sum()),
            "mask_end": mask_end, "mask_grid": (gx, gy, A), "landing_label": label, "annotated_landing": fractions,
            "in_objective": in_objective, "censoring": censoring, "annotation_at_end": A_end,
        }
        diagnostics_file = fit_dir / "anatomical_diagnostics.json"
        diagnostics = json.loads(diagnostics_file.read_text(encoding="utf-8")) if diagnostics_file.exists() else {}
        record["anatomical"] = {
            "term": inputs["anatomical_term"], "weight": settings_a["weight"], "in_objective": in_objective,
            "censoring": censoring,
            "D2_target_normalised": diagnostics.get("D2_anatomical_target_normalised"),
            "D2_by_censoring": diagnostics.get("D2_anatomical_by_censoring"),
            "annotated_landing": fractions,
            "landing_matches_anatomical_diagnostics": (
                None if "annotated_tissue_landing" not in diagnostics else
                max(abs(fractions[k] - diagnostics["annotated_tissue_landing"][k]) for k in fractions) < 1e-6),
            "mass_mm2": {"atlas_MTG_start": float((w0 * zeta_mtg).sum()), "atlas_MTG_end": float((w1 * zeta_mtg).sum()),
                         "atlas_MTG_counted_start (w*zeta*censor)": float((w0 * zeta_mtg * mask_start).sum()),
                         "atlas_MTG_counted_end (w*zeta*censor)": float((w1 * zeta_mtg * mask_end).sum()),
                         "atlas_MTG_outside_annotation_end (w*zeta*(1-A))": float((w1 * zeta_mtg * (1 - A_end)).sum()),
                         "target_annotated": float(annotated.sum()),
                         "annotation_mask_area (integral of A)": float(A.sum() * step * step)},
            "feature_maps": {"source": f"fixed projection {settings_a['source_projection']!r}",
                             "matrix": projection_matrix(settings_a["source_projection"], names)[1].tolist(),
                             "pi": "fixed [[1]] (MTG gray -> annotated MTG cortex), not optimised"},
            "mask": {"type": "SmoothedIndicatorField", "sigma_mm": settings_a["annotation_sigma_mm"],
                     "applied_to_atlas": censoring == "annotation"},
        }

    payload["record"] = record
    payload["summary_lines"] = _qc_summary_lines(record)
    return payload


QC_CHANNELS = ("STG_gray_matter", "MTG_gray_matter", "ITG_gray_matter", "other_gray_matter", "white_matter")


def _qc_summary_lines(record: dict) -> list[str]:
    fmt = lambda v: "n/a" if v is None else (f"{v:.4g}" if isinstance(v, float) else str(v))
    lines = []
    init = record["initial_transform"]
    sim = init.get("qnp_to_plane_similarity") or {}
    lines.append(f"INITIAL  QNP->plane (rigid scan): theta {fmt(sim.get('theta_deg'))} deg, scale {fmt(sim.get('scale'))}, "
                 f"flip {sim.get('flip')};  xIV init {init['xiv_initialization']} M={init['xiv_initialization_matrix_M']}")
    fit = record["optimised_transform_fit"]
    lines.append(f"FLOW     {' -> '.join(record['stages'])}: scale {fit['scale']:.4f}, rotation {fit['rotation_deg']:.2f} deg, "
                 f"translation ({fit['translation_mm'][0]:.2f}, {fit['translation_mm'][1]:.2f}) mm, reflection "
                 f"{fit['reflection']}, non-similarity residual rms {fit['residual_rms_mm']:.3f} / max "
                 f"{fit['residual_max_mm']:.3f} mm")
    losses = record["losses"]
    native = losses.get("native_weighted") or {}
    lines.append("LOSSES   weighted: " + ", ".join(f"{k} {v:.4g}" for k, v in native.items()))
    components = losses.get("components_unweighted")
    if components:
        for stage in components["stages"]:
            lines.append(f"         unweighted D2 ({stage['transform']}): start " +
                         ", ".join(f"{k} {v:.4g}" for k, v in stage["start"].items()) + " | end " +
                         ", ".join(f"{k} {v:.4g}" for k, v in stage["end"].items()))
    lines.append(f"SCORES   tissue {fmt(losses.get('score_total_mass'))}, gray/white {fmt(losses.get('score_classes'))}")
    stops = record.get("optimizer_stops")
    if stops:
        lines.append("STOP     " + "; ".join(f"{st.get('transform')}: {st.get('kind', 'n/a')} at iteration {st.get('iteration', 'n/a')}"
                                          for st in stops))
    mass = record["structural_mass_mm2"]
    lines.append(f"STRUCT   atlas {mass['atlas_start']:.1f} -> {mass['atlas_end']:.1f} mm2; counted w*s "
                 f"{mass['atlas_counted_start (w*s)']:.1f} -> {mass['atlas_counted_end (w*s)']:.1f}; target "
                 f"{mass['target']:.1f}; support>0.5 on {mass['particles_support_above_0.5_end']:.0%} of particles")
    maps = record["feature_maps"]
    lines.append(f"         source features: {maps['structural_source_features']}")
    lines.append(f"         pi_ST^2 {maps['structural_pi_ST_status']}: initial "
                 f"{np.round(maps['structural_pi_ST_initial'], 3).tolist()} -> final "
                 f"{np.round(maps['structural_pi_ST_squared'], 3).tolist()}")
    anatomical = record.get("anatomical")
    if anatomical is None:
        lines.append("ANAT     no anatomical masses in these archives")
    else:
        d2 = anatomical.get("D2_target_normalised") or {}
        am = anatomical["mass_mm2"]
        lines.append(f"ANAT     {anatomical['term']}; weight {anatomical['weight']}; censoring {anatomical['censoring']}")
        both = anatomical.get("D2_by_censoring") or {}
        for mode in ("annotation", "none"):
            v = both.get(mode)
            if v:
                lines.append(f"         D2 {'censored  ' if mode == 'annotation' else 'uncensored'} start {v['start']:.4g} -> end "
                             f"{v['end']:.4g}; relative (D2 / complete miss, s-free) {v['relative_start']:.3f} -> "
                             f"{v['relative_end']:.3f}" + ("   <- in objective" if mode == anatomical['censoring']
                                                           and anatomical['in_objective'] else ""))
        if not both:
            lines.append(f"         D2 (censored, target-normalised) start {fmt(d2.get('start'))} -> end {fmt(d2.get('end'))} "
                         f"(complete miss {fmt(d2.get('complete_miss'))})")
        lines.append(f"         atlas MTG {am['atlas_MTG_start']:.1f} -> {am['atlas_MTG_end']:.1f} mm2; counted by the term "
                     f"{am['atlas_MTG_counted_start (w*zeta*censor)']:.1f} -> {am['atlas_MTG_counted_end (w*zeta*censor)']:.1f}; "
                     f"outside annotation at end {am['atlas_MTG_outside_annotation_end (w*zeta*(1-A))']:.1f}; annotated target "
                     f"{am['target_annotated']:.1f}; annotation area {am['annotation_mask_area (integral of A)']:.1f}")
        landing = anatomical["annotated_landing"]
        lines.append("         annotated tissue lands on: " + ", ".join(
            f"{k.replace('_gray_matter', '').replace('_', ' ')} {v:.1%}" for k, v in landing.items() if v > 0))
        lines.append(f"         source {anatomical['feature_maps']['source']} {anatomical['feature_maps']['matrix']}; "
                     f"pi {anatomical['feature_maps']['pi']}; mask {anatomical['mask']['type']} sigma "
                     f"{anatomical['mask']['sigma_mm']} mm")
    nonlinear = record["nonlinear"]
    if isinstance(nonlinear, dict):
        ratio = nonlinear.get("mass_ratio_proxy_supported") or {}
        lines.append(f"NONLIN   atlas mass-ratio proxy (supported) p5/p50/p95 {fmt(ratio.get('p5'))}/{fmt(ratio.get('p50'))}/"
                     f"{fmt(ratio.get('p95'))}; hull area ratio {fmt(nonlinear.get('hull_area_ratio_supported'))}")
    else:
        lines.append(f"NONLIN   {nonlinear}")
    return lines


def write_registration_qc(api, built: dict, inputs: dict, fit_dir: Path, device, dtype, title: str = "") -> None:
    """``registration_qc.png`` and ``registration_qc.json`` for a finished fit; a failure only warns."""

    import warnings

    from scripts.view_xiv_trajectory import registration_qc_figure

    try:
        payload = registration_qc_payload(api, built, inputs, fit_dir, device, dtype, title=title)
        (fit_dir / "registration_qc.json").write_text(json.dumps(payload["record"], indent=2, default=float) + "\n",
                                                      encoding="utf-8")
        figure = registration_qc_figure(payload)
        figure.savefig(fit_dir / "registration_qc.png", dpi=130, bbox_inches="tight")
        plt.close(figure)
    except Exception as error:  # noqa: BLE001 - QC output must not discard a finished fit
        warnings.warn(f"registration QC not written: {error!r}")


def summarize(output_root: Path) -> None:
    """Rebuild initializations.csv and summary.json from every finished start."""

    rows = []
    for marker in sorted(output_root.glob("init_*/COMPLETED.json")):
        result = json.loads(marker.read_text(encoding="utf-8"))
        rows.append({"directory": marker.parent.name, **{k: result[k] for k in (
            "initialization", "steps", "level1_passed", "score_total_mass", "score_classes", "native_total_loss")},
            "numeric_flags": "; ".join(result["numeric_flags"])})
    if not rows:
        return
    with open(output_root / "initializations.csv", "w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    ranked = sorted((r for r in rows if r["level1_passed"]),
                    key=lambda r: (r["score_total_mass"], r["score_classes"] if r["score_classes"] is not None else 0))
    summary = {"ranking_score": "score_total_mass (ties: score_classes); native losses are not comparable",
               "best": ranked[0] if ranked else None, "number_finished": len(rows)}
    (output_root / "summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")


def main() -> None:
    args = parse_args()
    config = load_config(args.config)
    record = _registration_record(config, args.registration)
    record["_name"] = args.registration
    model = dict(record["model"])

    seed = int(model.get("seed", 0))
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    api = load_xmodmap(config)  # xmodmap sets the default tensor type on import
    plan = stage_plan(api, model, args.steps)
    dtype = _torch_dtype(str(model.get("torch_dtype", "float32")))
    device = torch.device(str(model.get("device", "cpu")))
    default_device = torch.empty(0).device
    if device.type != default_device.type:
        raise RuntimeError(f"model.device={device} but xmodmap made {default_device} the default; its "
                           "internal allocations would land on a different device.")

    output_root = resolve_path(config, record["output_dir"])
    output_root.mkdir(parents=True, exist_ok=True)
    write_resolved_config(config, output_root / "resolved_project_config.json")
    inputs = load_inputs(config, record)
    manifest = {"source_particles": str(inputs["source_file"]), "target_particles": str(inputs["target_file"]),
                "target_feature_mode": inputs["mode"], "source_metadata": inputs["source_meta"],
                "source_feature_projection": inputs["source_feature_projection"], "source_feature_names": inputs["source_names"],
                "anatomical_supervision": {"term": inputs["anatomical_term"], **inputs["anatomical_settings"]},
                "structural_feature_map": inputs["structural_feature_map"],
                "target_metadata": inputs["target_meta"]}
    (output_root / "input_manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")

    if args.stage == "support-check":
        built = build_model(api, inputs, model, record["reference_initialization"], device, dtype)
        report = support_check(built, output_root)
        print(json.dumps(report, indent=2))
        if report["failures"]:
            raise SystemExit(f"Support check failed: {report['failures']}")
        return

    if args.stage == "qc":
        inits = [args.init] if args.init else [p.parent.name[len("init_"):] for p in
                                               sorted(output_root.glob("init_*/COMPLETED.json"))]
        for init_id in inits:
            fit_dir = output_root / f"init_{init_id}"
            stage_ids = json.loads((fit_dir / "COMPLETED.json").read_text(encoding="utf-8"))["stages"]
            built = build_model(api, inputs, model, init_id.split("_steps")[0], device, dtype)
            write_registration_qc(api, built, inputs, fit_dir, device, dtype,
                                  title=f"{args.registration}  {init_id}  ({' -> '.join(TRANSFORM_LABELS.get(t, t) for t in stage_ids)})")
            print(f"Wrote {fit_dir / 'registration_qc.png'}")
        return

    inits = record["initializations"] if args.stage == "multistart" else [args.init or record["reference_initialization"]]
    if not (output_root / "support_check.json").is_file() or json.loads(
            (output_root / "support_check.json").read_text(encoding="utf-8"))["failures"]:
        raise SystemExit("Run --stage support-check first (and make it pass).")
    for init_id in inits:
        suffix = "" if args.steps is None else f"_steps{args.steps}"
        output_dir = output_root / f"init_{init_id}{suffix}"
        if (output_dir / "COMPLETED.json").exists() and not args.overwrite:
            print(f"Skipping completed {output_dir}")
            continue
        if output_dir.exists():
            shutil.rmtree(output_dir)
        output_dir.mkdir(parents=True)
        (output_dir / "input_manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
        result = fit_initialization(api, config, record, inputs, model, init_id, plan, output_dir, device, dtype)
        print(json.dumps(result, indent=2))
    summarize(output_root)


if __name__ == "__main__":
    main()
