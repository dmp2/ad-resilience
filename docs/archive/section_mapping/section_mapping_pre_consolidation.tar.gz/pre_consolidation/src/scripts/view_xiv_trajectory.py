#!/usr/bin/env python3
"""View an xIV fit's forward flow with xmodmap's own viewers (source | target | deformed).

Reads ``trajectory.pt`` written by ``framework_script_AtlasToSectionCrossModalBoundary.py``
(positions in mm, initialized target frame; frames run through every stage).

Viewers
-------
``3d`` (default)  ``xmodmap.plot.plot_registration_3d`` (pyvista), as in the upstream
                  examples: time slider, a "target" overlay toggle and a "map by pi_ST"
                  toggle that colours the source by its mapped features.  2-D data are
                  drawn in the z = 0 plane.
``2d``            ``xmodmap.plot.plot_registration_2d`` (matplotlib): time slider only.

Particles are coloured by argmax feature and sized by weight.  With ``--save DIR``
nothing opens: the viewer is rendered off-screen at ``--times`` (fractions of the whole
flow) to ``DIR/registration_t<t>[_pi].png``, using upstream's own slider and toggle.

Usage::

    PYTHONPATH=src:src/config_setup python src/scripts/view_xiv_trajectory.py \
        results/registrations/<registration>/init_r000_f0 [--viewer 2d] [--save DIR]
"""

from __future__ import annotations

import argparse
import importlib.util
from pathlib import Path
from typing import Any

import numpy as np
import torch

from config_setup.project_config import load_config
from preprocess.xmodmap_compat import load_xmodmap

MEASURES = ("S", "w_S", "zeta_S", "T", "w_T", "zeta_T")
# Categorical slots 1-8 (fixed order) for the 2-D figure's feature classes.
CLASS_COLORS = ("#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#6250d6", "#e34948")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("fit_dir", type=Path, help="An init_* directory containing trajectory.pt.")
    parser.add_argument("--config", default="configs/project_config.yaml", help="Project YAML (selects xmodmap).")
    parser.add_argument("--viewer", choices=["2d", "3d"], default="3d")
    parser.add_argument("--save", type=Path, help="Write PNGs here instead of opening a window.")
    parser.add_argument("--times", type=float, nargs="+", default=[0.0, 0.5, 1.0],
                        help="Flow fractions to save with --save.")
    parser.add_argument("--pi", action="store_true", help="With --save and the 3d viewer: also save pi_ST-mapped colours.")
    return parser.parse_args()


def write_trajectory(path: Path, measures: dict[str, Any], frames: list, *, pi_ST=None, stages=("affine+diffeo",),
                     frame_stage=None, units: str = "mm", source_names=None, target_names=None,
                     axis_labels=("x (mm)", "y (mm)"), panel_titles=("Template", "Target", "Deformed template")) -> None:
    """Save a forward flow for these viewers.

    ``measures`` holds S, w_S, zeta_S, T, w_T and zeta_T (tensors), and ``frames`` is a
    list of (positions, weights), one per time step, in the same units. Names and
    labels are used only by the figures.
    """

    cpu = lambda x: x.detach().cpu() if torch.is_tensor(x) else x
    torch.save({**{k: cpu(measures[k]) for k in MEASURES},
                "frames": [(cpu(q), cpu(w)) for q, w in frames], "pi_ST": cpu(pi_ST),
                "frame_stage": list(frame_stage) if frame_stage is not None else [0] * len(frames),
                "stages": list(stages), "units": units,
                "source_names": list(source_names) if source_names is not None else None,
                "target_names": list(target_names) if target_names is not None else None,
                "axis_labels": list(axis_labels), "panel_titles": list(panel_titles)}, path)


def load_trajectory(path: Path) -> dict[str, Any]:
    data = torch.load(path, weights_only=False, map_location="cpu")
    # xmodmap's viewers read qx / qw at positions 2 and 3 of each Shooting state.
    data["trajectory"] = [(None, None, q, w) for q, w in data["frames"]]
    return data


def has_pyvista() -> bool:
    return importlib.util.find_spec("pyvista") is not None


def render_registration(xmodmap, data: dict, out_dir: Path, times=(1.0,), viewer: str = "3d",
                        mapped: bool = False) -> list[Path]:
    """Save upstream's source | target | deformed view at flow fractions ``times``.

    The 3-D viewer is rendered off-screen and driven through its own slider and
    "map by pi_ST" checkbox, so each PNG is what the interactive window shows.
    ``mapped`` is ignored when the fit has no pi_ST (single modality).
    """

    out_dir.mkdir(parents=True, exist_ok=True)
    measures = [data[k] for k in MEASURES]
    trajectory = data["trajectory"]
    last = len(trajectory) - 1
    frame = lambda t: int(round(min(max(float(t), 0.0), 1.0) * last))
    written = []
    mapped = mapped and data.get("pi_ST") is not None
    if viewer == "3d":
        import pyvista as pv
        import vtk

        off_screen, pv.OFF_SCREEN = pv.OFF_SCREEN, True
        try:
            plotter = xmodmap.plot.plot_registration_3d(*measures, trajectory, pi_ST=data["pi_ST"],
                                                        show=False, window_size=(1800, 600))
            widgets = getattr(plotter, "widgets", plotter)  # pyvista >= 0.47 groups widgets here
            slider = widgets.slider_widgets[0] if widgets.slider_widgets else None
            for colours in ([False, True] if mapped else [False]):
                if mapped:
                    pi_toggle = widgets.button_widgets[1]  # [0] is the target overlay
                    pi_toggle.GetRepresentation().SetState(int(colours))
                    pi_toggle.InvokeEvent(vtk.vtkCommand.StateChangedEvent)
                for t in times:
                    if slider is not None:
                        slider.GetRepresentation().SetValue(frame(t))
                        slider.InvokeEvent(vtk.vtkCommand.InteractionEvent)
                    path = out_dir / f"registration_t{t:.2f}{'_pi' if colours else ''}.png"
                    plotter.screenshot(str(path))
                    written.append(path)
            plotter.close()
        finally:
            pv.OFF_SCREEN = off_screen
        return written

    import matplotlib.pyplot as plt

    for t in times:
        path = out_dir / f"registration_t{t:.2f}.png"
        figure = registration_figure_2d(xmodmap, data, frame(t), t)
        figure.savefig(path, dpi=150, bbox_inches="tight")
        plt.close(figure)
        written.append(path)
    return written


def _target_outline(T: np.ndarray, w_T: np.ndarray, axis, spacing_mm: float = 0.25):
    """Contour where the target's footprint (rigid-scan definition, 0.5 mm) falls to 0.5."""

    from preprocess.section_alignment import FootprintScorer

    scorer = FootprintScorer(T, w_T.reshape(-1, 1), footprint_sigma_mm=0.5)
    lo, hi = T.min(0) - 2.0, T.max(0) + 2.0
    gx, gy = np.meshgrid(np.arange(lo[0], hi[0], spacing_mm), np.arange(lo[1], hi[1], spacing_mm))
    weight = scorer.footprint(np.column_stack([gx.ravel(), gy.ravel()])).reshape(gx.shape)
    return axis.contour(gx, gy, weight, levels=[0.5], colors="#1a1a19", linewidths=0.8)


def registration_figure_2d(xmodmap, data: dict, k: int, t: float):
    """Upstream's 2-D source | target | deformed figure at frame ``k``, with labelled axes.

    Particles are discs sized by weight and coloured by their own argmax feature. The
    deformed panel adds the target's outline.
    """

    from matplotlib.colors import ListedColormap
    from matplotlib.lines import Line2D
    from matplotlib.patches import Patch

    measures = [data[k_] for k_ in MEASURES]
    source_names = data.get("source_names") or [f"feature {i}" for i in range(data["zeta_S"].shape[-1])]
    target_names = data.get("target_names") or [f"feature {i}" for i in range(data["zeta_T"].shape[-1])]
    n_classes = max(len(source_names), len(target_names))
    cmap = ListedColormap(CLASS_COLORS[:n_classes]) if n_classes <= len(CLASS_COLORS) else "tab10"
    figure = xmodmap.plot.plot_registration_2d(*measures, data["trajectory"], cmap=cmap, figsize=(15, 5.4),
                                               show=False)
    axes = figure.axes[:3]
    if hasattr(figure, "_slider"):
        figure._slider.set_val(k)
        figure._slider.ax.set_visible(False)
    xlabel, ylabel = data.get("axis_labels") or ("x (mm)", "y (mm)")
    titles = list(data.get("panel_titles") or ("Template", "Target", "Deformed template"))
    if t < 1.0:
        titles[2] = f"{titles[2]}, t = {t:.2f}"
    for axis, title in zip(axes, titles):
        axis.set_title(title, fontsize=11)
        axis.set_xlabel(xlabel)
    axes[0].set_ylabel(ylabel)
    T, w_T = (np.asarray(data[key].detach().cpu() if torch.is_tensor(data[key]) else data[key]) for key in ("T", "w_T"))
    _target_outline(T[:, :2], w_T, axes[2])

    patches = lambda names: [Patch(color=CLASS_COLORS[i % len(CLASS_COLORS)], label=n) for i, n in enumerate(names)]
    outline = Line2D([], [], color="#1a1a19", linewidth=0.8, label="target outline")
    if source_names == target_names:
        axes[2].legend(handles=patches(source_names) + [outline], loc="upper right", fontsize=8, frameon=False)
    else:
        axes[0].legend(handles=patches(source_names), loc="upper right", fontsize=8, frameon=False)
        axes[1].legend(handles=patches(target_names), loc="upper right", fontsize=8, frameon=False)
        axes[2].legend(handles=[outline], loc="upper right", fontsize=8, frameon=False)
    figure.subplots_adjust(bottom=0.12)
    return figure


# --------------------------------------------------------------------------------------
# Multi-term registration QC (structural + anatomical rows, supports, summary)
# --------------------------------------------------------------------------------------

# One colour per meaning across the whole QC figure.  The gyral hues are the first three
# categorical slots (they validate all-pairs) and match scan_atlas_planes_for_qnp's
# ANATOMY_COLORS; other gray / white matter are neutrals.  The structural row draws gray /
# white in neutrals so no hue means two things.
QC_ANATOMY_COLORS = {"STG_gray_matter": "#eb6834", "MTG_gray_matter": "#2a78d6", "ITG_gray_matter": "#1baf7a",
                     "other_gray_matter": "#e6e4dc", "white_matter": "#c4c2b9"}
QC_STRUCTURAL_COLORS = {"gray_matter": "#55544e", "white_matter": "#c4c2b9"}
QC_INK, QC_MUTED, QC_RING = "#1a1a19", "#6b6a64", "#9a988f"
QC_MASK_COLOR = "#104281"  # darkest blue step: the annotation-mask contour (A = 1/2)
QC_OUTSIDE = "#e34948"     # landing outside the atlas plane
# legends sit over particles in wide fields of view: a light, borderless backing keeps them legible
QC_LEGEND = {"frameon": True, "facecolor": "white", "edgecolor": "none", "framealpha": 0.85}


def _qc_discs(axis, points, weights, radius_scale, facecolors="none", edgecolors="none", alpha=0.8,
              linewidth=0.5, zorder=2):
    """Discs of area proportional to mass (xmodmap.plot.utils.weight_to_radius), like the 2-D viewer."""

    from matplotlib.collections import EllipseCollection
    from xmodmap.plot.utils import weight_to_radius  # type: ignore

    diameter = 2 * weight_to_radius(weights, radius_scale)
    collection = EllipseCollection(diameter, diameter, np.zeros_like(diameter), offsets=points, units="xy",
                                   offset_transform=axis.transData, facecolors=facecolors, edgecolors=edgecolors,
                                   linewidths=linewidth, alpha=alpha, zorder=zorder)
    axis.add_collection(collection)
    return collection


def _colors_by_argmax(features: np.ndarray, names: list[str], palette: dict[str, str]) -> list[str]:
    index = np.asarray(features).argmax(axis=1)
    return [palette.get(names[i], QC_MUTED) for i in index]


def registration_qc_figure(payload: dict):
    """Structural | anatomical | support rows over source, target and transformed source, plus a summary.

    ``payload`` comes from ``framework_script_AtlasToSectionCrossModalBoundary.registration_qc_payload``:
    every position, mass and weight is a saved model output or a model loss's own field evaluated
    at the saved positions.  All spatial panels share one frame (mm, initialized target frame),
    one axis range and one mass-to-disc-area scale.
    """

    import matplotlib.pyplot as plt
    from matplotlib.lines import Line2D
    from matplotlib.patches import Patch
    from xmodmap.plot.utils import default_radius_scale  # type: ignore

    p = payload
    S0, S1, T = p["source_start"], p["source_end"], p["target"]
    w0, w1, wT = p["w_source_start"], p["w_source_end"], p["w_target"]
    anatomical = p.get("anatomical")
    rows = 4
    figure = plt.figure(figsize=(17, 4.6 * rows), constrained_layout=True)
    grid = figure.add_gridspec(rows, 3, height_ratios=[1, 1, 1, 0.95])
    first = figure.add_subplot(grid[0, 0])
    spatial = [[first if (r, c) == (0, 0) else figure.add_subplot(grid[r, c], sharex=first, sharey=first)
                for c in range(3)] for r in range(3)]
    radius_scale = default_radius_scale([S0, S1, T], [w0, w1, wT])
    points = np.concatenate([S0, S1, T])
    lo, hi = points.min(0), points.max(0)
    pad = 0.04 * float((hi - lo).max())
    xlabel, ylabel = p.get("axis_labels") or ("x (mm)", "y (mm)")
    for r, row in enumerate(spatial):
        for c, axis in enumerate(row):
            axis.set_aspect("equal")
            axis.set_xlim(lo[0] - pad, hi[0] + pad)
            axis.set_ylim(lo[1] - pad, hi[1] + pad)
            axis.tick_params(labelsize=8, colors=QC_MUTED)
            for side in ("top", "right"):
                axis.spines[side].set_visible(False)
            if r == 2:
                axis.set_xlabel(xlabel, fontsize=9)
            if c == 0:
                axis.set_ylabel(ylabel, fontsize=9)

    def outline(axis):
        _target_outline(T, wT, axis)

    def mask_contour(axis):
        if anatomical is not None and anatomical.get("mask_grid") is not None:
            gx, gy, A = anatomical["mask_grid"]
            axis.contour(gx, gy, A, levels=[0.5], colors=QC_MASK_COLOR, linewidths=1.2, linestyles="--", zorder=4)

    tissue_line = Line2D([], [], color=QC_INK, linewidth=0.8, label="target tissue outline")
    mask_line = Line2D([], [], color=QC_MASK_COLOR, linewidth=1.2, linestyle="--", label="annotation mask A = 1/2")
    ring = Line2D([], [], marker="o", linestyle="none", markerfacecolor="none", markeredgecolor=QC_RING,
                  label="particle not counted (ring)")

    # ---- row 1: structural features (the gray/white source of the structural term) ----
    s_names = p["structural_source_names"]
    t_names = p["structural_target_names"]
    s_col = _colors_by_argmax(p["zeta_source"], s_names, QC_STRUCTURAL_COLORS)
    t_col = _colors_by_argmax(p["zeta_target"], t_names, QC_STRUCTURAL_COLORS)
    a = spatial[0]
    _qc_discs(a[0], S0, w0, radius_scale, facecolors=s_col)
    _qc_discs(a[1], T, wT, radius_scale, facecolors=t_col)
    _qc_discs(a[2], S1, w1, radius_scale, facecolors=s_col)
    outline(a[2])
    a[0].set_title("Atlas plane (source), t = 0: gray / white", fontsize=10)
    a[1].set_title("QNP section (target): gray / white", fontsize=10)
    a[2].set_title(f"Transformed atlas ({p['transform_label']}) on target outline", fontsize=10)
    handles = [Patch(color=QC_STRUCTURAL_COLORS.get(n, QC_MUTED), label=n.replace("_", " ")) for n in s_names]
    a[2].legend(handles=handles + [tissue_line], loc="upper right", fontsize=7, **QC_LEGEND)
    a[0].text(0.01, 0.01, "disc area = particle mass (same scale in every panel)", transform=a[0].transAxes,
              fontsize=7, color=QC_MUTED)

    # ---- row 2: anatomical channels and the HALO annotation ----
    a = spatial[1]
    channels = p.get("atlas_channels")
    if channels is None:
        for axis in (a[0], a[2]):
            axis.text(0.5, 0.5, "no anatomical channels (nu_Anat) in the source", ha="center", va="center",
                      transform=axis.transAxes, color=QC_MUTED)
    else:
        names = channels["names"]
        colors = _colors_by_argmax(channels["values"], names, QC_ANATOMY_COLORS)
        _qc_discs(a[0], S0, w0, radius_scale, facecolors=colors, alpha=0.9)
        _qc_discs(a[2], S1, w1, radius_scale, facecolors=colors, alpha=0.9)
        outline(a[2])
        a[0].set_title("Atlas plane: anatomical channels (nu_Anat)", fontsize=10)
        a[0].legend(handles=[Patch(color=QC_ANATOMY_COLORS[n], label=n.replace("_", " ")) for n in names],
                    loc="upper right", fontsize=7, **QC_LEGEND)
        a[2].set_title("Transformed atlas, anatomical colours" + (", with annotation mask" if anatomical else ""),
                       fontsize=10)
        a[2].legend(handles=[tissue_line] + ([mask_line] if anatomical else []), loc="upper right", fontsize=7,
                    **QC_LEGEND)
    if anatomical is None:
        a[1].text(0.5, 0.5, "no HALO annotation (nu_Annot) in the target", ha="center", va="center",
                  transform=a[1].transAxes, color=QC_MUTED)
    else:
        annotated = anatomical["target_annotated"]
        known = annotated > 0
        _qc_discs(a[1], T, wT, radius_scale, edgecolors=QC_RING)  # all tissue, as rings
        _qc_discs(a[1], T[known], annotated[known], radius_scale, facecolors=QC_ANATOMY_COLORS["MTG_gray_matter"],
                  alpha=0.9, zorder=3)
        outline(a[1])
        mask_contour(a[1])
        mask_contour(a[2])
        a[1].set_title(f"Target: HALO MTG annotation (filled = annotated area; ring = tissue,\n"
                       f"unannotated = unknown) {anatomical['annotated_fraction']:.0%} of tissue", fontsize=10)
        a[1].legend(handles=[Patch(color=QC_ANATOMY_COLORS["MTG_gray_matter"], label="annotated (positive)"), ring,
                             tissue_line, mask_line], loc="upper right", fontsize=7, **QC_LEGEND)

    # ---- row 3: what each term actually counts, and where the annotation lands ----
    a = spatial[2]
    support = p["structural_support_end"]
    _qc_discs(a[0], S1, w1, radius_scale, edgecolors=QC_RING, linewidth=0.3, alpha=0.6)
    _qc_discs(a[0], S1, w1 * support, radius_scale, facecolors=s_col, zorder=3)
    outline(a[0])
    a[0].set_title(f"Structural term counts w*s(x) (tissue support)\n"
                   f"{(w1 * support).sum():.0f} of {w1.sum():.0f} mm2 atlas", fontsize=10)
    a[0].legend(handles=[ring, tissue_line], loc="upper right", fontsize=7, **QC_LEGEND)
    if anatomical is None:
        for axis in a[1:]:
            axis.text(0.5, 0.5, "no anatomical term", ha="center", va="center", transform=axis.transAxes,
                      color=QC_MUTED)
    else:
        mtg = w1 * anatomical["zeta_mtg"]
        counted = mtg * anatomical["mask_end"]
        censored = anatomical.get("censoring", "annotation") == "annotation"
        _qc_discs(a[1], S1, w1, radius_scale, edgecolors=QC_RING, linewidth=0.3, alpha=0.6)
        _qc_discs(a[1], S1, counted, radius_scale, facecolors=QC_ANATOMY_COLORS["MTG_gray_matter"], zorder=3)
        outline(a[1])
        mask_contour(a[1])
        state = "in objective" if anatomical["in_objective"] else "NOT in objective, weight 0"
        if censored:
            title = f"Anatomical term counts w*zeta_MTG*A(x) ({state})"
            legend = [ring, tissue_line, mask_line]
        else:
            outside = (mtg * (1 - anatomical["annotation_at_end"])).sum()
            title = f"Anatomical term counts all atlas MTG, uncensored ({state});\n{outside:.0f} mm2 of it lies outside the annotation"
            legend = [ring, tissue_line,
                      Line2D([], [], color=QC_MASK_COLOR, linewidth=1.2, linestyle="--",
                             label="annotation A = 1/2 (target measure; not applied to atlas)")]
        a[1].set_title(f"{title}\n{counted.sum():.0f} of {mtg.sum():.0f} mm2 atlas MTG counted; target "
                       f"{anatomical['target_annotated'].sum():.0f} mm2", fontsize=10)
        a[1].legend(handles=legend, loc="upper right", fontsize=7, **QC_LEGEND)
        landing = anatomical["landing_label"]
        landing_names = anatomical["channel_names"] + ["outside_atlas_plane"]
        palette = dict(QC_ANATOMY_COLORS, outside_atlas_plane=QC_OUTSIDE)
        _qc_discs(a[2], T[~known], wT[~known], radius_scale, edgecolors=QC_RING, linewidth=0.3, alpha=0.6)
        _qc_discs(a[2], T[known], annotated[known], radius_scale,
                  facecolors=[palette[landing_names[k]] for k in landing[known]], alpha=0.95, zorder=3)
        outline(a[2])
        fractions = anatomical["annotated_landing"]
        a[2].set_title(f"Annotated tissue coloured by the atlas channel it lands on\n"
                       f"MTG {fractions.get('MTG_gray_matter', 0):.1%}", fontsize=10)
        shown = [n for n in landing_names if fractions.get(n, 0) > 0]
        a[2].legend(handles=[Patch(color=palette[n], label=f"{n.replace('_', ' ')} {fractions[n]:.1%}") for n in shown],
                    loc="upper right", fontsize=7, **QC_LEGEND)

    # ---- row 4: feature maps and the numbers ----
    bottom = grid[3, :].subgridspec(1, 2, width_ratios=[1, 4.2])
    pi_axis = figure.add_subplot(bottom[0, 0])
    pi = np.asarray(p["pi_structural"])
    pi_axis.imshow(pi, cmap="Greys", vmin=0, vmax=max(1.0, float(pi.max())))
    for (i, j), value in np.ndenumerate(pi):
        pi_axis.text(j, i, f"{value:.3f}", ha="center", va="center", fontsize=10,
                     color="white" if value > 0.6 * max(1.0, float(pi.max())) else QC_INK)
    pi_axis.set_xticks(range(len(t_names)), [n.replace("_", " ") for n in t_names], fontsize=8)
    pi_axis.set_yticks(range(len(s_names)), [n.replace("_", " ") for n in s_names], fontsize=8)
    pi_axis.set_xlabel("target feature", fontsize=8)
    pi_axis.set_ylabel("atlas feature (after projection)", fontsize=8)
    pi_axis.set_title(f"Feature maps\nstructural pi_ST (squared): {p['pi_structural_status']}", fontsize=9)
    if anatomical is not None:
        pi_axis.set_xlabel("target feature\n\nanatomical map: atlas MTG gray -> HALO MTG annotation,\nfixed [[1]] (I_1), "
                           "not learned", fontsize=8)
    text_axis = figure.add_subplot(bottom[0, 1])
    text_axis.axis("off")
    import textwrap
    wrapped = [part for line in p["summary_lines"]
               for part in textwrap.wrap(line, width=150, subsequent_indent=" " * 9) or [""]]
    text_axis.text(0.0, 1.0, "\n".join(wrapped), va="top", ha="left", family="monospace", fontsize=7.5,
                   color=QC_INK, transform=text_axis.transAxes)
    figure.suptitle(p.get("title", "Registration QC"), fontsize=12)
    return figure


def main() -> None:
    args = parse_args()
    if args.save is not None:
        import matplotlib
        matplotlib.use("Agg")
    load_xmodmap(load_config(args.config))
    import xmodmap.plot  # type: ignore

    data = load_trajectory(args.fit_dir / "trajectory.pt")
    if args.save is not None:
        written = render_registration(xmodmap, data, args.save, args.times, args.viewer, mapped=args.pi)
        print(f"Wrote {len(written)} images to {args.save}")
    elif args.viewer == "3d":
        xmodmap.plot.plot_registration_3d(*[data[k] for k in MEASURES], data["trajectory"], pi_ST=data["pi_ST"])
    else:
        xmodmap.plot.plot_registration_2d(*[data[k] for k in MEASURES], data["trajectory"])


if __name__ == "__main__":
    main()
