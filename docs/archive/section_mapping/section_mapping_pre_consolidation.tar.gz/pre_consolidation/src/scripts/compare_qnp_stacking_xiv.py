"""Cross-donor comparison for estimate_qnp_stacking_xiv.py (``--stage compare --jobs A B --out DIR``).

Reads each job's ``report.json`` and fit results only; fits nothing.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import numpy as np

CONDITIONS = ("baseline", "supervised")
COND_COLORS = {"baseline": "#5f5e5a", "supervised": "#2a78d6"}


def compare(config: dict, jobs: list[str], out: Path) -> dict[str, Any]:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    import estimate_qnp_stacking_xiv as E

    out.mkdir(parents=True, exist_ok=True)
    reports, contexts = {}, {}
    for job in jobs:
        ctx = E.Context(config, job)
        contexts[job] = ctx
        reports[job] = json.loads((ctx.out / "report.json").read_text())
    rows = []
    for job, full in reports.items():
      for variant, rep in full["variants"].items():
        for s, entry in rep["sections"].items():
            for cond in CONDITIONS:
                c = entry["conditions"].get(cond)
                if not c:
                    continue
                b = c["best"]
                rows.append({"job": job, "variant": variant, "section": s, "annotation": entry["annotation"], "condition": cond,
                             "objective": c["objective"], "ranking": c["ranking_score"], "best_y_mm": b["y_mm"],
                             "window": c["window"]["window_y"], "delta": c["delta"], "R_struct": b["R_struct"],
                             "R_anat": b["R_anat"], "scale": b["fit_scale"], "own_annot_on_MTG": b["own_annotation_on_MTG"],
                             "ref_annot_on_MTG": b["reference_annotation_on_MTG"],
                             "competing": [(m["y_mm"], None if m["gap_in_delta"] is None else round(m["gap_in_delta"], 1))
                                           for m in c["competing_minima"][1:]]})
    summary = {"jobs": jobs, "rows": rows, "consistency": {j: {v: r["consistency"] for v, r in full["variants"].items()}
                                                        for j, full in reports.items()}}
    (out / "comparison.json").write_text(json.dumps(summary, indent=2, default=float) + "\n", encoding="utf-8")

    # One figure: per donor, every anchor's ranking-score profile in both conditions (relative to its best).
    fig, axes = plt.subplots(len(jobs), 2, figsize=(14, 3.6 * len(jobs)), squeeze=False, constrained_layout=True)
    for i, job in enumerate(jobs):
        ctx = contexts[job]
        fits = E.load_fits(ctx)
        for j, cond in enumerate(CONDITIONS):
            ax = axes[i, j]
            for k, s in enumerate(ctx.anchors()):
                run = cond if cond in E.conditions_for(ctx, s) else "baseline"
                key = ctx.ranking_key(cond, s)
                prof = E.best_per_depth(fits, s, run, key)
                ys = sorted(prof)
                vals = np.array([prof[y][key] for y in ys])
                if not len(ys):
                    continue
                ax.plot(ys, vals - vals.min(), marker="o", ms=2, lw=1.2, label=f"{s} [{key}]",
                        color=["#2a78d6", "#eb6834", "#1baf7a", "#6250d6"][k % 4],
                        ls="-" if key != "R_struct" or cond == "baseline" else ":")
            ax.set_title(f"{job}: {cond}", fontsize=10, loc="left")
            ax.set_xlabel("coronal plane y (mm, MNI)")
            ax.set_ylabel("score - section's best")
            ax.invert_xaxis()
            ax.grid(alpha=0.25, lw=0.5)
            ax.legend(fontsize=8, frameon=False)
    fig.savefig(out / "profiles_by_donor.png", dpi=120)
    plt.close(fig)
    return summary
