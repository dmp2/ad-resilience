#!/usr/bin/env python3
"""QNP stacking coordinate by xIV similarity fits: structural baseline vs positive-only HALO MTG supervision.

For each informative section (an *anchor* of ``scan_atlas_planes_for_qnp.py --stage roles``) and
every candidate coronal atlas depth, xIV fits a similarity (rotation, translation, isotropic scale)
of the whole atlas window to the section in two conditions that share everything else:

* ``baseline``    structural gray/white varifold term, fixed identity feature map, anatomical weight 0;
* ``supervised``  the same, plus the uncensored HALO MTG <-> atlas MTG varifold term with weight 1.

The xIV objective, its normalisation, kernels and optimizer are the registration driver's own
(``framework_script_AtlasToSectionCrossModalBoundary.build_model`` / ``run_stages``).  The native
loss is *not* used to compare candidates: every fitted pose is scored afterwards by one common score
in the fixed QNP local frame (``preprocess/qnp_stacking_xiv.py``).  Sections without their own fitting
HALO annotation have no anatomical term: in the supervised condition they run the baseline objective
(no labels are transferred from other slides); passengers keep the within-donor alignment.

Stages (outputs under ``atlas_scan.xiv_stacking.output_dir``)
------
``sections``  per anchor: the 500 um target measure and its own annotation -> sections/<stain>.npz,
              sections.json
``starts``    ``--level coarse``: every depth of the target region's y-extent (+- pad, 3 mm stride),
              global GPU 2-D search (stacking.search, h1.0 particles), the K best distinct refined poses
              -> starts_coarse.csv (identical for both conditions).
              ``--level fine``: windows around each condition's best distinct coarse minima (union over
              conditions and anchors, so both conditions get the same depths); at every fine depth a
              fresh scan pose (shared) plus each condition's own best coarse pose of that window
              -> starts_fine.csv
``fit``       ``--level L [--worker i --workers n]``: one xIV fit per (start, condition); resumable
              (an existing result is kept unless ``--overwrite``; the skip count is printed)
``report``    profiles, noise scale, windows, competing minima, tables and figures -> report.json,
              REPORT.md, candidates.csv, profiles.png
``qc``        refit the leading candidates with the driver's full outputs, incl. registration_qc.png
``compare``   both donors side by side (``--jobs A B``) -> compare output dir
"""

from __future__ import annotations

import argparse
import contextlib
import copy
import csv
import io
import json
import os
import sys
import time
from pathlib import Path
from typing import Any

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
for extra in (ROOT / "src", ROOT / "src" / "config_setup", ROOT / "src" / "preprocess", ROOT / "src" / "scripts"):
    if str(extra) not in sys.path:
        sys.path.insert(0, str(extra))

from config_setup.project_config import load_config, resolve_path  # noqa: E402
from config_setup.qnp_jobs import resolve_qnp_job  # noqa: E402

CONDITIONS = ("baseline", "supervised")
COND_COLORS = {"baseline": "#5f5e5a", "supervised": "#2a78d6"}
INK, MUTED = "#1a1a19", "#8c8a82"


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--config", required=True)
    p.add_argument("--job", help="QNP job (qnp_section_inputs)")
    p.add_argument("--jobs", nargs="+", help="--stage compare: the jobs to compare")
    p.add_argument("--stage", required=True, choices=["sections", "starts", "fit", "report", "qc", "compare"])
    p.add_argument("--level", choices=["coarse", "fine"])
    p.add_argument("--worker", type=int, default=0)
    p.add_argument("--workers", type=int, default=1)
    p.add_argument("--overwrite", action="store_true")
    p.add_argument("--limit", type=int, help="--stage fit: at most this many new fits (timing runs)")
    p.add_argument("--out", help="--stage compare: output directory")
    return p.parse_args()


# --------------------------------------------------------------------------------------
# Context
# --------------------------------------------------------------------------------------

class Context:
    def __init__(self, config: dict, job_name: str):
        import scan_atlas_planes_for_qnp as SCAN

        self.config = config
        self.job = resolve_qnp_job(config, job_name)
        self.stack = SCAN.StackContext(config, self.job)
        self.scan = self.job["atlas_scan"]
        self.cfg = self.scan["xiv_stacking"]
        self.out = resolve_path(config, self.cfg["output_dir"])
        self.out.mkdir(parents=True, exist_ok=True)
        record = copy.deepcopy(config["registrations"][self.cfg["model_from_registration"]])
        self.model = {**record["model"], **self.cfg.get("model_overrides", {})}
        self.feature_map = str(self.cfg.get("structural_feature_map", "identity"))
        self.conditions = {c: dict(self.cfg["conditions"][c] or {}) for c in CONDITIONS}

    @property
    def atlas(self):
        return self.stack.atlas

    def anchors(self) -> list[str]:
        return self.stack.anchors()

    def section(self, stain: str):
        from preprocess.qnp_stacking_xiv import SectionMeasure

        with np.load(self.out / "sections" / f"{stain}.npz") as a:
            annotation = a["annotation"] if "annotation" in a.files else None
            record = json.loads(str(a["record"]))
            return SectionMeasure(stain, a["X"], a["nu"], annotation, record)

    def depths_coarse(self) -> np.ndarray:
        from preprocess.qnp_stacking import region_y_extent

        lo, hi = region_y_extent(self.atlas)
        c = self.cfg["coarse"]
        pad, stride = float(c.get("y_pad_mm", 5.0)), float(c.get("stride_mm", 3.0))
        return np.round(np.arange(hi + pad, lo - pad - 1e-9, -stride), 3)

    def ranking_key(self, condition: str, stain: str) -> str:
        return "R_combined" if condition == "supervised" and self.section(stain).annotated else "R_struct"


def _write_rows(path: Path, rows: list[dict]) -> None:
    with open(path, "w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def _read_rows(path: Path) -> list[dict]:
    with open(path, newline="") as stream:
        return list(csv.DictReader(stream))


def _sim_from_row(row: dict, prefix: str = ""):
    from preprocess.section_alignment import Similarity2D

    return Similarity2D(float(row[prefix + "theta_deg"]), float(row[prefix + "scale"]),
                        str(row[prefix + "flip"]) in ("True", "true", "1"),
                        (float(row[prefix + "tau_x"]), float(row[prefix + "tau_y"])))


def _sim_dict(t) -> dict:
    return {"theta_deg": float(t.theta_deg % 360), "scale": float(t.scale), "flip": bool(t.flip),
            "tau_x": float(t.tau[0]), "tau_y": float(t.tau[1])}


# --------------------------------------------------------------------------------------
# Stage: sections
# --------------------------------------------------------------------------------------

def run_sections(ctx: Context) -> dict:
    from preprocess.qnp_stacking_xiv import section_annotation_masses

    out_dir = ctx.out / "sections"
    out_dir.mkdir(exist_ok=True)
    level = ctx.cfg.get("section_level", "500um")
    summary = {}
    for stain in ctx.anchors():
        Xl, nul, _ = ctx.stack.particles(stain, level, "local")
        Xn, nun, _ = ctx.stack.particles(stain, level, "native")
        M = ctx.stack.slide_to_local(stain)
        mapped = Xn @ M[:2, :2].T + M[:2, 2]
        if not (np.allclose(mapped, Xl, atol=1e-4) and np.array_equal(nul, nun)):
            raise RuntimeError(f"{stain}: local particles are not the rigidly moved native particles")
        if abs(abs(np.linalg.det(M[:2, :2])) - 1) > 1e-6:
            raise RuntimeError(f"{stain}: slide -> local is not rigid; annotated areas would change")
        maps = dict(np.load(ctx.stack.particle_dir / f"{ctx.stack.stems[stain]}_maps_32um.npz"))
        annotation, record = section_annotation_masses(maps, Xn, nun)
        if stain in ctx.job.get("annotation_misfit", []):
            annotation, record = None, {"status": "annotation_misfit",
                                        "rule": "the slide's HALO layers do not fit its own tissue (inventory)"}
        elif annotation is None:
            record["status"] = "no_annotation"
        arrays = {"X": Xl, "nu": nul, "record": json.dumps(record)}
        if annotation is not None:
            arrays["annotation"] = annotation
        np.savez_compressed(out_dir / f"{stain}.npz", **arrays)
        summary[stain] = {"particles": int(len(Xl)), "tissue_area_mm2": float(nul.sum()), **record}
        print(f"{stain}: {len(Xl)} particles, {nul.sum():.1f} mm2, annotation: {record['status']}"
              + (f" ({record['annotated_tissue_area_mm2']:.1f} mm2, {100 * record['annotated_tissue_fraction']:.0f}%)"
                 if annotation is not None else ""), flush=True)
    (ctx.out / "sections.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    return summary


# --------------------------------------------------------------------------------------
# Stage: starts
# --------------------------------------------------------------------------------------

def _scan_poses(ctx: Context, stain: str, ys, k: int) -> dict[float, list]:
    from preprocess.qnp_stacking import level_sigmas, make_scorer, plane_measure, search_depths
    from preprocess.qnp_stacking_xiv import distinct_poses

    level = ctx.cfg.get("start_level", "h1.0")
    X, nu, _ = ctx.stack.particles(stain, level)
    scorer = make_scorer(X, nu, level_sigmas(ctx.stack.sigmas, ctx.stack.h_mm(level)))
    measures = [plane_measure(ctx.atlas, ctx.scan, y) for y in ys]
    results = search_depths(scorer, measures, ctx.stack.cfg["search"])
    d = ctx.cfg.get("distinct_start", {})
    return {float(y): distinct_poses(ranked, k, float(d.get("min_shift_mm", 3.0)), float(d.get("min_angle_deg", 20.0)))
            for y, ranked in zip(ys, results)}


def run_starts(ctx: Context, level: str) -> None:
    rows = []
    if level == "coarse":
        ys = ctx.depths_coarse()
        k = int(ctx.cfg["coarse"].get("starts_per_depth", 3))
        for stain in ctx.anchors():
            t0 = time.time()
            for y, poses in _scan_poses(ctx, stain, ys, k).items():
                for j, (score, t) in enumerate(poses):
                    rows.append({"section": stain, "level": level, "y_mm": y, "start_id": f"scan{j}",
                                 "conditions": "all", "scan_score": score, **_sim_dict(t)})
            print(f"{stain}: {len(ys)} depths, {k} distinct poses each, {time.time() - t0:.1f} s", flush=True)
        _write_rows(ctx.out / "starts_coarse.csv", rows)
        return
    plan = fine_plan(ctx)
    k = int(ctx.cfg["fine"].get("scan_starts_per_depth", 1))
    for stain in ctx.anchors():
        ys = plan["depths"]
        for y, poses in _scan_poses(ctx, stain, ys, k).items():
            for j, (score, t) in enumerate(poses):
                rows.append({"section": stain, "level": level, "y_mm": y, "start_id": f"scan{j}",
                             "conditions": "all", "scan_score": score, **_sim_dict(t)})
        for cond, minima in plan["conditioning"][stain].items():
            for y in ys:
                m = min(minima, key=lambda r: abs(float(r["y_mm"]) - y))  # the window's own coarse minimum
                rows.append({"section": stain, "level": level, "y_mm": y, "start_id": f"prev_{cond}",
                             "conditions": cond, "scan_score": "",
                             **{k2: m[f"fit_{k2}"] for k2 in ("theta_deg", "scale", "flip", "tau_x", "tau_y")}})
    (ctx.out / "fine_plan.json").write_text(json.dumps(plan, indent=2, default=str) + "\n", encoding="utf-8")
    _write_rows(ctx.out / "starts_fine.csv", rows)
    print(f"fine: {len(plan['depths'])} depths {plan['depths'][0]} ... {plan['depths'][-1]}; {len(rows)} start rows")


def fine_plan(ctx: Context) -> dict:
    """Fine depths: the union over anchors and conditions of +- pad around each condition's best distinct
    coarse minima (so both conditions are refined at the same depths), plus the conditioning poses."""

    from preprocess.qnp_stacking import distinct_minima

    f = ctx.cfg["fine"]
    step, pad = float(f.get("step_mm", 0.5)), float(f.get("pad_mm", 3.0))
    keep, sep = int(f.get("minima_per_condition", 2)), float(f.get("min_separation_mm", 6.0))
    fits = load_fits(ctx, ["coarse"])
    centres, conditioning = set(), {}
    for stain in ctx.anchors():
        conditioning[stain] = {}
        for cond in conditions_for(ctx, stain):
            conditioning[stain][cond] = []
            for scale_range in scale_variants(ctx).values():  # both rankings get refinement coverage
                best = best_per_depth(fits, stain, cond, ctx.ranking_key(cond, stain), scale_range)
                ys = sorted(best)
                minima = distinct_minima(ys, [best[y][ctx.ranking_key(cond, stain)] for y in ys], keep, sep)
                conditioning[stain][cond] += [best[y] for y in minima
                                              if all(abs(best[y]["y_mm"] - c["y_mm"]) > 1e-6 for c in conditioning[stain][cond])]
                centres |= set(minima)
    depths = sorted({round(float(y), 3) for c in centres for y in np.arange(c - pad, c + pad + 1e-9, step)}, reverse=True)
    return {"centres_mm": sorted(centres, reverse=True), "depths": depths, "step_mm": step, "pad_mm": pad,
            "conditioning": conditioning}


def conditions_for(ctx: Context, stain: str) -> list[str]:
    """Conditions that run a distinct objective: the supervised term needs the section's own annotation."""

    return list(CONDITIONS) if ctx.section(stain).annotated else ["baseline"]


# --------------------------------------------------------------------------------------
# Stage: fit
# --------------------------------------------------------------------------------------

def tasks(ctx: Context, level: str) -> list[dict]:
    out = []
    for row in _read_rows(ctx.out / f"starts_{level}.csv"):
        runnable = conditions_for(ctx, row["section"])
        wanted = runnable if row["conditions"] == "all" else [c for c in [row["conditions"]] if c in runnable]
        for cond in wanted:
            out.append({**row, "condition": cond})
    return out


def result_path(ctx: Context, level: str, t: dict) -> Path:
    return ctx.out / f"fits_{level}" / t["section"] / t["condition"] / f"y{float(t['y_mm']):+06.1f}_{t['start_id']}.json"


class Fitter:
    """One process: xmodmap loaded once, sections and planes cached."""

    def __init__(self, ctx: Context, workdir: Path):
        import torch

        import framework_script_AtlasToSectionCrossModalBoundary as D
        from preprocess.qnp_stacking_xiv import CommonScore, EvaluationSettings
        from preprocess.xmodmap_compat import load_xmodmap

        self.ctx, self.D, self.torch = ctx, D, torch
        self.api = load_xmodmap(ctx.config)  # sets the default tensor type
        self.dtype = D._torch_dtype(str(ctx.model.get("torch_dtype", "float32")))
        self.device = torch.device(str(ctx.model.get("device", "cpu")))
        self.plan = D.stage_plan(self.api, ctx.model, None)
        self.workdir = workdir
        self.settings = EvaluationSettings.from_config(ctx.cfg["evaluation"])
        self.sections = {s: ctx.section(s) for s in ctx.anchors()}
        self.scores = {s: CommonScore(sec, self.settings) for s, sec in self.sections.items()}
        reference = ctx.stack.reference
        self.reference = self.sections.get(reference) or (ctx.section(reference) if (ctx.out / "sections" / f"{reference}.npz").exists() else None)
        self.planes: dict[float, dict] = {}

    def plane(self, y: float) -> dict:
        from preprocess.qnp_stacking_xiv import atlas_plane

        key = round(float(y), 3)
        if key not in self.planes:
            if len(self.planes) > 64:
                self.planes.clear()
            self.planes[key] = atlas_plane(self.ctx.atlas, self.ctx.scan, key, float(self.ctx.cfg.get("atlas_bin_mm", 1.0)))
        return self.planes[key]

    def inputs(self, stain: str, plane: dict, t_init, condition: str, strip=None) -> dict:
        from preprocess.qnp_stacking_xiv import ANNOTATION_FEATURE, MTG_CHANNEL

        D, sec = self.D, self.sections[stain]
        record = {"model": self.ctx.model, "anatomical_supervision": self.ctx.conditions[condition]}
        settings = D.anatomical_settings(record)
        s2 = t_init.scale ** 2
        T_plane = t_init.section_to_moving(sec.X)
        centre = T_plane.mean(0)  # center_mode shared_target
        anatomical = None
        if sec.annotated:
            anatomical = {"nu_S": plane["mtg"], "nu_T": sec.annotation * s2, "source_names": [MTG_CHANNEL],
                          "target_names": [ANNOTATION_FEATURE], "nu_Anat": plane["nu_anat"],
                          "nu_Anat_names": plane["anat_names"]}
        if settings["weight"] == 0:
            term = "off (weight 0): original structural objective"
        elif anatomical is None:
            term = "inactive (section has no HALO annotation): original structural objective"
        else:
            term = "active"
        strip_X, strip_depth = strip if strip is not None else (np.zeros((0, 2)), np.zeros(0))
        return {
            "S": plane["X"] - centre, "nu_S": plane["nu"], "T": T_plane - centre, "nu_T": sec.nu * s2,
            "source_center": centre, "target_center": centre, "mode": "classes",
            "source_names": ["gray_matter", "white_matter"], "target_names": ["gray_matter", "white_matter"],
            "anatomical": anatomical, "anatomical_settings": settings, "anatomical_term": term,
            "structural_feature_map": self.ctx.feature_map, "source_feature_projection": None,
            "strip_X": (t_init.section_to_moving(strip_X) - centre) if len(strip_X) else np.zeros((0, 2)),
            "strip_depth_um": strip_depth,
            "source_meta": {"plane": plane["plane_meta"], "coordinate_space": "mni_icbm2009b_symmetric_plane"},
            "target_meta": {"similarity_qnp_local_to_plane": {**t_init.as_dict(), "from": "qnp_local_mm",
                                                              "to": "atlas plane mm"},
                            "annotation_supervision": sec.annotation_record, "stain": stain},
            "source_file": None, "target_file": None,
        }

    def evaluate(self, stain: str, plane: dict, pose) -> dict:
        from preprocess.qnp_stacking_xiv import landing, section_frame_atlas

        Y, (nu, mtg) = section_frame_atlas(pose, plane["X"], [plane["nu"], plane["mtg"]])
        out = self.scores[stain].evaluate(Y, nu, mtg)
        sec, tables = self.sections[stain], self.ctx.atlas["anatomical"]
        gm = landing(plane, self.ctx.atlas, pose, sec.X, sec.nu[:, 0], tables)
        wm = landing(plane, self.ctx.atlas, pose, sec.X, sec.nu[:, 1], tables)
        gray = [n for n in tables if n != "white_matter"]
        out["landing_gray_on_atlas_gray"] = float(sum(gm[n] for n in gray))
        out["landing_white_on_atlas_white"] = float(wm["white_matter"])
        out["landing_tissue_outside_atlas"] = float((gm["outside"] * sec.nu[:, 0].sum() + wm["outside"] * sec.nu[:, 1].sum())
                                                    / sec.nu.sum())
        if sec.annotated:
            out["landing_own_annotation"] = landing(plane, self.ctx.atlas, pose, sec.X, sec.annotation, tables)
        if self.reference is not None and self.reference.annotated:
            out["landing_reference_annotation"] = landing(plane, self.ctx.atlas, pose, self.reference.X,
                                                          self.reference.annotation, tables)
        return out

    def fit(self, task: dict) -> dict:
        from preprocess.qnp_stacking_xiv import compose, similarity_lsq

        torch, D = self.torch, self.D
        stain, cond = task["section"], task["condition"]
        plane = self.plane(float(task["y_mm"]))
        t_init = _sim_from_row(task)
        inputs = self.inputs(stain, plane, t_init, cond)
        seed = int(self.ctx.model.get("seed", 0))
        torch.manual_seed(seed)
        np.random.seed(seed)
        t0 = time.time()
        with open(os.devnull, "w") as sink, contextlib.redirect_stdout(sink):
            built = D.build_model(self.api, inputs, self.ctx.model, "r000_f0", self.device, self.dtype)
            stages = D.run_stages(self.api, built, self.plan, self.workdir)
        seconds = time.time() - t0
        stage = stages[-1]
        qx1, qw1 = stage["shot"][2].detach(), stage["shot"][3].detach()
        s, m = built["s"], built["m"]
        D_plane = self.api.resize_data(qx1, s, m).cpu().numpy().astype(np.float64) + inputs["source_center"]
        ratio = (qw1 / built["w_S"]).cpu().numpy().astype(np.float64).ravel()
        fit = similarity_lsq(plane["X"], D_plane, plane["nu"].sum(1))
        pose = compose(t_init, fit)
        # The shot particles themselves, in the section frame (positions via the start, areas / s_init^2).
        Yshot = t_init.moving_to_section(D_plane)
        nu_shot = plane["nu"] * ratio[:, None] / t_init.scale ** 2
        mtg_shot = plane["mtg"] * ratio[:, None] / t_init.scale ** 2
        evaluation = self.evaluate(stain, plane, pose)
        shot_eval = self.scores[stain].evaluate(Yshot, nu_shot, mtg_shot)
        start_eval = self.scores[stain].evaluate(t_init.moving_to_section(plane["X"]), plane["nu"] / t_init.scale ** 2,
                                                 plane["mtg"] / t_init.scale ** 2)
        loss = stage["loss"]
        names = getattr(loss, "term_names", ["hamiltonian", "data", "pi", "lambda"])
        final = [float(v) for v in loss.log[-1]]
        first = [float(v) for v in loss.log[0]]
        return {
            "job": self.ctx.job["_name"], "section": stain, "condition": cond, "level": task["level"],
            "y_mm": float(task["y_mm"]), "start_id": task["start_id"], "scan_score": task.get("scan_score"),
            "anatomical_term": inputs["anatomical_term"],
            "start_pose": _sim_dict(t_init), "fit_pose": _sim_dict(pose),
            "xiv_similarity": {"scale": fit["scale"], "rotation_deg": fit["rotation_deg"], "translation_mm": fit["b"].tolist(),
                               "lsq_residual_mm": fit["residual_mm"],
                               "mass_ratio_vs_scale2": float(np.median(ratio) / fit["scale"] ** 2)},
            "native": {"terms": names, "first": dict(zip(names, first)), "final": dict(zip(names, final)),
                       "total_final": float(sum(final)), "closures": len(loss.log), "unit_box_s_mm": float(s),
                       "components": stage.get("components"), "stop": stage.get("stop_reason")},
            "eval": evaluation, "eval_shot_particles": {k: shot_eval[k] for k in ("R_struct", "R_anat", "R_combined")},
            "eval_start": {k: start_eval[k] for k in ("R_struct", "R_anat", "R_combined")},
            "seconds": seconds,
            "finite": bool(np.isfinite(D_plane).all() and np.isfinite(final).all()),
        }


def run_fit(ctx: Context, level: str, worker: int, workers: int, overwrite: bool, limit: int | None) -> None:
    todo = [t for k, t in enumerate(tasks(ctx, level)) if k % workers == worker]
    pending = [t for t in todo if overwrite or not result_path(ctx, level, t).exists()]
    print(f"worker {worker}/{workers}: {len(todo)} tasks, {len(todo) - len(pending)} already done (kept), "
          f"{len(pending)} to fit", flush=True)
    if limit is not None:
        pending = pending[:limit]
    if not pending:
        return
    fitter = Fitter(ctx, ctx.out / "_work" / f"worker{worker}")
    t0 = time.time()
    for n, task in enumerate(pending, 1):
        path = result_path(ctx, level, task)
        path.parent.mkdir(parents=True, exist_ok=True)
        try:
            result = fitter.fit(task)
        except Exception as error:  # noqa: BLE001 - one failed fit is recorded, not fatal
            result = {**{k: task[k] for k in ("section", "condition", "level", "y_mm", "start_id")},
                      "error": repr(error), "finite": False}
        path.write_text(json.dumps(result, indent=1, default=float) + "\n", encoding="utf-8")
        if n % 10 == 0 or n == len(pending):
            print(f"worker {worker}: {n}/{len(pending)} fits, {(time.time() - t0) / n:.1f} s each", flush=True)


# --------------------------------------------------------------------------------------
# Profiles and report
# --------------------------------------------------------------------------------------

def load_fits(ctx: Context, levels=("coarse", "fine")) -> list[dict]:
    rows = []
    for level in levels:
        for path in sorted((ctx.out / f"fits_{level}").glob("*/*/*.json")):
            r = json.loads(path.read_text())
            if "error" in r or not r.get("finite", False):
                r["_failed"] = True
            rows.append(r)
    return rows


def _flat(r: dict) -> dict:
    e = r["eval"]
    return {"y_mm": r["y_mm"], "level": r["level"], "start_id": r["start_id"], "condition": r["condition"],
            "R_struct": e["R_struct"], "R_anat": e["R_anat"], "R_combined": e["R_combined"],
            **{f"fit_{k}": v for k, v in r["fit_pose"].items()}, "xiv_scale": r["xiv_similarity"]["scale"],
            "native_total": r["native"]["total_final"], "native_data": r["native"]["final"].get("data"),
            "native_anatomical": r["native"]["final"].get("anatomical"), "unit_box_s_mm": r["native"]["unit_box_s_mm"],
            "stop": (r["native"].get("stop") or {}).get("kind"), "closures": r["native"]["closures"],
            "atlas_mtg_mass_mm2": e["atlas_mtg_mass_mm2"], "atlas_mtg_in_footprint_mm2": e["atlas_mtg_mass_in_footprint_mm2"],
            "anat_atlas_self": (e["anat"] or {}).get("atlas_self"), "anat_cross": (e["anat"] or {}).get("cross"),
            "landing_gray": e["landing_gray_on_atlas_gray"], "landing_white": e["landing_white_on_atlas_white"],
            "landing_outside": e["landing_tissue_outside_atlas"],
            "own_annotation_on_MTG": (e.get("landing_own_annotation") or {}).get("MTG_gray_matter"),
            "own_annotation_outside": (e.get("landing_own_annotation") or {}).get("outside"),
            "reference_annotation_on_MTG": (e.get("landing_reference_annotation") or {}).get("MTG_gray_matter"),
            "R_struct_start": r["eval_start"]["R_struct"], "R_combined_start": r["eval_start"]["R_combined"],
            "shot_vs_pose_R_struct": r["eval_shot_particles"]["R_struct"] - e["R_struct"]}


def best_per_depth(fits: list[dict], stain: str, condition: str, key: str,
                   scale_range: tuple[float, float] | None = None) -> dict[float, dict]:
    """Per depth, the fit with the lowest ``key``; ``scale_range`` keeps only fits whose final pose scale lies
    inside it (a post-fit admissibility filter, not part of any objective)."""

    best: dict[float, dict] = {}
    for r in fits:
        if r.get("_failed") or r["section"] != stain or r["condition"] != condition:
            continue
        f = _flat(r)
        if f[key] is None:
            continue
        if scale_range is not None and not (scale_range[0] <= f["fit_scale"] <= scale_range[1]):
            continue
        y = round(float(r["y_mm"]), 3)
        if y not in best or f[key] < best[y][key]:
            best[y] = f
    return best


def scale_variants(ctx: Context) -> dict[str, tuple[float, float] | None]:
    lo, hi = ctx.cfg["evaluation"].get("scale_plausible", [0.8, 1.5])
    return {"plausible_scale": (float(lo), float(hi)), "all_fits": None}


def _local_minima(ys: list[float], vals: list[float], keep: int, sep: float) -> list[float]:
    from preprocess.qnp_stacking import distinct_minima

    return distinct_minima(ys, vals, keep, sep)


def run_report(ctx: Context) -> dict:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fits = load_fits(ctx)
    failed = [r for r in fits if r.get("_failed")]
    plan = json.loads((ctx.out / "fine_plan.json").read_text()) if (ctx.out / "fine_plan.json").exists() else None
    summary: dict[str, Any] = {
        "job": ctx.job["_name"], "anchors": ctx.anchors(), "failed_fits": len(failed),
        "failed": [{k: r.get(k) for k in ("section", "condition", "level", "y_mm", "start_id", "error")} for r in failed],
        "fits": len(fits) - len(failed), "fine_plan": None if plan is None else {k: plan[k] for k in ("centres_mm", "depths")},
        "optimizer_stops": _stops(fits), "variants": {},
        "ranking": "baseline: R_struct; supervised: R_combined = lambda_struct R_struct + lambda_anat R_anat for sections "
                   "with their own annotation, R_struct otherwise (they run the baseline objective).  A post-fit common "
                   "score in the fixed QNP local frame; xIV optimised its own native loss.",
        "variant_definitions": {"plausible_scale": "only fits whose final pose scale lies in evaluation.scale_plausible "
                                                   "(the scan's scale bounds): a post-fit admissibility filter",
                                "all_fits": "every finite fit"}}
    profiles_by_variant = {}
    for variant, scale_range in scale_variants(ctx).items():
        summary["variants"][variant], profiles_by_variant[variant] = _variant_report(ctx, fits, plan, scale_range)
    (ctx.out / "report.json").write_text(json.dumps(summary, indent=2, default=float) + "\n", encoding="utf-8")
    rows = [{"variant": v, **r} for v, rep in summary["variants"].items() for r in rep["table"]]
    if rows:
        _write_rows(ctx.out / "candidates.csv", rows)
    _profiles_figure(ctx, profiles_by_variant, summary, plt)
    _write_report_md(ctx, summary)
    return summary


def _stops(fits: list[dict]) -> dict:
    out: dict[str, dict] = {}
    for r in fits:
        if r.get("_failed"):
            continue
        kind = (r["native"].get("stop") or {}).get("kind") or "none"
        out.setdefault(r["condition"], {}).setdefault(kind, 0)
        out[r["condition"]][kind] += 1
    return out


def _variant_report(ctx: Context, fits: list[dict], plan: dict | None, scale_range) -> tuple[dict, dict]:
    from preprocess.qnp_stacking import noise_delta, window

    fine_ys = set(round(float(y), 3) for y in plan["depths"]) if plan else set()
    anchors = ctx.anchors()
    step = float(ctx.cfg["fine"].get("step_mm", 0.5))
    sections = {s: ctx.section(s) for s in anchors}
    lo, hi = ctx.cfg["evaluation"].get("scale_plausible", [0.8, 1.5])
    # profiles[condition][stain] = {y: best flat row by the condition's ranking score}; sections without their
    # own annotation run the baseline objective in the supervised condition (the same fits).
    profiles: dict[str, dict[str, dict[float, dict]]] = {c: {} for c in CONDITIONS}
    keys: dict[str, dict[str, str]] = {c: {} for c in CONDITIONS}
    for cond in CONDITIONS:
        for s in anchors:
            run_cond = cond if cond in conditions_for(ctx, s) else "baseline"
            keys[cond][s] = ctx.ranking_key(cond, s)
            profiles[cond][s] = best_per_depth(fits, s, run_cond, keys[cond][s], scale_range)
    ablation = {s: best_per_depth(fits, s, "baseline", "R_combined", scale_range) for s in anchors if sections[s].annotated}

    def on_shared(prof, key):
        return {y: r[key] for y, r in prof.items() if (y in fine_ys if fine_ys else True)}

    # delta (skill definition: across-anchor spread of each anchor's score relative to its own best). R_struct: all
    # anchors' baseline fits (the supervised condition of an unannotated section is the same fits); R_combined: the
    # anchors with their own annotation, supervised fits.
    struct_members = {s: on_shared(profiles["baseline"][s], "R_struct") for s in anchors}
    deltas = {"R_struct": noise_delta({s: p for s, p in struct_members.items() if p})}
    comb_members = {s: on_shared(profiles["supervised"][s], "R_combined") for s in anchors if sections[s].annotated}
    comb_members = {s: p for s, p in comb_members.items() if p}
    deltas["R_combined"] = noise_delta(comb_members) if len(comb_members) >= 2 else {
        "delta": None, "members": list(comb_members), "reason": "fewer than 2 annotated anchors"}

    def delta_for(key):
        d = deltas[key].get("delta")
        if d is not None and np.isfinite(d):
            return d, "across-anchor (skill definition)"
        d = deltas["R_struct"].get("delta")
        if d is not None and np.isfinite(d):
            return d, "borrowed: the R_struct delta (fewer than 2 anchors with their own annotation)"
        return 0.0, "unavailable (fewer than 2 anchors with shared depths); window = best only"

    out: dict[str, Any] = {"deltas": deltas, "sections": {}, "table": []}
    for s in anchors:
        entry = {"annotation": sections[s].annotation_record.get("status"), "conditions": {}}
        for cond in CONDITIONS:
            key = keys[cond][s]
            prof = profiles[cond][s]
            ys = sorted(prof)
            if not ys:
                continue
            vals = [prof[y][key] for y in ys]
            delta, delta_source = delta_for(key)
            fine_prof = {y: prof[y][key] for y in ys if y in fine_ys} or {y: prof[y][key] for y in ys}
            w = window(fine_prof, delta, step)
            w["note"] = "window on the fine depths (0.5 mm); the coarse profile is in competing_minima"
            minima = _local_minima(ys, vals, 4, float(ctx.cfg["fine"].get("min_separation_mm", 6.0)))
            best = prof[min(ys, key=lambda y: prof[y][key])]
            competing = [{"y_mm": y, key: prof[y][key], "gap_in_delta": (prof[y][key] - best[key]) / delta if delta > 0 else None,
                          **{k: prof[y][k] for k in ("level", "start_id", "fit_scale", "fit_theta_deg", "fit_flip", "fit_tau_x",
                                                     "fit_tau_y", "R_struct", "R_anat", "own_annotation_on_MTG",
                                                     "reference_annotation_on_MTG", "landing_gray", "landing_white")}}
                         for y in minima]
            objective = "baseline (no annotation)" if cond == "supervised" and key == "R_struct" else cond
            entry["conditions"][cond] = {"objective": objective, "ranking_score": key, "delta": delta,
                                         "delta_source": delta_source, "window": w, "best": best,
                                         "competing_minima": competing,
                                         "scale_flag": not (lo <= best["fit_scale"] <= hi),
                                         "depths_profiled": len(ys)}
            out["table"].append({
                "section": s, "condition": cond, "objective": objective, "ranking": key, "best_y_mm": best["y_mm"],
                "window_lo": w["window_y"][1], "window_hi": w["window_y"][0], "window_contiguous": w["contiguous"],
                "delta": round(delta, 4), "score": round(best[key], 4), "R_struct": round(best["R_struct"], 4),
                "R_anat": None if best["R_anat"] is None else round(best["R_anat"], 4),
                "anat_atlas_self": None if best["anat_atlas_self"] is None else round(best["anat_atlas_self"], 3),
                "anat_cross": None if best["anat_cross"] is None else round(best["anat_cross"], 3),
                "scale": round(best["fit_scale"], 3), "theta_deg": round(best["fit_theta_deg"], 1), "flip": best["fit_flip"],
                "tau_x": round(best["fit_tau_x"], 2), "tau_y": round(best["fit_tau_y"], 2),
                "native_total": round(best["native_total"], 3), "native_data": round(best["native_data"], 3),
                "native_anatomical": None if best["native_anatomical"] is None else round(best["native_anatomical"], 3),
                "unit_box_s_mm": round(best["unit_box_s_mm"], 2), "stop": best["stop"],
                "landing_gray": round(best["landing_gray"], 3), "landing_white": round(best["landing_white"], 3),
                "own_annot_on_MTG": None if best["own_annotation_on_MTG"] is None else round(best["own_annotation_on_MTG"], 3),
                "ref_annot_on_MTG": None if best["reference_annotation_on_MTG"] is None else round(best["reference_annotation_on_MTG"], 3),
                "tissue_outside_atlas": round(best["landing_outside"], 3),
                "own_annot_outside_atlas": None if best["own_annotation_outside"] is None else round(best["own_annotation_outside"], 3),
                "atlas_MTG_mm2": round(best["atlas_mtg_mass_mm2"], 1),
                "atlas_MTG_in_footprint_mm2": round(best["atlas_mtg_in_footprint_mm2"], 1),
                "competing": "; ".join(f"{c['y_mm']:+.1f} ({'-' if c['gap_in_delta'] is None else round(c['gap_in_delta'], 1)} delta,"
                                       f" scale {c['fit_scale']:.2f})" for c in competing[1:])})
        if s in ablation and ablation[s]:
            ab = ablation[s]
            yb = min(ab, key=lambda y: ab[y]["R_combined"])
            entry["selection_only_ablation"] = {"definition": "baseline fits ranked by R_combined", "best_y_mm": yb,
                                                **{k: ab[yb][k] for k in ("R_struct", "R_anat", "R_combined", "fit_scale",
                                                                          "own_annotation_on_MTG")}}
        out["sections"][s] = entry
    out["consistency"] = consistency(out, anchors)
    return out, {"profiles": profiles, "keys": keys}


def consistency(summary: dict, anchors: list[str]) -> dict:
    """Agreement of the sections of one block: overlap of their windows (no order or spacing assumed)."""

    out = {}
    for cond in CONDITIONS:
        wins = {s: summary["sections"][s]["conditions"][cond]["window"]
                for s in anchors if cond in summary["sections"][s]["conditions"]}
        if not wins:
            continue
        his = [w["window_y"][0] for w in wins.values()]
        los = [w["window_y"][1] for w in wins.values()]
        bests = [w["best_y"] for w in wins.values()]
        out[cond] = {"best_y_mm": {s: w["best_y"] for s, w in wins.items()},
                     "best_spread_mm": float(max(bests) - min(bests)),
                     "common_window_mm": [min(his), max(los)] if min(his) >= max(los) else None,
                     "union_window_mm": [max(his), min(los)],
                     "note": "sections share one block; a common window means one depth range explains every anchor "
                             "within its noise; order and spacing are not estimated"}
    return out


def _profiles_figure(ctx, profiles_by_variant, summary, plt) -> None:
    anchors = ctx.anchors()
    primary = profiles_by_variant["plausible_scale"]
    secondary = profiles_by_variant["all_fits"]
    rep = summary["variants"]["plausible_scale"]
    lo, hi = ctx.cfg["evaluation"].get("scale_plausible", [0.8, 1.5])
    fig, axes = plt.subplots(len(anchors), 4, figsize=(19, 3.4 * len(anchors)), squeeze=False, constrained_layout=True)
    panels = (("rank", "ranking score (lower = better)"), ("R_struct", "R_struct (gray/white, identity)"),
              ("R_anat", "R_anat (HALO MTG, uncensored)"), ("fit_scale", "fitted scale (section -> atlas)"))
    for i, s in enumerate(anchors):
        for j, (metric, label) in enumerate(panels):
            ax = axes[i, j]
            for cond in CONDITIONS:
                key_rank = primary["keys"][cond][s]
                same = cond == "supervised" and key_rank == "R_struct"
                if same and metric != "rank":
                    continue
                key = key_rank if metric == "rank" else metric
                for profs, faint in ((secondary, True), (primary, False)):
                    prof = profs["profiles"][cond][s]
                    ys = sorted(prof)
                    vals = [prof[y][key] for y in ys]
                    if not ys or all(v is None for v in vals):
                        continue
                    ax.plot(ys, vals, marker="o" if not faint else None, ms=2.2, lw=0.8 if faint else 1.5,
                            alpha=0.35 if faint else 1.0, color=COND_COLORS[cond], ls=":" if same else "-",
                            label=None if faint else (f"{cond}" + (" (= baseline: no annotation)" if same else "")
                                                      + (f" [{key_rank}]" if metric == "rank" else "")))
                info = rep["sections"][s]["conditions"].get(cond)
                if info and not same:
                    if metric == "rank":
                        ax.axvspan(info["window"]["window_y"][1] - 0.1, info["window"]["window_y"][0] + 0.1,
                                   color=COND_COLORS[cond], alpha=0.14, lw=0)
                    ax.axvline(info["best"]["y_mm"], color=COND_COLORS[cond], lw=0.8, alpha=0.8)
            if metric == "fit_scale":
                ax.axhspan(lo, hi, color="#e6e4dc", alpha=0.6, lw=0, zorder=0)
            if metric == "R_anat" and rep["sections"][s]["annotation"] != "annotated":
                ax.cla()
                ax.text(0.5, 0.5, "no own fitting HALO annotation:\nno anatomical term, no R_anat", ha="center",
                        va="center", transform=ax.transAxes, color=MUTED, fontsize=10)
                ax.set_xticks([])
                ax.set_yticks([])
                ax.set_title(f"{s}: {label}", fontsize=9.5, loc="left")
                continue
            ax.set_title(f"{s} ({rep['sections'][s]['annotation']}): {label}", fontsize=9.5, loc="left")
            ax.set_xlabel("coronal plane y (mm, MNI)")
            ax.invert_xaxis()
            ax.grid(alpha=0.25, lw=0.5)
            if j == 0:
                ax.legend(fontsize=8, frameon=False)
    fig.suptitle(f"{ctx.job['_name']}: best xIV similarity fit per depth (solid: fits with scale in [{lo}, {hi}]; "
                 "faint: all fits); band = window within delta; line = best depth", fontsize=11)
    fig.savefig(ctx.out / "profiles.png", dpi=120)
    plt.close(fig)


def _write_report_md(ctx, summary) -> None:
    lines = [f"# {summary['job']}: stacking coordinate, baseline vs HALO MTG supervision", "",
             f"Fits: {summary['fits']} ({summary['failed_fits']} failed). Optimizer stops: {summary['optimizer_stops']}.", "",
             summary["ranking"], ""]
    for variant, rep in summary["variants"].items():
        lines += [f"## Ranking over {variant.replace('_', ' ')} ({summary['variant_definitions'][variant]})", "",
                  "| section | condition | best y | window (within delta) | delta | score | R_struct | R_anat | scale | theta | "
                  "flip | gray→gray | white→white | tissue outside atlas | own annot→MTG | NeuN annot→MTG | "
                  "competing minima (gap, scale) |",
                  "|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|"]
        for r in rep["table"]:
            lines.append(f"| {r['section']} | {r['condition']} ({r['objective']}, {r['ranking']}) | {r['best_y_mm']:+.1f} | "
                         f"{r['window_hi']:+.1f} … {r['window_lo']:+.1f}{'' if r['window_contiguous'] else ' (gaps)'} | "
                         f"{r['delta']} | {r['score']} | {r['R_struct']} | {r['R_anat']} | {r['scale']} | {r['theta_deg']} | "
                         f"{r['flip']} | {r['landing_gray']} | {r['landing_white']} | {r['tissue_outside_atlas']} | {r['own_annot_on_MTG']} | "
                         f"{r['ref_annot_on_MTG']} | {r['competing']} |")
        lines += ["", "Consistency within the block:", ""]
        for cond, c in rep["consistency"].items():
            lines.append(f"- {cond}: best depths {c['best_y_mm']}, spread {c['best_spread_mm']:.1f} mm; "
                         f"common window {c['common_window_mm']}")
        lines.append("")
    (ctx.out / "REPORT.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


# --------------------------------------------------------------------------------------
# Stage: qc (leading candidates with the driver's full outputs)
# --------------------------------------------------------------------------------------

def run_qc(ctx: Context, overwrite: bool) -> None:
    import shutil

    import torch

    from preprocess.qnp_stacking_xiv import compose, pose_distance, similarity_lsq

    report = json.loads((ctx.out / "report.json").read_text())
    fits = load_fits(ctx)
    per = int(ctx.cfg.get("qc_candidates_per_condition", 2))
    fitter = Fitter(ctx, ctx.out / "_work" / "qc")
    D = fitter.D
    with np.load(resolve_path(ctx.config, ctx.scan["ribbon_points"])) as a:
        strip = (a["X"][:, :2].astype(np.float64), a["depth_from_pia_um"].astype(np.float64))
    rows, done = [], set()
    candidates = []
    for variant, rep in report["variants"].items():
        for s, entry in rep["sections"].items():
            for cond, info in entry["conditions"].items():
                if info["objective"].startswith("baseline (no annotation)"):
                    continue  # identical fits to baseline
                for rank, cand in enumerate(info["competing_minima"][:per]):
                    candidates.append((variant, s, cond, info["ranking_score"], rank, cand))
    for variant, s, cond, key, rank, cand in candidates:
        y = round(float(cand["y_mm"]), 3)
        if (s, cond, y, cand["start_id"], cand["level"]) in done:
            continue
        done.add((s, cond, y, cand["start_id"], cand["level"]))
        best = next(r for r in fits if not r.get("_failed") and r["section"] == s and r["condition"] == cond
                    and round(float(r["y_mm"]), 3) == y and r["start_id"] == cand["start_id"]
                    and r["level"] == cand["level"])
        out_dir = ctx.out / "qc" / s / cond / f"y{y:+06.1f}_{cand['level']}_{cand['start_id']}" / "init_r000_f0"
        plane = fitter.plane(y)
        t_init = _sim_from_row(best["start_pose"])
        inputs = fitter.inputs(s, plane, t_init, cond, strip=strip)
        # The inputs as archives (provenance; the QC figure reads the atlas channels from the source archive).
        out_dir.parent.mkdir(parents=True, exist_ok=True)
        source_file = out_dir.parent / "source_atlas_plane.npz"
        np.savez_compressed(source_file, X=np.column_stack([inputs["S"] + inputs["source_center"], np.zeros(len(inputs["S"]))]),
                            nu_Sub=inputs["nu_S"], nu_Anat=plane["nu_anat"],
                            anatomical_feature_names=np.asarray(plane["anat_names"], dtype=str),
                            plane=json.dumps(plane["plane_meta"]))
        np.savez_compressed(out_dir.parent / "target_section_in_plane.npz",
                            X=np.column_stack([inputs["T"] + inputs["target_center"], np.zeros(len(inputs["T"]))]),
                            nu_Sub=inputs["nu_T"], nu_Annot=(inputs["anatomical"] or {}).get("nu_T", np.zeros((0, 1))),
                            start_pose=json.dumps(_sim_dict(t_init)), section=s)
        inputs["source_file"] = source_file
        title = (f"{ctx.job['_name']} {s} {cond}  y {y:+.1f}  {cand['level']} {cand['start_id']}  "
                 f"(anatomical term {inputs['anatomical_term'].split(' ')[0]})")
        if (out_dir / "COMPLETED.json").exists() and not overwrite:
            if not (out_dir / "registration_qc.png").exists():
                built = D.build_model(fitter.api, inputs, ctx.model, "r000_f0", fitter.device, fitter.dtype)
                D.write_registration_qc(fitter.api, built, inputs, out_dir, fitter.device, fitter.dtype, title=title)
                print(f"QC figure added (fit kept): {out_dir}")
            else:
                print(f"exists, kept: {out_dir}")
        else:
            if out_dir.exists():
                shutil.rmtree(out_dir)
            out_dir.mkdir(parents=True)
            record = {"_name": title, "vtk_coordinate_convention": "xyz", "center_mode": "shared_target"}
            torch.manual_seed(int(ctx.model.get("seed", 0)))
            np.random.seed(int(ctx.model.get("seed", 0)))
            with open(out_dir / "driver_stdout.log", "w") as log, contextlib.redirect_stdout(log):
                D.fit_initialization(fitter.api, ctx.config, record, inputs, ctx.model, "r000_f0", fitter.plan,
                                     out_dir, fitter.device, fitter.dtype)
        # the refit's own pose and common score, against the sweep's
        atlas = torch.load(out_dir / "atlas_deformationSummary.pt", weights_only=False, map_location="cpu")
        D_plane = atlas["D"].numpy().astype(np.float64)[:, :2] + t_init.section_to_moving(fitter.sections[s].X).mean(0)
        pose = compose(t_init, similarity_lsq(plane["X"], D_plane, plane["nu"].sum(1)))
        ev = fitter.evaluate(s, plane, pose)
        rows.append({"variant": variant, "section": s, "condition": cond, "rank": rank, "y_mm": y,
                     "level": best["level"], "start_id": best["start_id"],
                     "sweep_" + key: _flat(best)[key], "refit_" + key: ev[key] if ev[key] is not None else "",
                     "sweep_scale": best["fit_pose"]["scale"], "refit_scale": pose.scale,
                     "pose_difference_mm": pose_distance(pose, _sim_from_row(best["fit_pose"]), fitter.sections[s].X),
                     "qc_figure": str(out_dir / "registration_qc.png")})
        print(rows[-1], flush=True)
    if rows:
        keys_ = sorted({k for r in rows for k in r}, key=lambda k: (k not in rows[0], k))
        with open(ctx.out / "qc_candidates.csv", "w", newline="") as stream:
            writer = csv.DictWriter(stream, fieldnames=keys_)
            writer.writeheader()
            writer.writerows(rows)


# --------------------------------------------------------------------------------------

def main() -> None:
    args = parse_args()
    config = load_config(args.config)
    if args.stage == "compare":
        import compare_qnp_stacking_xiv as C  # noqa: F401  (kept separate: reads only report.json files)

        C.compare(config, args.jobs, Path(args.out))
        return
    ctx = Context(config, args.job)
    if args.stage == "sections":
        run_sections(ctx)
    elif args.stage == "starts":
        run_starts(ctx, args.level or "coarse")
    elif args.stage == "fit":
        run_fit(ctx, args.level or "coarse", args.worker, args.workers, args.overwrite, args.limit)
    elif args.stage == "report":
        run_report(ctx)
    elif args.stage == "qc":
        run_qc(ctx, args.overwrite)


if __name__ == "__main__":
    main()
