#!/usr/bin/env python3
"""Profile where a QNP section could sit in the AHRAv2 atlas (gate 4), and export one plane.

The atlas is *resliced* at candidate planes (coronal, tilted by pitch about x and yaw
about z, through the left-MTG centroid shifted to y0) as gray/white tissue classes:
AHRAv2 gyral labels -> gray matter, forebrain white-matter labels -> white matter,
ventricles dropped.  The correspondence QNP gray/white <-> atlas gray/white is fixed in
advance, so scores share a feature space and no cross-modal law is learned here.

For each plane and each representation (the structural consensus as gray/white or as
tissue only, and each structural stain alone), a 2-D similarity (rotation, reflection,
isotropic scale, translation) is fitted by ``section_alignment.search`` and scored with
the fixed-scale footprint-restricted varifold score (0 = identical, 1 = no overlap).
Scores share the QNP reference measure, so they are comparable across planes.

Stages
------
``scan``       fit every (representation, plane); appends to ``plane_scores.csv`` and
               resumes.  Each row also records where the NeuN HALO cortical ribbon (not
               used by the fit) lands among atlas labels.
``summarize``  profiles, the stain-replicate noise scale, confidence sets, and the
               gray/white-vs-tissue-only comparison -> ``summary.json`` and figures.
``export``     write xIV inputs for the best plane of the primary representation: atlas
               plane particles (0.5 mm, MNI plane coordinates), the QNP consensus mapped
               into that plane by the fitted similarity, and ribbon QC points.  With
               ``export.annotation_maps`` set, the target also carries ``nu_Annot``: the
               positive-only HALO-annotated tissue area per particle (for the xIV anatomical
               term; ``preprocess/qnp_annotation_features.py``).
``atlas-features``  check the canonical one-hot anatomical atlas channels (STG/MTG/ITG gray,
               other gray, white; ``atlas_scan.anatomical_features``) against the segmentation and
               their fixed projections (gmwm, mtg_gm, anatomical) against the existing tables;
               figures of the channels on representative coronal planes -> ``atlas_features/``.
``graph``      write ``transform_graph.json``: slides -> QNP local frame -> each exported
               atlas-plane hypothesis (rigid scan + xIV fit, if run) -> MNI.
``evaluate``   after the xIV fit of an exported ``--plane``, map the pulled-back ribbon points to MNI and compare
               label landing with the rigid placement; atlas-correspondence figure.

Stacking coordinate (skill ``section-to-template-mapping`` steps 1-7, GPU; ``atlas_scan.stacking``;
computations in ``preprocess/qnp_stacking.py``; outputs in ``stacking.output_dir``)
``roles``         feature QC of each section's gray/white map -> anchor or passenger (``roles.json``).
``compress``      joint XY + mass compression of every section at each compressed level.
``slabs``         coronal slabs over the target region's atlas y-extent, one global 2-D search per slab.
``profile``       ``--level L``: per anchor, a fresh global 2-D search (both reflections) at every coronal
                  depth; delta (across-anchor noise) and within-delta windows.  Levels after the first
                  search only the previous windows, with the previous best poses as extra starts, and
                  extend past any window touching the searched range.  ``--families``: per-reflection-
                  family profiles (off by default).
``passengers``    passengers inherit an anchor's pose through the QNP<->QNP tissue-outline alignment,
                  re-checked by a direct GPU outline fit.
``stack-report``  depth-profile and best-pose figures, ``report.json`` and ``REPORT.md``.
``--region-prior`` applies the explicit dissection-region prior (atlas restricted to the cells near
``stacking.region_prior.regions``) to the stacking stages; results go to ``<output_dir>/region_prior/``.
``--landmark-slab`` applies the anatomical slab prior (``stacking.landmark_slab``; for MTG: SEA-AD
sampling at the first appearance of the LGN, 4 mm slabs of unknown cutting phase, the landmark slab
and its neighbours): ``slabs`` and ``profile`` search only that AP interval, ``stack-report`` adds
which candidate slabs the windows are consistent with.  Results go to ``<output_dir>/landmark_slab/``
(``region_prior__landmark_slab/`` with both priors).  Computations in ``preprocess/anatomical_slab.py``.
``candidates``    (with ``--region-prior`` and/or ``--landmark-slab``) per anchor, the unconstrained and the
                  admissible best placement on one data-only objective (full atlas), plus boundary,
                  support, pose and tilt diagnostics -> ``candidates.json``, ``candidates.png``.
``landmark``      (implies ``--landmark-slab``) locate the landmark, build the candidate slabs, write
                  ``landmark_slab.json`` and the 3-D slab, coronal-montage and sagittal figures.

Low scores are not anatomical validation; see ``summary.json`` for what is and is not
discriminated.

Usage::

    PYTHONPATH=src:src/config_setup:src/preprocess python src/scripts/scan_atlas_planes_for_qnp.py \
        --config configs/project_config.yaml --job H20.33.034_MTG --stage scan
"""

from __future__ import annotations

import argparse
import csv
import json
import os
import time
from concurrent.futures import ProcessPoolExecutor
from itertools import product
from pathlib import Path
from typing import Any

import numpy as np
from scipy import ndimage as ndi

from config_setup.project_config import load_config, resolve_path
from config_setup.qnp_jobs import resolve_qnp_job

FINE_ORDER_TAIL = ("other_gray_matter", "white_matter")
STACK_STAGES_CLI = ("roles", "compress", "slabs", "profile", "passengers", "stack-report", "landmark", "candidates")
LANDING_CLASSES = ("outside", "dropped")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--config", required=True)
    parser.add_argument("--job", required=True, help="Name under qnp_section_inputs (uses its atlas_scan block).")
    parser.add_argument("--stage", required=True,
                        choices=["scan", "summarize", "export", "evaluate", "graph", "atlas-features",
                                 *STACK_STAGES_CLI])
    parser.add_argument("--representation", action="append", help="Restrict --stage scan to these representations.")
    parser.add_argument("--plane", help="Export this plane id (pitch_yaw_y0) instead of the best.")
    parser.add_argument("--fit-dir", help="--stage evaluate: the xIV init_* directory.")
    parser.add_argument("--dense", action="store_true",
                        help="--stage scan/summarize: re-search the planes in atlas_scan.dense_search with its "
                             "settings, writing plane_scores_dense.csv (search-robustness check).")
    parser.add_argument("--level", help="--stage profile: stacking level (atlas_scan.stacking.levels); "
                                        "default: the first level not yet profiled")
    parser.add_argument("--families", action="store_true",
                        help="--stage profile: per-reflection-family depth profiles (flip fixed per family) "
                             "instead of one global search over both reflections (off by default)")
    parser.add_argument("--overwrite", action="store_true", help="--stage compress: recompute existing archives")
    parser.add_argument("--region-prior", action="store_true",
                        help="stacking stages: apply the explicit dissection-region prior (atlas_scan.stacking."
                             "region_prior); results go to <output_dir>/region_prior/")
    parser.add_argument("--landmark-slab", action="store_true",
                        help="stacking stages: restrict the AP search to the anatomical slab prior (atlas_scan."
                             "stacking.landmark_slab); results go to <output_dir>/landmark_slab/")
    return parser.parse_args()


# --------------------------------------------------------------------------------------
# Shared setup
# --------------------------------------------------------------------------------------

def atlas_setup(config: dict, scan: dict) -> dict[str, Any]:
    import csv as _csv

    import nibabel as nib
    from preprocess.atlas_features import DEFAULT_GRAY_REGIONS, anatomical_tables, check_gmwm_reproduces
    from preprocess.section_alignment import lookup_tables

    image = nib.load(str(resolve_path(config, scan["annotation_nifti"])))
    labels = np.asanyarray(image.dataobj).astype(np.int32)
    affine = np.asarray(image.affine, float)
    with open(resolve_path(config, scan["terminology_csv"]), newline="", encoding="utf-8") as stream:
        names = {int(r["annotation_value"]): r["name"] for r in _csv.DictReader(stream) if r["annotation_value"].strip()}
    failures = []
    for region, spec in scan["fine_regions"].items():
        for code in spec["codes"]:
            if names.get(int(code)) != spec["expected_name"]:
                failures.append(f"{region}: code {code} decodes to {names.get(int(code))!r}, expected {spec['expected_name']!r}")
    if failures:
        raise SystemExit("Terminology check failed:\n  " + "\n  ".join(failures))
    coarse, fine = lookup_tables(int(labels.max()), scan["white_matter_codes"], scan["drop_codes"],
                                 {k: v["codes"] for k, v in scan["fine_regions"].items()})
    # Canonical one-hot anatomical channels (STG/MTG/ITG gray, other gray, white); their gmwm
    # projection must equal ``coarse`` code for code, so every gm/wm consumer is unchanged.
    anatomical = anatomical_tables(int(labels.max()), scan["white_matter_codes"], scan["drop_codes"],
                                   {k: v["codes"] for k, v in scan["fine_regions"].items()},
                                   scan.get("anatomical_features", {}).get("gray_regions", DEFAULT_GRAY_REGIONS))
    check_gmwm_reproduces(anatomical, coarse)
    hemisphere_sign = -1.0 if scan.get("hemisphere", "left") == "left" else 1.0
    ijk = np.argwhere(fine[next(iter(scan["fine_regions"]))][labels])
    world = ijk @ affine[:3, :3].T + affine[:3, 3]
    world = world[np.sign(world[:, 0]) == hemisphere_sign]
    centroid = world.mean(0)
    return {"labels": labels, "affine": affine, "coarse": coarse, "fine": fine, "anatomical": anatomical, "names": names,
            "centroid": centroid, "region_extent_y": [float(world[:, 1].min()), float(world[:, 1].max())]}


def plane_geometry(atlas: dict, pitch: float, yaw: float, y0: float):
    from preprocess.section_alignment import plane_basis

    u, v, n = plane_basis(pitch, yaw)
    origin = np.array([atlas["centroid"][0], y0, atlas["centroid"][2]])
    return origin, u, v, n


def plane_id(pitch: float, yaw: float, y0: float) -> str:
    return f"p{pitch:+04.0f}_w{yaw:+04.0f}_y{y0:+06.1f}"


def plane_particles(atlas: dict, scan: dict, origin, u, v, spacing: float, aggregate: int, table: str):
    from preprocess.section_alignment import label_class_masses, reslice_labels

    grid, axis = reslice_labels(atlas["labels"], atlas["affine"], origin, u, v, float(scan["half_width_mm"]), spacing)
    return label_class_masses(grid, axis, spacing, atlas[table], aggregate)


def classify_points(atlas: dict, world: np.ndarray, region_names: list[str]) -> np.ndarray:
    """Index into region_names + ('outside', 'dropped') for each world point (nearest voxel)."""

    ijk = np.rint((world - atlas["affine"][:3, 3]) @ np.linalg.inv(atlas["affine"][:3, :3]).T).astype(int)
    shape = np.array(atlas["labels"].shape)
    inside = np.all((ijk >= 0) & (ijk < shape), axis=1)
    codes = np.zeros(len(world), int)
    codes[inside] = atlas["labels"][tuple(ijk[inside].T)]
    out = np.full(len(world), len(region_names) + 1)  # dropped by default
    out[codes == 0] = len(region_names)
    for k, name in enumerate(region_names):
        table = atlas["fine"][name]
        member = np.zeros(len(world), bool)
        valid = codes < len(table)
        member[valid] = table[codes[valid]]
        out[member] = k
    return out


def landing_fractions(atlas: dict, transform, origin, u, v, points_local: np.ndarray, region_names) -> dict[str, float]:
    plane = transform.section_to_moving(points_local)
    world = origin + plane[:, :1] * u + plane[:, 1:2] * v
    index = classify_points(atlas, world, region_names)
    names = list(region_names) + list(LANDING_CLASSES)
    counts = np.bincount(index, minlength=len(names)) / max(len(index), 1)
    return dict(zip(names, counts.tolist()))


def representation_inputs(config: dict, job: dict, scan: dict) -> dict[str, dict]:
    from preprocess.particle_utils import load_particle_archive

    out = {}
    for name, spec in scan["representations"].items():
        X, nu, meta = load_particle_archive(resolve_path(config, spec["particles"]), "nu_Sub")
        if meta.get("coordinate_space") != "qnp_local_mm":
            raise ValueError(f"{name}: expected qnp_local_mm particles, got {meta.get('coordinate_space')!r}")
        out[name] = {"X": X[:, :2].astype(np.float64), "nu": nu.astype(np.float64), "mode": spec["features"]}
    return out


# --------------------------------------------------------------------------------------
# Stage: scan
# --------------------------------------------------------------------------------------

def effective_scan(scan: dict, dense: bool) -> dict:
    """The scan settings, with atlas_scan.dense_search overrides when ``dense``."""

    if not dense:
        return scan
    overrides = {k: v for k, v in scan["dense_search"].items() if k not in ("planes", "representations")}
    return {**scan, **overrides}


def scores_table(out_dir: Path, dense: bool) -> Path:
    return out_dir / ("plane_scores_dense.csv" if dense else "plane_scores.csv")


_WORKER: dict[str, Any] = {}


def _init_worker(config_path: str, job_name: str, names: list[str], dense: bool = False) -> None:
    os.environ.setdefault("OMP_NUM_THREADS", "1")
    from preprocess.section_alignment import FootprintScorer

    config = load_config(config_path)
    job = resolve_qnp_job(config, job_name)
    scan = effective_scan(job["atlas_scan"], dense)
    reps = {k: v for k, v in representation_inputs(config, job, scan).items() if k in names}
    sigmas = [float(s) for s in scan.get("score_sigmas_mm", [2.0, 1.0, 0.5])]
    scorers = {}
    for name, rep in reps.items():
        nu = rep["nu"].sum(1, keepdims=True) if rep["mode"] == "tissue" else rep["nu"]
        scorers[name] = FootprintScorer(rep["X"], nu, sigmas)
    with np.load(resolve_path(config, scan["ribbon_points"])) as archive:
        ribbon = archive["X"][:, :2].astype(np.float64)
    _WORKER.update(config=config, scan=scan, atlas=atlas_setup(config, scan), reps=reps, scorers=scorers,
                   ribbon=ribbon[:: int(scan.get("ribbon_subsample", 10))])


def _fit_plane(task: tuple[float, float, float]) -> list[dict[str, Any]]:
    from preprocess.section_alignment import search

    pitch, yaw, y0 = task
    scan, atlas = _WORKER["scan"], _WORKER["atlas"]
    origin, u, v, n = plane_geometry(atlas, pitch, yaw, y0)
    spacing, aggregate = float(scan["reslice_mm"]), int(round(float(scan["scan_bin_mm"]) / float(scan["reslice_mm"])))
    P, nu_P = plane_particles(atlas, scan, origin, u, v, spacing, aggregate, "coarse")
    regions = list(scan["fine_regions"]) + list(FINE_ORDER_TAIL)
    rows = []
    for name, rep in _WORKER["reps"].items():
        base = {"representation": name, "plane_id": plane_id(pitch, yaw, y0), "pitch_deg": pitch, "yaw_deg": yaw,
                "y0_mm": y0, "atlas_particles": int(len(P)), "atlas_area_mm2": float(nu_P.sum())}
        if len(P) < 10:
            rows.append({**base, "score": 1.0, "status": "empty_plane"})
            continue
        mu = nu_P.sum(1, keepdims=True) if rep["mode"] == "tissue" else nu_P
        ranked = search(_WORKER["scorers"][name], P[:, :2], mu,
                        thetas=np.arange(0, 360, float(scan.get("theta_step_deg", 15))),
                        scales=[float(s) for s in scan["scale_grid"]], flips=[False, True],
                        scale_bounds=tuple(float(s) for s in scan["scale_bounds"]),
                        h=float(scan.get("fft_grid_mm", 1.0)), blur_mm=float(scan.get("fft_blur_mm", 1.5)),
                        refine_top=int(scan.get("refine_top", 2)), max_evals=int(scan.get("max_evals", 150)))
        score, t = ranked[0]
        other = [s for s, c in ranked if c.flip != t.flip]
        landing = landing_fractions(atlas, t, origin, u, v, _WORKER["ribbon"], regions)
        rows.append({**base, "score": score, "status": "ok", "theta_deg": t.theta_deg, "scale": t.scale,
                     "flip": t.flip, "tau_x": t.tau[0], "tau_y": t.tau[1],
                     "best_other_flip_score": min(other) if other else None,
                     **{f"ribbon_on_{k}": val for k, val in landing.items()}})
    return rows


def run_scan(args, config, job, scan, out_dir: Path) -> None:
    if args.dense:
        dense = scan["dense_search"]
        names = args.representation or list(dense["representations"])
        planes = [(float(p), float(w), float(y)) for p, w, ys in dense["planes"] for y in ys]
    else:
        names = args.representation or list(scan["representations"])
        planes = list(product([float(v) for v in scan["pitch_deg"]], [float(v) for v in scan["yaw_deg"]],
                              np.arange(float(scan["y_range_mm"][0]), float(scan["y_range_mm"][1]) + 1e-9,
                                        float(scan["y_step_mm"])).round(2).tolist()))
    table = scores_table(out_dir, args.dense)
    done = set()
    if table.exists():
        with open(table, newline="") as stream:
            done = {(r["representation"], r["plane_id"]) for r in csv.DictReader(stream)}
    todo = [p for p in planes if any((n, plane_id(*p)) not in done for n in names)]
    print(f"{len(planes)} planes x {len(names)} representations; {len(todo)} planes to fit", flush=True)
    regions = list(scan["fine_regions"]) + list(FINE_ORDER_TAIL)
    fieldnames = (["representation", "plane_id", "pitch_deg", "yaw_deg", "y0_mm", "atlas_particles", "atlas_area_mm2",
                   "score", "status", "theta_deg", "scale", "flip", "tau_x", "tau_y", "best_other_flip_score"]
                  + [f"ribbon_on_{k}" for k in regions + list(LANDING_CLASSES)])
    with ProcessPoolExecutor(int(scan.get("workers", 8)), initializer=_init_worker,
                             initargs=(args.config, args.job, names, args.dense)) as pool:
        for count, rows in enumerate(pool.map(_fit_plane, todo, chunksize=1), start=1):
            rows = [r for r in rows if (r["representation"], r["plane_id"]) not in done]
            with open(table, "a", newline="") as stream:
                writer = csv.DictWriter(stream, fieldnames=fieldnames, extrasaction="ignore")
                if stream.tell() == 0:
                    writer.writeheader()
                writer.writerows(rows)
            if count % 10 == 0 or count == len(todo):
                best = min(rows, key=lambda r: r["score"])
                print(f"{count}/{len(todo)} planes; last {best['plane_id']} best {best['representation']} "
                      f"{best['score']:.3f}", flush=True)


# --------------------------------------------------------------------------------------
# Stage: summarize
# --------------------------------------------------------------------------------------

def load_scores(out_dir: Path) -> dict[str, list[dict]]:
    by_rep: dict[str, list[dict]] = {}
    with open(out_dir / "plane_scores.csv", newline="") as stream:
        for row in csv.DictReader(stream):
            for key, value in list(row.items()):
                try:
                    row[key] = float(value) if key not in ("representation", "plane_id", "status", "flip") else value
                except ValueError:
                    pass
            by_rep.setdefault(row["representation"], []).append(row)
    return by_rep


def run_summarize(config, job, scan, out_dir: Path) -> dict[str, Any]:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    by_rep = load_scores(out_dir)
    primary = scan["primary_representation"]
    replicates = [r for r in scan.get("replicate_representations", []) if r in by_rep]
    regions = list(scan["fine_regions"]) + list(FINE_ORDER_TAIL)
    target_region = next(iter(scan["fine_regions"]))

    # Stain-replicate noise scale: at each plane, each stain's score relative to its own
    # best; the SD across stains measures how much a score difference depends on which
    # stain represented the section.  delta = its median over the primary top planes.
    index = {r: {row["plane_id"]: row for row in by_rep[r]} for r in by_rep}
    planes = sorted(index[primary], key=lambda p: index[primary][p]["score"])
    delta = None
    if len(replicates) >= 2:
        rel = {r: {p: row["score"] - min(x["score"] for x in by_rep[r]) for p, row in index[r].items()} for r in replicates}
        top = planes[: int(scan.get("noise_top_planes", 20))]
        sds = [float(np.std([rel[r][p] for r in replicates if p in rel[r]], ddof=1)) for p in top]
        delta = float(np.median(sds))

    summary: dict[str, Any] = {"primary_representation": primary, "replicates": replicates,
                               "stain_replicate_noise_delta": delta,
                               "delta_definition": "median over the primary's top planes of the across-stain SD of "
                                                   "(stain score - that stain's best score)", "representations": {}}
    for rep, rows in by_rep.items():
        ok = [r for r in rows if r.get("status") == "ok"]
        ok.sort(key=lambda r: r["score"])
        best = ok[0]
        scores = np.array([r["score"] for r in ok])
        entry = {"best": {k: best[k] for k in best if not k.startswith("ribbon_on_")},
                 "best_ribbon_landing": {k[10:]: best[k] for k in best if k.startswith("ribbon_on_")},
                 "score_quantiles": dict(zip(["min", "p10", "median", "max"],
                                             np.percentile(scores, [0, 10, 50, 100]).tolist())),
                 "contrast_median_minus_best": float(np.median(scores) - scores[0]),
                 "top5": [{k: r[k] for k in ("plane_id", "score", "scale", "theta_deg", "flip",
                                             f"ribbon_on_{target_region}")} for r in ok[:5]]}
        if delta is not None:
            members = [r for r in ok if r["score"] <= scores[0] + delta]
            entry["confidence_set"] = {
                "rule": "score <= best + delta (stain-replicate noise)", "size": len(members),
                "fraction_of_planes": len(members) / len(ok),
                "y0_range_mm": [min(r["y0_mm"] for r in members), max(r["y0_mm"] for r in members)],
                "pitch_values": sorted({r["pitch_deg"] for r in members}),
                "yaw_values": sorted({r["yaw_deg"] for r in members}),
                "flip_values": sorted({r["flip"] for r in members}),
                "scale_range": [min(r["scale"] for r in members), max(r["scale"] for r in members)],
                f"ribbon_on_{target_region}_range": [min(r[f"ribbon_on_{target_region}"] for r in members),
                                                     max(r[f"ribbon_on_{target_region}"] for r in members)],
                "contrast_in_delta_units": entry["contrast_median_minus_best"] / delta if delta else None,
            }
        summary["representations"][rep] = entry
    if replicates:
        bests = {r: summary["representations"][r]["best"] for r in replicates}
        summary["replicate_best_planes"] = {r: {k: b[k] for k in ("plane_id", "y0_mm", "pitch_deg", "yaw_deg", "score", "flip")}
                                            for r, b in bests.items()}
    if scores_table(out_dir, True).exists():
        summary["dense_basins"] = summarize_dense(out_dir, scan, delta, target_region, plt)
    (out_dir / "summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")

    # ---- figures ----------------------------------------------------------------------
    reps = list(by_rep)
    orientations = sorted({(r["pitch_deg"], r["yaw_deg"]) for r in by_rep[primary]})
    fig, axes = plt.subplots(len(reps), 1, figsize=(11, 3.2 * len(reps)), sharex=True, constrained_layout=True,
                             squeeze=False)
    cmap = plt.get_cmap("viridis", len(orientations))
    for ax, rep in zip(axes[:, 0], reps):
        for k, (pitch, yaw) in enumerate(orientations):
            rows = sorted((r for r in by_rep[rep] if r["pitch_deg"] == pitch and r["yaw_deg"] == yaw and r.get("status") == "ok"),
                          key=lambda r: r["y0_mm"])
            ax.plot([r["y0_mm"] for r in rows], [r["score"] for r in rows], color=cmap(k), lw=1.2,
                    label=f"pitch {pitch:+.0f}°, yaw {yaw:+.0f}°")
        best = summary["representations"][rep]["best"]
        ax.axhline(best["score"], color="#1a1a19", lw=0.6)
        if delta is not None:
            ax.axhspan(best["score"], best["score"] + delta, color="#eda100", alpha=0.25, lw=0,
                       label="best + stain-replicate noise δ")
        ax.set_ylabel("score (0 = identical)")
        ax.set_title(f"{rep}: best {best['plane_id']} score {best['score']:.3f}", fontsize=10)
    axes[0, 0].legend(loc="upper left", bbox_to_anchor=(1.01, 1.0), fontsize=8, frameon=False)
    axes[-1, 0].set_xlabel("plane origin y0 (MNI mm, through the left-MTG centroid in x, z)")
    fig.savefig(out_dir / "score_profiles.png", dpi=130)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(7, 5.5), constrained_layout=True)
    for rep in reps:
        ok = [r for r in by_rep[rep] if r.get("status") == "ok"]
        ax.scatter([r["score"] for r in ok], [r[f"ribbon_on_{target_region}"] for r in ok], s=8, label=rep, alpha=0.6)
    ax.set_xlabel("plane score (lower = better)")
    ax.set_ylabel(f"fraction of NeuN HALO ribbon on atlas {target_region}")
    ax.set_title("Does a better score put the annotated cortex on the atlas MTG?\n(ribbon not used by the fit)", fontsize=10)
    ax.legend(fontsize=8, frameon=False)
    fig.savefig(out_dir / "score_vs_ribbon_landing.png", dpi=130)
    plt.close(fig)
    print(json.dumps({k: summary[k] for k in ("stain_replicate_noise_delta",)}, indent=2))
    for rep, entry in summary["representations"].items():
        print(rep, json.dumps({"best": entry["best"]["plane_id"], "score": round(entry["best"]["score"], 4),
                               "contrast": round(entry["contrast_median_minus_best"], 4),
                               "confidence_set": {k: entry.get("confidence_set", {}).get(k) for k in
                                                  ("size", "y0_range_mm", "pitch_values", "yaw_values", "flip_values",
                                                   f"ribbon_on_{target_region}_range")},
                               "ribbon_landing": {k: round(v, 3) for k, v in entry["best_ribbon_landing"].items()}}))
    return summary


def summarize_dense(out_dir: Path, scan: dict, delta: float | None, target_region: str, plt) -> dict[str, Any]:
    """Per orientation of the dense re-search: each representation's minimum, the
    y-width of its basin (score <= min + delta), and pose consistency inside it."""

    rows = []
    with open(scores_table(out_dir, True), newline="") as stream:
        for row in csv.DictReader(stream):
            rows.append({k: (v if k in ("representation", "plane_id", "status", "flip") else float(v))
                         for k, v in row.items() if v != ""})
    orientations = sorted({(r["pitch_deg"], r["yaw_deg"]) for r in rows})
    reps = list(dict.fromkeys(r["representation"] for r in rows))
    basins: dict[str, Any] = {}
    fig, axes = plt.subplots(1, len(orientations), figsize=(7 * len(orientations), 4.5), constrained_layout=True,
                             squeeze=False)
    for ax, (pitch, yaw) in zip(axes[0], orientations):
        key = f"pitch{pitch:+.0f}_yaw{yaw:+.0f}"
        basins[key] = {}
        for rep in reps:
            sel = sorted((r for r in rows if r["representation"] == rep and r["pitch_deg"] == pitch
                          and r["yaw_deg"] == yaw), key=lambda r: r["y0_mm"])
            best = min(sel, key=lambda r: r["score"])
            inside = [r for r in sel if delta is not None and r["score"] <= best["score"] + delta]
            basins[key][rep] = {
                "best_y0_mm": best["y0_mm"], "best_score": best["score"], "scale": best["scale"],
                "theta_deg": best["theta_deg"] % 360, "flip": best["flip"],
                f"ribbon_on_{target_region}": best[f"ribbon_on_{target_region}"],
                "ribbon_on_FuG": best.get("ribbon_on_FuG"),
                "basin_y0_range_mm": [min(r["y0_mm"] for r in inside), max(r["y0_mm"] for r in inside)] if inside else None,
            }
            ax.plot([r["y0_mm"] for r in sel], [r["score"] for r in sel], marker="o", ms=3, lw=1.2, label=rep)
        ax.set_title(f"dense re-search, pitch {pitch:+.0f}°, yaw {yaw:+.0f}°", fontsize=10)
        ax.set_xlabel("plane origin y0 (MNI mm)")
        ax.set_ylabel("score (0 = identical)")
    axes[0, 0].legend(fontsize=8, frameon=False)
    fig.savefig(out_dir / "dense_basin_profiles.png", dpi=130)
    plt.close(fig)
    return basins


# --------------------------------------------------------------------------------------
# Stage: export
# --------------------------------------------------------------------------------------

def run_export(args, config, job, scan, out_dir: Path) -> None:
    from preprocess.atlas_features import projection_matrix, projection_metadata, project
    from preprocess.particle_utils import FeatureDefinition, load_particle_archive, save_particle_archive
    from preprocess.section_alignment import FootprintScorer, Similarity2D
    from preprocess.xmodmap_compat import entropy_numpy, load_xmodmap, write_vtk_xyz

    by_rep = load_scores(out_dir)
    primary = scan["primary_representation"]
    rows = [r for r in by_rep[primary] if r.get("status") == "ok"]
    row = (next(r for r in rows if r["plane_id"] == args.plane) if args.plane else min(rows, key=lambda r: r["score"]))
    t = Similarity2D(row["theta_deg"], row["scale"], row["flip"] == "True", (row["tau_x"], row["tau_y"]))
    atlas = atlas_setup(config, scan)
    origin, u, v, n = plane_geometry(atlas, row["pitch_deg"], row["yaw_deg"], row["y0_mm"])
    export = scan["export"]
    spacing = float(export["bin_mm"])
    P, nu_coarse = plane_particles(atlas, scan, origin, u, v, spacing, 1, "coarse")
    _, nu_fine = plane_particles(atlas, scan, origin, u, v, spacing, 1, "fine")
    _, nu_anat = plane_particles(atlas, scan, origin, u, v, spacing, 1, "anatomical")
    if len(P) != len(nu_fine) or len(P) != len(nu_anat):
        raise RuntimeError("coarse, fine and anatomical plane particles differ; check the label tables")
    anat_names = list(atlas["anatomical"])
    if not np.array_equal(project(nu_anat, projection_matrix("gmwm", anat_names)[1]), nu_coarse):
        raise RuntimeError("gmwm projection of the anatomical features differs from the gray/white features")

    target_file = resolve_path(config, export["target_particles"])
    X_q, nu_q, meta_q = load_particle_archive(target_file, "nu_Sub")
    annotation = None  # (masses in QNP local mm^2 or None, record); None without export.annotation_maps
    if export.get("annotation_maps"):
        from preprocess.qnp_annotation_features import ANNOTATION_FEATURE, annotated_tissue_masses
        annotation = annotated_tissue_masses(resolve_path(config, export["annotation_maps"]), X_q, nu_q,
                                             meta_q["particles"]["downsample_factor"])
    # Default: keep only atlas particles near the rigidly placed section.  With
    # restrict_source_to_footprint: false the whole in-plane window (half_width_mm) is kept, so
    # neighbouring gyri (STG, insula, FuG, ...) stay in the source; xIV's support censors them.
    restrict = bool(export.get("restrict_source_to_footprint", True))
    if restrict:
        support = FootprintScorer(X_q[:, :2], nu_q, [1.0], footprint_sigma_mm=float(export["support_sigma_mm"]))
        keep = support.footprint(t.moving_to_section(P[:, :2])) > float(export["support_min_weight"])
    else:
        keep = np.ones(len(P), dtype=bool)
    regions = list(scan["fine_regions"]) + list(FINE_ORDER_TAIL)
    features = FeatureDefinition(fine_ids=tuple(range(len(regions))), fine_names=tuple(regions),
                                 coarse_names=("gray_matter", "white_matter"),
                                 fine_to_coarse=tuple(1 if r == "white_matter" else 0 for r in regions))
    plane_meta = {"origin_mm": origin.tolist(), "u_axis": u.tolist(), "v_axis": v.tolist(), "normal": n.tolist(),
                  "pitch_deg": row["pitch_deg"], "yaw_deg": row["yaw_deg"], "y0_mm": row["y0_mm"],
                  "plane_id": row["plane_id"], "reslice": "nearest-neighbour labels on a regular in-plane grid",
                  "inverse": "world = origin + plane_X[:, 0] * u_axis + plane_X[:, 1] * v_axis",
                  "status": "best plane of a discrete scan; a hypothesis, not an estimate of the cutting plane"}
    api = load_xmodmap(config)
    writer = lambda points, arrays, names, filename: write_vtk_xyz(api, points, arrays, names, filename)
    entropy = lambda nu: entropy_numpy(api, nu)
    paths = {k: resolve_path(config, export[k].format(plane_id=row["plane_id"]))
             for k in ("source_npz", "target_npz", "qc_points_npz")}
    save_particle_archive(paths["source_npz"], P[keep], nu_coarse[keep], nu_fine[keep], features, {
        "particle_role": "source_atlas_plane", "coordinate_space": "mni_icbm2009b_symmetric_plane",
        "plane": plane_meta, "atlas_annotation": str(resolve_path(config, scan["annotation_nifti"])),
        "label_grouping": {"white_matter_codes": scan["white_matter_codes"], "drop_codes": scan["drop_codes"],
                           "fine_regions": scan["fine_regions"], "gray_matter": "every other non-zero code"},
        "support_restriction": ({"rule": "QNP footprint weight at the rigidly placed position > support_min_weight",
                                 **{k: export[k] for k in ("support_sigma_mm", "support_min_weight")}} if restrict else
                                {"rule": "none: the whole in-plane window (restrict_source_to_footprint false)",
                                 "half_width_mm": scan["half_width_mm"]}),
        "anatomical_features": {"key": "nu_Anat", "names": anat_names,
                                "rule": "one-hot label channels (preprocess/atlas_features.py); nu_Sub = gmwm projection",
                                "projections": projection_metadata(anat_names)},
        "mass_units": "mm^2 (in-plane pixel area)"}, vtk_writer=writer, entropy_function=entropy,
        extra_arrays={"nu_Anat": nu_anat[keep].astype(np.float32),
                      "anatomical_feature_names": np.asarray(anat_names, dtype=str)})

    Y = t.section_to_moving(X_q[:, :2])
    target_X = np.column_stack([Y, np.zeros(len(Y))])
    similarity = {**t.as_dict(), "from": "qnp_local_mm", "to": "atlas plane mm", "plane_id": row["plane_id"],
                  "uncertainty": "one member of the scan's confidence set; see summary.json"}
    target_meta = {**meta_q, "particle_role": "target_qnp_in_atlas_plane",
                   "coordinate_space": "qnp_local_in_atlas_plane_mm", "source_particles": str(target_file),
                   "similarity_qnp_local_to_plane": similarity, "plane": plane_meta,
                   "mass_units": "mm^2 in atlas-plane units (QNP area * scale^2)"}
    target_extra = None
    if annotation is not None:
        masses, annotation_record = annotation
        target_meta["annotation_supervision"] = {**annotation_record, "key": "nu_Annot",
                                                 "mass_units": "mm^2 in atlas-plane units (annotated area * scale^2)"}
        if masses is not None:
            target_extra = {"nu_Annot": (masses * t.scale ** 2).astype(np.float32),
                            "annotation_feature_names": np.asarray([ANNOTATION_FEATURE], dtype=str)}
    save_particle_archive(paths["target_npz"], target_X, nu_q * t.scale ** 2, nu_q * t.scale ** 2,
                          FeatureDefinition((0, 1), ("gray_matter", "white_matter"), ("gray_matter", "white_matter"), (0, 1)),
                          target_meta, vtk_writer=writer, entropy_function=entropy, extra_arrays=target_extra)
    with np.load(resolve_path(config, scan["ribbon_points"])) as archive:
        ribbon_X, depth = archive["X"][:, :2].astype(np.float64), archive["depth_from_pia_um"]
    ribbon_plane = t.section_to_moving(ribbon_X)
    np.savez_compressed(paths["qc_points_npz"], X=np.column_stack([ribbon_plane, np.zeros(len(ribbon_plane))]).astype(np.float32),
                        depth_from_pia_um=depth, depth_units=np.asarray("um of QNP (unscaled) tissue"),
                        coordinate_space=np.asarray("qnp_local_in_atlas_plane_mm"))
    record = {"plane": plane_meta, "similarity_qnp_local_to_plane": similarity, "source_particles": int(keep.sum()),
              "source_area_mm2": float(nu_coarse[keep].sum()), "target_particles": int(len(Y)),
              "target_area_mm2_plane_units": float((nu_q * t.scale ** 2).sum()),
              "rigid_ribbon_landing": landing_fractions(atlas, t, origin, u, v, ribbon_X, regions),
              "paths": {k: str(p) for k, p in paths.items()}}
    if annotation is not None:
        record["annotation_supervision"] = annotation[1]
    # export.record_subdir (default: the scan directory itself) keeps a second export set's records apart from the
    # original ones, which --stage graph globs in the scan directory.
    record_dir = out_dir / str(export.get("record_subdir", ""))
    record_dir.mkdir(parents=True, exist_ok=True)
    (record_dir / f"export_{row['plane_id']}.json").write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({k: record[k] for k in ("source_particles", "source_area_mm2", "target_particles",
                                              "target_area_mm2_plane_units", "rigid_ribbon_landing")}, indent=2))


# --------------------------------------------------------------------------------------
# Stage: atlas-features (canonical one-hot anatomical channels: checks and figures)
# --------------------------------------------------------------------------------------

ANATOMY_COLORS = {"STG_gray_matter": "#eb6834", "MTG_gray_matter": "#2a78d6", "ITG_gray_matter": "#1baf7a",
                  "other_gray_matter": "#e6e4dc", "white_matter": "#c4c2b9"}
GMWM_COLORS = {"gray_matter": "#8c8a82", "white_matter": "#dcdad2"}


def _anatomy_checks(atlas: dict, scan: dict, config: dict) -> dict[str, Any]:
    """Channel voxel counts by table lookup vs an independent np.isin path (and Allen volumes)."""

    from preprocess.atlas_features import label_channel_index, projected_tables

    labels, tables = atlas["labels"], atlas["anatomical"]
    index = label_channel_index(tables)[labels]
    wm, drop = np.isin(labels, scan["white_matter_codes"]), np.isin(labels, scan["drop_codes"]) | (labels == 0)
    regions = scan.get("anatomical_features", {}).get("gray_regions", ["STG", "MTG", "ITG"])
    region_codes = {r: scan["fine_regions"][r]["codes"] for r in regions}
    named = np.isin(labels, sum(region_codes.values(), []))
    expected = {f"{r}_gray_matter": np.isin(labels, c) & ~wm & ~drop for r, c in region_codes.items()}
    expected["other_gray_matter"] = ~wm & ~drop & ~named
    expected["white_matter"] = wm
    channels = {}
    for k, name in enumerate(tables):
        got = index == k
        channels[name] = {"voxels": int(got.sum()), "expected_voxels_isin": int(expected[name].sum()),
                          "voxels_differing": int((got != expected[name]).sum())}
    volumes_csv = scan.get("anatomical_features", {}).get("parcellation_volumes_csv")
    if volumes_csv:
        with open(resolve_path(config, scan["terminology_csv"]), newline="", encoding="utf-8") as stream:
            ident = {int(r["annotation_value"]): r["identifier"] for r in csv.DictReader(stream) if r["annotation_value"].strip()}
        with open(resolve_path(config, volumes_csv), newline="", encoding="utf-8") as stream:
            allen = {r["identifier"]: int(r["voxel_count"]) for r in csv.DictReader(stream)}
        for r, codes in region_codes.items():
            channels[f"{r}_gray_matter"]["allen_parcellation_voxels"] = int(sum(allen[ident[c]] for c in codes))
    coarse_index = np.full(len(atlas["coarse"]["gray_matter"]), -1, np.int16)
    for k, table in enumerate(atlas["coarse"].values()):
        coarse_index[table] = k
    gm_from_anat = projected_tables(tables, "gmwm")
    gm_index = np.full(len(coarse_index), -1, np.int16)
    for k, table in enumerate(gm_from_anat.values()):
        gm_index[table] = k
    return {"channels": channels,
            "unassigned_nonzero_voxels": int(((index < 0) & ~drop).sum()),
            "gmwm_projection_voxels_differing": int((gm_index[labels] != coarse_index[labels]).sum())}


def _other_gray_codes(atlas: dict, ys, half: float, hemisphere_sign: float) -> list[dict[str, Any]]:
    """Codes that make up other_gray_matter on the figure planes (one hemisphere), by area."""

    from preprocess.section_alignment import plane_basis, reslice_labels

    u, v, _ = plane_basis(0.0, 0.0)
    counts: dict[int, int] = {}
    for y in ys:
        origin = np.array([atlas["centroid"][0], y, atlas["centroid"][2]])
        grid, axis = reslice_labels(atlas["labels"], atlas["affine"], origin, u, v, half, 0.5)
        same_side = np.sign(atlas["centroid"][0] + axis)[None, :] == hemisphere_sign
        codes = grid[atlas["anatomical"]["other_gray_matter"][np.clip(grid, 0, None)] & same_side]
        for c, n in zip(*np.unique(codes, return_counts=True)):
            counts[int(c)] = counts.get(int(c), 0) + int(n)
    return [{"code": c, "name": atlas["names"].get(c), "area_mm2": n * 0.25}
            for c, n in sorted(counts.items(), key=lambda item: -item[1])]


def _channel_image(atlas: dict, y: float, half: float, res: float = 0.25):
    from preprocess.atlas_features import label_channel_index
    from preprocess.section_alignment import plane_basis, reslice_labels

    u, v, _ = plane_basis(0.0, 0.0)
    origin = np.array([atlas["centroid"][0], y, atlas["centroid"][2]])
    grid, axis = reslice_labels(atlas["labels"], atlas["affine"], origin, u, v, half, res)
    index = label_channel_index(atlas["anatomical"])
    return index[np.clip(grid, 0, len(index) - 1)], atlas["centroid"][0] + axis, atlas["centroid"][2] + axis


def _draw_channels(ax, img, xs, zs, names, colors, label_names=()):
    from matplotlib.colors import ListedColormap

    step = xs[1] - xs[0]
    ax.imshow(img + 1, origin="lower", extent=(xs[0] - step / 2, xs[-1] + step / 2, zs[0] - step / 2, zs[-1] + step / 2),
              cmap=ListedColormap(["#ffffff"] + [colors[n] for n in names]), vmin=-0.5, vmax=len(names) + 0.5,
              interpolation="nearest")
    ax.contour(xs, zs, (img >= 0).astype(float), [0.5], colors="#52514e", linewidths=0.5)
    for k, name in enumerate(names):
        if name not in label_names:
            continue
        mask = img == k
        if mask.sum() < 40:
            continue
        lab, n = ndi.label(mask)
        biggest = 1 + int(np.argmax(ndi.sum(mask, lab, range(1, n + 1))))
        iz, ix = np.unravel_index(np.argmax(ndi.distance_transform_edt(lab == biggest)), mask.shape)
        ax.text(xs[ix], zs[iz], name.split("_")[0], fontsize=7, ha="center", va="center", color=INK,
                bbox=dict(boxstyle="round,pad=0.15", fc="white", ec="none", alpha=0.8))
    ax.set_aspect("equal")
    ax.tick_params(labelsize=7)


def run_atlas_features(config, job, scan, out_dir: Path) -> None:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.patches import Patch

    from preprocess.atlas_features import PROJECTIONS, label_channel_index, project, projection_matrix

    atlas = atlas_setup(config, scan)
    feats = scan.get("anatomical_features", {})
    ys = [float(y) for y in feats.get("figure_y_mm", np.linspace(*atlas["region_extent_y"], 7)[1:-1].round(1))]
    reference_y = float(feats.get("reference_y_mm", ys[len(ys) // 2]))
    half = float(feats.get("figure_half_width_mm", scan["half_width_mm"]))
    names = list(atlas["anatomical"])
    target = f"{next(iter(scan['fine_regions']))}_gray_matter"
    sign = -1.0 if scan.get("hemisphere", "left") == "left" else 1.0
    fig_dir = out_dir / "atlas_features"
    fig_dir.mkdir(parents=True, exist_ok=True)

    # Plane-level checks at the particle level the scan and export use (reslice_mm pixels).
    spacing = float(scan["reslice_mm"])
    planes = []
    for y in sorted(set(ys + [reference_y])):
        origin, u, v, _ = plane_geometry(atlas, 0.0, 0.0, y)
        P, nu_coarse = plane_particles(atlas, scan, origin, u, v, spacing, 1, "coarse")
        P2, nu_fine = plane_particles(atlas, scan, origin, u, v, spacing, 1, "fine")
        P3, nu_anat = plane_particles(atlas, scan, origin, u, v, spacing, 1, "anatomical")
        if not (np.array_equal(P, P3) and np.array_equal(P2, P3)):
            raise RuntimeError(f"plane y {y}: particle sets differ between feature tables")
        row = {"y_mm": y, "particles": int(len(P)),
               "one_hot": bool(np.all((nu_anat > 0).sum(1) == 1)),
               "area_mm2": dict(zip(names, nu_anat.sum(0).round(3).tolist()))}
        for name in PROJECTIONS:
            row[f"max_abs_diff_{name}"] = float(np.abs(project(nu_anat, projection_matrix(name, names)[1]) - {
                "gmwm": nu_coarse, "mtg_gm": nu_fine[:, [list(atlas["fine"]).index(target.split("_")[0])]],
                "anatomical": nu_anat}[name]).max())
        planes.append(row)

    volume = _anatomy_checks(atlas, scan, config)
    other = _other_gray_codes(atlas, ys, half, sign)
    unnamed = sorted(int(c) for c in np.unique(atlas["labels"]) if c and c not in atlas["names"])
    index = label_channel_index(atlas["anatomical"])
    record = {
        "channels": names, "gray_regions": feats.get("gray_regions", ["STG", "MTG", "ITG"]),
        "volume_checks": volume, "plane_checks": planes,
        "other_gray_matter_codes_on_figure_planes": {
            "hemisphere": scan.get("hemisphere", "left"), "half_width_mm": half, "codes": other[:25]},
        "unnamed_codes": [{"code": c, "voxels": int((atlas["labels"] == c).sum()),
                           "channel": names[index[c]] if index[c] >= 0 else None} for c in unnamed],
        "passed": bool(all(ch["voxels_differing"] == 0 and ch.get("allen_parcellation_voxels", ch["voxels"]) == ch["voxels"]
                           for ch in volume["channels"].values())
                       and volume["unassigned_nonzero_voxels"] == 0 and volume["gmwm_projection_voxels_differing"] == 0
                       and all(p["one_hot"] and max(p[f"max_abs_diff_{n}"] for n in PROJECTIONS) == 0 for p in planes)),
    }
    (fig_dir / "atlas_features.json").write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")

    # Figure 1: the five channels on representative coronal planes.
    fig, axes = plt.subplots(1, len(ys), figsize=(3.1 * len(ys), 3.9), constrained_layout=True, squeeze=False)
    for ax, y in zip(axes[0], ys):
        img, xs, zs = _channel_image(atlas, y, half)
        _draw_channels(ax, img, xs, zs, names, ANATOMY_COLORS, label_names=names[:-2])
        ax.set_title(f"coronal y = {y:g} mm", fontsize=9)
        ax.set_xlabel("MNI x (mm)", fontsize=8)
    axes[0][0].set_ylabel("MNI z (mm)", fontsize=8)
    fig.legend([Patch(fc=ANATOMY_COLORS[n], ec="#52514e", lw=0.4) for n in names],
               [n.replace("_", " ") for n in names], loc="outside lower center", ncol=len(names), frameon=False, fontsize=8)
    fig.suptitle("AHRAv2 anatomical atlas channels (one-hot; dropped codes and background white)", fontsize=10)
    fig.savefig(fig_dir / "anatomical_channels.png", dpi=150)
    plt.close(fig)

    # Figure 2: the three fixed projections of one plane.
    img, xs, zs = _channel_image(atlas, reference_y, half)
    fig, axes = plt.subplots(1, 3, figsize=(10.5, 4.2), constrained_layout=True)
    for ax, name in zip(axes, ("gmwm", "mtg_gm", "anatomical")):
        out_names, M = projection_matrix(name, names)
        # Pixel-level projection: a one-hot pixel takes the projected channel that receives it.
        proj = np.full(img.shape, -1, int)
        for j, row in enumerate(M):
            proj[np.isin(img, np.flatnonzero(row))] = j
        colors = {**GMWM_COLORS, **ANATOMY_COLORS}
        gyri = [n for n in out_names if n not in ("gray_matter", "other_gray_matter", "white_matter")]
        _draw_channels(ax, proj, xs, zs, list(out_names), colors, label_names=gyri)
        if name == "mtg_gm":
            ax.contour(xs, zs, (img >= 0).astype(float), [0.5], colors="#52514e", linewidths=0.5)
        ax.set_title(f"{name}: {len(out_names)} channel{'s' if len(out_names) > 1 else ''}", fontsize=9)
        ax.set_xlabel("MNI x (mm)", fontsize=8)
        ax.legend([Patch(fc=colors[n], ec="#52514e", lw=0.4) for n in out_names],
                  [n.replace("_", " ") for n in out_names], loc="lower left", fontsize=6, frameon=True)
    axes[0].set_ylabel("MNI z (mm)", fontsize=8)
    fig.suptitle(f"Fixed projections of the anatomical channels, coronal y = {reference_y:g} mm "
                 "(gmwm = the original gray/white atlas features)", fontsize=10)
    fig.savefig(fig_dir / "feature_projections.png", dpi=150)
    plt.close(fig)
    print(json.dumps({"passed": record["passed"], "volume_checks": volume,
                      "figures": [str(fig_dir / "anatomical_channels.png"), str(fig_dir / "feature_projections.png")]},
                     indent=2))


# --------------------------------------------------------------------------------------
# Stage: evaluate
# --------------------------------------------------------------------------------------

def run_evaluate(args, config, job, scan, out_dir: Path) -> None:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import nibabel as nib
    from scipy import ndimage as ndi

    from preprocess.section_alignment import reslice_labels

    fit_dir = Path(args.fit_dir)
    export = json.loads((out_dir / str(scan["export"].get("record_subdir", "")) / f"export_{args.plane}.json").read_text())
    plane = export["plane"]
    origin, u, v = (np.asarray(plane[k]) for k in ("origin_mm", "u_axis", "v_axis"))
    atlas = atlas_setup(config, scan)
    regions = list(scan["fine_regions"]) + list(FINE_ORDER_TAIL)
    with np.load(fit_dir / "qc_points_pulled_back.npz") as archive:
        pulled = archive["X_plane"][:, :2].astype(np.float64)
        depth_um = archive["depth"].astype(np.float64)
    with np.load(export["paths"]["qc_points_npz"]) as archive:
        rigid = archive["X"][:, :2].astype(np.float64)
    names = regions + list(LANDING_CLASSES)
    bins = [(0, 1000), (1000, 2000), (2000, 3000), (3000, 6000)]

    def by_depth(points):
        index = classify_points(atlas, origin + points[:, :1] * u + points[:, 1:2] * v, regions)
        out = {"all": dict(zip(names, (np.bincount(index, minlength=len(names)) / len(index)).tolist()))}
        for low, high in bins:
            sel = (depth_um >= low) & (depth_um < high)
            if sel.any():
                out[f"{low}-{high}um"] = dict(zip(names, (np.bincount(index[sel], minlength=len(names)) / sel.sum()).tolist()))
        return out

    displacement = np.linalg.norm(pulled - rigid, axis=1)
    evaluation = {
        "fit_dir": str(fit_dir), "plane_id": plane["plane_id"],
        "ribbon_landing_rigid": by_depth(rigid), "ribbon_landing_after_xiv": by_depth(pulled),
        "ribbon_displacement_by_xiv_mm": dict(zip(["p50", "p90", "max"], np.percentile(displacement, [50, 90, 100]).tolist())),
        "note": "the ribbon is the NeuN HALO cortex, never seen by any fit; atlas MTG is a population-template "
                "label, so landing fractions test consistency, not ground truth",
    }
    for name in ("plausibility.json", "scores.json", "COMPLETED.json"):
        if (fit_dir / name).exists():
            evaluation[name.replace(".json", "")] = json.loads((fit_dir / name).read_text())
    (fit_dir / "anatomical_evaluation.json").write_text(json.dumps(evaluation, indent=2) + "\n", encoding="utf-8")

    # ---- atlas-correspondence figure: template + labels on the plane, QNP on top -------
    half, step = float(scan["half_width_mm"]), 0.25
    grid, axis = reslice_labels(atlas["labels"], atlas["affine"], origin, u, v, half, step)
    template = nib.load(str(resolve_path(config, scan["template_nifti"])))
    aa, bb = np.meshgrid(axis, axis, indexing="xy")
    world = origin + aa[..., None] * u + bb[..., None] * v
    ijk = (world.reshape(-1, 3) - template.affine[:3, 3]) @ np.linalg.inv(template.affine[:3, :3]).T
    t1 = ndi.map_coordinates(np.asanyarray(template.dataobj).astype(np.float32), ijk.T, order=1).reshape(aa.shape)
    fig, axes = plt.subplots(1, 2, figsize=(15, 7.2), constrained_layout=True)
    colors = ["#eb6834", "#2a78d6", "#1baf7a", "#eda100", "#c3c2b7", "#1a1a19"]
    for ax, points, title in ((axes[0], rigid, "rigid scan placement"), (axes[1], pulled, "after xIV (pulled back)")):
        ax.imshow(t1, extent=[axis[0], axis[-1], axis[0], axis[-1]], origin="lower", cmap="gray")
        for color, name in zip(colors, regions):
            ax.contour(axis, axis, atlas["fine"][name][np.clip(grid, 0, len(atlas["fine"][name]) - 1)].astype(float),
                       [0.5], colors=[color], linewidths=0.9)
        shown = ax.scatter(points[::5, 0], points[::5, 1], c=depth_um[::5] / 1000.0, s=0.6, cmap="viridis",
                           vmin=0, vmax=3.5, linewidths=0)
        ax.set_title(f"{title}: NeuN HALO ribbon (colour = depth from pia, mm)", fontsize=10)
        ax.set_xlabel("plane u (mm)"); ax.set_ylabel("plane v (mm)"); ax.set_aspect("equal")
    fig.colorbar(shown, ax=axes, shrink=0.6, label="depth from pia (mm, QNP)")
    handles = [plt.Line2D([], [], color=c) for c in colors]
    fig.legend(handles, regions, loc="lower center", ncol=len(regions), frameon=False, fontsize=9)
    fig.suptitle(f"AHRAv2 plane {plane['plane_id']} (MNI ICBM 2009b T1, label outlines) with the QNP section", fontsize=11)
    fig.savefig(fit_dir / "atlas_correspondence.png", dpi=130)
    plt.close(fig)
    print(json.dumps({k: evaluation[k] for k in ("ribbon_displacement_by_xiv_mm",)}, indent=2))
    print("rigid:", json.dumps({k: round(v, 3) for k, v in evaluation["ribbon_landing_rigid"]["all"].items()}))
    print("xIV:  ", json.dumps({k: round(v, 3) for k, v in evaluation["ribbon_landing_after_xiv"]["all"].items()}))


def run_graph(config, job, scan, out_dir: Path) -> None:
    """Edges of the Allen <-> QNP transformation graph, with their uncertainty."""

    within = json.loads((resolve_path(config, job["alignment"]["output_dir"]) / "transforms.json").read_text())
    summary = json.loads((out_dir / "summary.json").read_text()) if (out_dir / "summary.json").exists() else {}
    nodes = {"mni_icbm2009b_symmetric": "AHRAv2 / MNI ICBM 2009b symmetric, mm",
             "qnp_local_mm": within["local_frame"]}
    edges = []
    for stain, edge in within["edges"].items():
        node = f"qnp_slide_mm:{edge['slide']}"
        nodes[node] = "slide mm of one QNP slide (x right, y down)"
        reliable = edge["structural"] or "halo_ribbon_dice_vs_reference" in edge["independent_checks"]
        edges.append({"from": node, "to": "qnp_local_mm", "type": "2-D rigid (+ reflection), scale 1",
                      "matrix_3x3": edge["slide_mm_to_local_mm"], "score": edge["score_fine"],
                      "checks": edge["independent_checks"],
                      "status": "accepted" if reliable and edge["score_fine"] < 0.25 else "unreliable (not used)"})
    hypotheses = []
    for export_file in sorted(out_dir.glob("export_*.json")):
        export = json.loads(export_file.read_text())
        plane = export["plane"]
        node = f"atlas_plane:{plane['plane_id']}"
        nodes[node] = "in-plane mm of a resliced AHRAv2 plane; world = origin + a u + b v"
        sim = export["similarity_qnp_local_to_plane"]
        fit = None
        for name, record in config.get("registrations", {}).items():
            if plane["plane_id"] in str(record.get("source_particles", "")):
                done = resolve_path(config, record["output_dir"]) / f"init_{record['reference_initialization']}"
                if (done / "COMPLETED.json").exists():
                    fit = {"registration": name, "directory": str(done),
                           "variables": str(done / "optimized_variables.pt"),
                           "transform_chain": str(done / "transform_chain.json"),
                           "evaluation": str(done / "anatomical_evaluation.json")}
        edges.append({"from": "qnp_local_mm", "to": node, "type": "2-D similarity from the plane scan, then "
                      "(optionally) xIV LDDMM on the plane", "similarity": sim, "xiv_fit": fit,
                      "status": "competing hypothesis"})
        edges.append({"from": node, "to": "mni_icbm2009b_symmetric", "type": "plane embedding (exact by definition)",
                      "origin_mm": plane["origin_mm"], "u_axis": plane["u_axis"], "v_axis": plane["v_axis"],
                      "status": "exact given the hypothesis"})
        hypotheses.append({"plane_id": plane["plane_id"], "rigid_ribbon_landing": export["rigid_ribbon_landing"]})
    graph = {
        "nodes": nodes, "edges": edges, "hypotheses": hypotheses,
        "placement_uncertainty": {
            "stain_replicate_noise_delta": summary.get("stain_replicate_noise_delta"),
            "dense_basins": summary.get("dense_basins"),
            "interpretation": "competing planes are alternative constraints, not a posterior; no hypothesis is "
                              "certified by the image data alone",
        },
        "attachable_later": {"merfish": "SEA-AD MERFISH sections of the same donor/region -> qnp_local_mm "
                                        "(no shared physical section; would be another uncertain edge)",
                             "donor_mri": "donor MRI -> mni_icbm2009b_symmetric or directly -> atlas planes"},
    }
    (out_dir / "transform_graph.json").write_text(json.dumps(graph, indent=2) + "\n", encoding="utf-8")
    print(f"{len(nodes)} nodes, {len(edges)} edges -> {out_dir / 'transform_graph.json'}")


# --------------------------------------------------------------------------------------
# Stacking coordinate (skill section-to-template-mapping, steps 1-7; GPU)
# --------------------------------------------------------------------------------------
# Stages, all configured by atlas_scan.stacking of the resolved job:
#   roles         feature QC of each section's gray/white map -> anchor or passenger
#   compress      joint (XY + mass) compression of every section, once per level
#   slabs         coarse pass: coronal slabs over the target region's y-extent, per anchor
#   profile       depth profile per anchor (fresh global 2-D search at every depth), delta,
#                 within-delta windows; --level picks the level, each conditioned on the
#                 previous one (its windows and best poses as extra starts)
#   passengers    passengers inherit an anchor's pose through a QNP<->QNP outline fit
#   stack-report  figures and the per-section report

STACK_STAGES = ("roles", "compress", "slabs", "profile", "passengers", "stack-report", "landmark", "candidates")
REGION_COLORS = {"MTG": "#2a78d6", "STG": "#eb6834", "ITG": "#1baf7a", "FuG": "#eda100",
                 "white_matter": "#c4c2b9", "other_gray_matter": "#e6e4dc"}
REGION_COLORS.update(insula="#b59a1a", hippocampus="#8b8a85", LGN="#d6246e", MGN="#8a5cc2", temporal_plane="#c98bb9")
PIA_COLOR = "#e34948"
INK = "#1a1a19"
ATLAS_LINE = "#6b6a66"
SUPPORT_COLOR = "#1baf7a"


def _pose_legend_handles(regions, support: bool = False):
    from matplotlib.lines import Line2D
    from matplotlib.patches import Patch

    handles = [Patch(fc=REGION_COLORS[n], alpha=0.55, ec="none", label=f"atlas {n.replace('_', ' ')}")
               for n in regions if n in REGION_COLORS]
    handles += [Line2D([], [], color=ATLAS_LINE, lw=0.7, label="atlas outer surface (and ventricle walls)"),
                Line2D([], [], color=ATLAS_LINE, lw=0.6, ls=":", label="atlas gray/white boundary"),
                Line2D([], [], color=INK, lw=1.6, label="QNP tissue outline (transformed)"),
                Line2D([], [], color=INK, lw=1.1, ls="--", label="QNP gray/white boundary (transformed)"),
                Line2D([], [], color=PIA_COLOR, lw=2.5, label="QNP pia, ribbon depth ≤ 100 µm (transformed)")]
    if support:
        handles.append(Line2D([], [], color=SUPPORT_COLOR, lw=0.9, ls="-.", label="admissible atlas support (region prior)"))
    return handles


class StackContext:
    """Paths, sections and settings of one job's stacking run (no donor-specific values)."""

    def __init__(self, config: dict, job: dict, region_prior: bool = False, landmark_slab: bool = False):
        self.config, self.job = config, job
        self.scan = job["atlas_scan"]
        self.cfg = self.scan["stacking"]
        # Dissection-region prior (explicit, off by default): the atlas plane is restricted to
        # the cells near these regions; results go to their own folder, beside the unconstrained run.
        self.prior = dict(self.cfg["region_prior"]) if region_prior else None
        # Anatomical slab prior (explicit, off by default): the AP search is restricted to the
        # candidate tissue slabs around a landmark (preprocess/anatomical_slab.py).
        self.slab_cfg = None
        if landmark_slab:
            cfg = self.cfg.get("landmark_slab")
            if not cfg:
                raise SystemExit("--landmark-slab: no atlas_scan.stacking.landmark_slab block for this job")
            regions = cfg.get("applies_to_regions")
            if regions and job.get("region") not in regions:
                raise SystemExit(f"--landmark-slab: the configured rule applies to {regions}, not to region "
                                 f"{job.get('region')!r}; give this job its own landmark_slab block")
            self.slab_cfg = dict(cfg)
        self.base_out = resolve_path(config, self.cfg["output_dir"])
        tags = [t for t, on in (("region_prior", self.prior), ("landmark_slab", self.slab_cfg)) if on]
        self.out = self.base_out / "__".join(tags) if tags else self.base_out
        self.out.mkdir(parents=True, exist_ok=True)
        self._slab_prior = None
        self.aligned = resolve_path(config, job["alignment"]["output_dir"])
        self.compressed = resolve_path(config, self.cfg["compressed_dir"])
        self.particle_dir = resolve_path(config, job["particle_dir"])
        self.qc_dir = resolve_path(config, job["qc_dir"])
        self.record = json.loads((self.aligned / "transforms.json").read_text())
        self.reference = job["reference_stain"]
        self.stems = {self.reference: self.record["reference_slide"],
                      **{s: e["slide"] for s, e in self.record["edges"].items()}}
        self.stains = [s for s in job["stains"] if s in self.stems]
        self.sigmas = [float(s) for s in self.scan.get("score_sigmas_mm", [2.0, 1.0, 0.5])]
        self.levels = list(self.cfg["levels"])
        self.compression_levels = dict(self.cfg["compression"]["levels"])
        self._atlas = None

    @property
    def atlas(self) -> dict:
        if self._atlas is None:
            self._atlas = atlas_setup(self.config, self.scan)
        return self._atlas

    @property
    def slab_prior(self) -> dict | None:
        """Landmark + candidate slabs + search interval (``landmark_slab.json``), or None."""

        if self.slab_cfg is None:
            return None
        if self._slab_prior is None:
            from preprocess.anatomical_slab import build_slab_prior, locate_landmark

            spec = self.slab_cfg["landmark"]
            if spec.get("codes") and spec.get("expected_name"):
                decoded = {int(c): self.atlas["names"].get(int(c)) for c in spec["codes"]}
                if decoded[int(spec["codes"][0])] != spec["expected_name"]:
                    raise SystemExit(f"landmark {spec.get('name')}: code {spec['codes'][0]} decodes to "
                                     f"{decoded[int(spec['codes'][0])]!r}, expected {spec['expected_name']!r}")
            landmark = locate_landmark(self.atlas["labels"], self.atlas["affine"], spec,
                                       self.scan.get("hemisphere", "left"))
            record = build_slab_prior(landmark, self.slab_cfg)
            record.update(atlas={"annotation_nifti": self.scan["annotation_nifti"],
                                 "space": "AHRAv2 on MNI ICBM 2009b symmetric, world mm"},
                          sampling_regions=list(self.slab_cfg.get("sampling_regions", [])),
                          concepts={"slab": "nominal tissue slab S_j(delta) of the dissection protocol",
                                    "sampling_region": "atlas sampling_regions inside the slab (display/QC only)",
                                    "qnp_block": "not constructed: its position is the registration estimate"})
            self._slab_prior = record
            path = self.out / "landmark_slab.json"
            path.write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
        return self._slab_prior

    def search_y_range(self) -> tuple[float, float, str]:
        """(posterior y, anterior y, description) of the AP range the stacking search covers."""

        if self.slab_prior is not None:
            hi, lo = self.slab_prior["search_interval"]["y_mm"]
            lm = self.slab_prior["landmark"]
            return lo, hi, (f"landmark slab prior: {lm['name']} at y {lm['y_mm']:+.1f} mm ({lm['method'].split(':')[0]}), "
                            f"{self.slab_prior['slab_thickness_mm']:g} mm slabs j in {self.slab_prior['slab_offsets']} "
                            f"over every cutting phase, +- {self.slab_prior['extension_mm']:g} mm: y {hi:+.1f} ... {lo:+.1f}")
        lo, hi = self.atlas["region_extent_y"]
        pad = float(self.cfg["slabs"].get("y_pad_mm", 5.0))
        return lo - pad, hi + pad, (f"slab range: atlas {next(iter(self.scan['fine_regions']))} y-extent +- "
                                    f"{pad} mm (dissection region)")

    def h_mm(self, level: str) -> float | None:
        return float(self.compression_levels[level]) if level in self.compression_levels else None

    def particle_path(self, stain: str, level: str, frame: str = "local") -> Path:
        stem = self.stems[stain]
        suffix = "_local" if frame == "local" else ""
        if level in self.compression_levels:
            return self.compressed / f"{stem}_tissue_classes_{level}{suffix}.npz"
        return (self.aligned / f"{stem}_tissue_classes_{level}_local.npz" if frame == "local"
                else self.particle_dir / f"{stem}_tissue_classes_{level}.npz")

    def particles(self, stain: str, level: str, frame: str = "local"):
        from preprocess.particle_utils import load_particle_archive

        X, nu, meta = load_particle_archive(self.particle_path(stain, level, frame), "nu_Sub")
        return X[:, :2].astype(np.float64), nu.astype(np.float64), meta

    def slide_to_local(self, stain: str) -> np.ndarray:
        if stain == self.reference:
            return np.eye(3)
        return np.asarray(self.record["edges"][stain]["slide_mm_to_local_mm"], float)

    def roles(self) -> dict:
        path = self.base_out / "roles.json"
        if not path.exists():
            raise SystemExit("Run --stage roles first.")
        return json.loads(path.read_text())

    def anchors(self) -> list[str]:
        return [s for s, r in self.roles()["sections"].items() if r["role"] == "anchor"]

    def ribbon_local(self):
        with np.load(resolve_path(self.config, self.scan["ribbon_points"])) as archive:
            return archive["X"][:, :2].astype(np.float64), archive["depth_from_pia_um"].astype(np.float64)


def _transform_from_row(row: dict):
    from preprocess.section_alignment import Similarity2D

    return Similarity2D(float(row["theta_deg"]), float(row["scale"]), str(row["flip"]) == "True",
                        (float(row["tau_x"]), float(row["tau_y"])))


def _write_rows(path: Path, rows: list[dict]) -> None:
    with open(path, "w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def _read_rows(path: Path) -> list[dict]:
    with open(path, newline="") as stream:
        rows = list(csv.DictReader(stream))
    for row in rows:
        for key in ("y0_mm", "score", "theta_deg", "scale", "tau_x", "tau_y"):
            if key in row:
                row[key] = float(row[key])
    return rows


# ---- roles ---------------------------------------------------------------------------

def run_roles(ctx: StackContext) -> dict:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from preprocess.qnp_stacking import RoleThresholds, assign_role, stripe_index

    summary = json.loads((ctx.qc_dir / "particles_summary.json").read_text())
    with np.load(ctx.aligned / "multistain_maps_32um_local.npz") as archive:
        ms = {k: archive[k] for k in archive.files}
    ms_stains = [str(s) for s in ms["stains"]]
    pad = int(ctx.job["alignment"].get("grid_pad_px", 60))
    ref_maps = np.load(ctx.particle_dir / f"{ctx.stems[ctx.reference]}_maps_32um.npz")
    layer1 = None
    if "layers" in ref_maps:
        layers = np.pad(ref_maps["layers"], pad)
        if layers.shape != ms["p_wm"].shape[1:]:
            raise RuntimeError(f"reference layer raster {layers.shape} does not match the local grid {ms['p_wm'].shape[1:]}")
        layer1 = layers == 1  # LAYER_ORDER[0] = L1
    roles_cfg = ctx.cfg.get("roles", {})
    thresholds = RoleThresholds.from_config(roles_cfg)
    override = roles_cfg.get("override") or {}
    sections = {}
    for stain in ctx.stains:
        maps = np.load(ctx.particle_dir / f"{ctx.stems[stain]}_maps_32um.npz")
        stripes = stripe_index(maps["p_wm"].astype(float), maps["mask"].astype(bool), float(np.mean(maps["px_mm"])))
        k = ms_stains.index(stain)
        tissue, p = ms["tissue"][k].astype(bool), ms["p_wm"][k].astype(float)
        l1 = None
        if layer1 is not None and (layer1 & tissue).sum() > 50:
            l1 = float(p[layer1 & tissue].mean())
        metrics = {"otsu_separability": float(summary[stain]["membership"]["otsu_separability"]),
                   "stripe_index": stripes["max"], "stripes": stripes, "layer1_mean_p_wm": l1,
                   "layer1_source": f"{ctx.reference} HALO layer 1 carried into the local frame" if l1 is not None else None}
        role, reasons = assign_role(stain, metrics, thresholds)
        entry = {"role_from_qc": role, "failed_checks": reasons, "metrics": metrics, "role": role,
                 "role_source": "feature QC"}
        if stain in override:
            entry.update(role=str(override[stain]), role_source="user override (stacking.roles.override)")
        sections[stain] = entry
        print(f"{stain}: {entry['role']} ({entry['role_source']}) sep {metrics['otsu_separability']:.3f} "
              f"stripes {metrics['stripe_index']:.3f} L1 {l1 if l1 is None else round(l1, 2)} {reasons}", flush=True)
    record = {"job": ctx.job["_name"], "thresholds": thresholds.__dict__, "sections": sections,
              "note": "flat depth profiles demote an anchor at --stage profile (reported there)"}
    (ctx.base_out / "roles.json").write_text(json.dumps(record, indent=2, default=list) + "\n", encoding="utf-8")

    # Gray/white map per section in the local frame, titled by its role.
    origin, px = ms["origin_mm"], ms["px_mm"]
    rows_, cols_ = ms["p_wm"].shape[1:]
    extent = [origin[0], origin[0] + cols_ * px[1], origin[1] + rows_ * px[0], origin[1]]
    ncol = 3
    nrow = int(np.ceil(len(ctx.stains) / ncol))
    fig, axes = plt.subplots(nrow, ncol, figsize=(5.2 * ncol, 4.6 * nrow), constrained_layout=True, squeeze=False)
    for ax, stain in zip(axes.flat, ctx.stains):
        k = ms_stains.index(stain)
        shown = ax.imshow(np.where(ms["tissue"][k], ms["p_wm"][k].astype(float), np.nan), extent=extent,
                          cmap="Blues", vmin=0, vmax=1, interpolation="nearest")
        if layer1 is not None:
            ax.contour(origin[0] + np.arange(cols_) * px[1], origin[1] + np.arange(rows_) * px[0],
                       layer1.astype(float), [0.5], colors=[PIA_COLOR], linewidths=0.5)
        m = sections[stain]["metrics"]
        ax.set_title(f"{stain}: {sections[stain]['role']}\nseparability {m['otsu_separability']:.2f}, "
                     f"stripes {m['stripe_index']:.2f}"
                     + (f", layer 1 p(WM) {m['layer1_mean_p_wm']:.2f}" if m["layer1_mean_p_wm"] is not None else ""),
                     fontsize=10)
        ax.set_xlabel("local x (mm)")
        ax.set_ylabel("local y (mm, down)")
        ax.set_aspect("equal")
    for ax in list(axes.flat)[len(ctx.stains):]:
        ax.axis("off")
    fig.colorbar(shown, ax=axes, shrink=0.5, label="p(white matter)")
    fig.savefig(ctx.base_out / "roles_gray_white_maps.png", dpi=110)
    plt.close(fig)
    return record


# ---- compress ------------------------------------------------------------------------

def _save_compressed(path: Path, X2: np.ndarray, nu: np.ndarray, meta: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(path, X=np.column_stack([X2, np.zeros(len(X2))]).astype(np.float64), nu_Sub=nu,
                        metadata_json=json.dumps(meta))


def run_compress(ctx: StackContext, overwrite: bool = False) -> dict:
    """Compress each section's native 500 um particles once per level; also write the local copy.

    The compression objective is invariant under rigid motions, so compressing in the slide
    frame and then applying the slide -> local rigid transform equals compressing in the local
    frame (up to roundoff); the native archive is what the figures draw.
    """

    from preprocess.qnp_stacking import compress

    comp = ctx.cfg["compression"]
    reference_tag = ctx.cfg.get("reference_bin_tag", "500um")
    path_json = ctx.base_out / "compression.json"
    record = json.loads(path_json.read_text()) if path_json.exists() else {}
    for stain in ctx.stains:
        X, nu, meta = ctx.particles(stain, reference_tag, frame="native")
        M = ctx.slide_to_local(stain)
        for level, h in ctx.compression_levels.items():
            native, local = ctx.particle_path(stain, level, "native"), ctx.particle_path(stain, level, "local")
            if native.exists() and local.exists() and not overwrite and f"{stain}:{level}" in record:
                print(f"exists, skipped: {stain} {level}")
                continue
            Z, nuZ, info = compress(X, nu, float(h), outer_steps=int(comp.get("outer_steps", 30)),
                                    max_pairs=int(comp.get("max_pairs", 16_000_000)))
            base = {k: meta[k] for k in ("slide", "structural_feature") if k in meta}
            common = {**base, **info, "level": level, "features": ["gray_matter", "white_matter"],
                      "source_archive": str(ctx.particle_path(stain, reference_tag, "native")), "mass_units": "mm^2"}
            _save_compressed(native, Z, nuZ, {**common, "coordinate_space": "qnp_slide_mm"})
            Zl = Z @ M[:2, :2].T + M[:2, 2]
            _save_compressed(local, Zl, nuZ, {**common, "coordinate_space": "qnp_local_mm",
                                              "slide_to_local": M.tolist(),
                                              "alignment_transforms": str(ctx.aligned / "transforms.json")})
            record[f"{stain}:{level}"] = {k: info[k] for k in ("count", "reference_count", "h_mm", "sigma_mm", "seconds",
                                                               "relative_error_final", "total_mass_deviation_percent")}
            print(f"{stain} {level}: {info['reference_count']} -> {info['count']} particles in {info['seconds']:.1f} s, "
                  f"relative error {info['relative_error_final']:.4f}, mass {info['total_mass_deviation_percent']:+.3f}%",
                  flush=True)
            path_json.write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
    return record


# ---- slabs ---------------------------------------------------------------------------

def run_slabs(ctx: StackContext) -> dict:
    from preprocess.qnp_stacking import distinct_minima, level_sigmas, make_scorer, region_y_extent, search_depths, slab_measure

    slabs = ctx.cfg["slabs"]
    level = ctx.levels[0]
    lo, hi = region_y_extent(ctx.atlas)
    search_lo, search_hi, search_note = ctx.search_y_range()
    stride, half = float(slabs.get("stride_mm", 3.0)), float(slabs.get("half_thickness_mm", 3.0))
    # Search slabs (blurred atlas for the fast pass), not tissue slabs: centres span the search range.
    centres = np.round(np.arange(search_hi, search_lo - 1e-9, -stride), 3)
    measures = [slab_measure(ctx.atlas, ctx.scan, y, half, float(slabs.get("plane_step_mm", 0.5)), ctx.prior)
                for y in centres]
    rows, kept = [], {}
    for anchor in ctx.anchors():
        X, nu, _ = ctx.particles(anchor, level)
        scorer = make_scorer(X, nu, level_sigmas(ctx.sigmas, ctx.h_mm(level)))
        t0 = time.time()
        results = search_depths(scorer, measures, ctx.cfg["search"])
        scores = []
        for y, ranked in zip(centres, results):
            score, t = ranked[0]
            scores.append(score)
            rows.append({"level": level, "representation": anchor, "y0_mm": float(y), "score": score,
                         "theta_deg": t.theta_deg % 360, "scale": t.scale, "flip": t.flip, "tau_x": t.tau[0], "tau_y": t.tau[1],
                         "particles": len(X)})
        top = distinct_minima(list(centres), scores, int(slabs.get("keep", 3)), 2 * stride)
        inside = [(s, y) for y, s in zip(centres, scores) if lo <= y <= hi]
        prior = float(min(inside)[1]) if inside else None
        kept[anchor] = {"top_distinct": top, "best_prior_consistent": prior}
        print(f"slabs {anchor}: {len(centres)} slabs in {time.time() - t0:.1f} s; top {top}, prior-consistent {prior}", flush=True)
    _write_rows(ctx.out / f"slabs_{level}.csv", rows)
    union = sorted({y for k in kept.values() for y in k["top_distinct"] + ([k["best_prior_consistent"]] if k["best_prior_consistent"] is not None else [])},
                   reverse=True)
    record = {"level": level, "slab_half_thickness_mm": half, "stride_mm": stride, "centres_mm": centres.tolist(),
              "target_region_y_extent_mm": [lo, hi], "per_anchor": kept, "kept_centres_mm": union,
              "prior": f"dissection region: slabs whose centre lies in the atlas {next(iter(ctx.scan['fine_regions']))} y-extent",
              "region_prior": ctx.prior, "search_y_range_mm": [search_hi, search_lo], "search_range": search_note}
    if ctx.slab_prior is not None:
        # The slab interval is already narrow: profile level 1 scans every plane in it (no shortlist).
        record["landmark_slab"] = "landmark_slab.json"
        record["profile_first_level"] = "every plane of search_y_range_mm (kept_centres_mm not used)"
    (ctx.out / "slabs.json").write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
    return record


# ---- profile -------------------------------------------------------------------------

def _level_summary(ctx: StackContext, level: str, rows: list[dict], previous: dict | None) -> dict:
    from preprocess.qnp_stacking import noise_delta, window

    step = float(ctx.cfg["profile"].get("step_mm", 0.5))
    families = sorted({r["family"] for r in rows})
    anchors = list(dict.fromkeys(r["representation"] for r in rows))

    def profile(anchor, family=None):
        best: dict[float, float] = {}
        for r in rows:
            if r["representation"] == anchor and (family is None or r["family"] == family):
                best[r["y0_mm"]] = min(best.get(r["y0_mm"], np.inf), r["score"])
        return best

    pooled = {a: profile(a) for a in anchors}
    noise = noise_delta(pooled, int(ctx.cfg.get("delta_top_planes", 20)))
    delta = noise["delta"]
    out = {"level": level, "families": families, "delta": noise, "anchors": {}}
    if delta is None:
        out["warning"] = noise["reason"]
        return out
    first_level = previous is None
    inherited_flat = set(previous.get("flat_anchors", [])) if previous else set()
    flat_rule = "median - best <= 2 delta on the first level" if first_level else "inherited from the first level"
    if first_level and ctx.slab_prior is not None:
        # A slab-limited range cannot show that a profile is flat (and its top-plane delta is
        # inflated): inherit flatness from the unconstrained first level, else do not judge it.
        wide = ctx.base_out / f"profile_{level}.json"
        first_level = False
        if wide.exists():
            inherited_flat = set(json.loads(wide.read_text()).get("flat_anchors", []))
            flat_rule = f"inherited from the unconstrained first level ({wide.name})"
        else:
            flat_rule = "not judged: the landmark-slab range is too narrow (run the unconstrained profile to judge it)"
    flat = []
    for a in anchors:
        w = window(pooled[a], delta, step)
        # Flatness is judged once, on the wide first-level profile; an escalation level spans
        # only the previous windows, where median - best is small by construction.
        w["flat"] = bool(w["flat"]) if first_level else a in inherited_flat
        w["flat_rule"] = flat_rule
        best_row = min((r for r in rows if r["representation"] == a), key=lambda r: r["score"])
        w["best_transform"] = {k: best_row[k] for k in ("theta_deg", "scale", "flip", "tau_x", "tau_y")}
        if len(families) > 1:
            w["families"] = {f: window(profile(a, f), delta, step) for f in families}
            fb = {f: w["families"][f]["best_score"] for f in families}
            w["family_gap_in_delta"] = (max(fb.values()) - min(fb.values())) / delta
        if w["flat"]:
            flat.append(a)
        out["anchors"][a] = w
    out["flat_anchors"] = flat
    if flat and len(anchors) - len(flat) >= 2:
        kept = {a: pooled[a] for a in anchors if a not in flat}
        out["delta_without_flat"] = noise_delta(kept, int(ctx.cfg.get("delta_top_planes", 20)))
    widths = [w["width_mm"] for w in out["anchors"].values() if not w["flat"]]
    out["union_window_y"] = [max(w["window_y"][0] for w in out["anchors"].values() if not w["flat"]),
                             min(w["window_y"][1] for w in out["anchors"].values() if not w["flat"])] if widths else None
    if previous is not None and previous.get("anchors"):
        shrink = {a: previous["anchors"][a]["width_mm"] - out["anchors"][a]["width_mm"]
                  for a in out["anchors"] if a in previous["anchors"]}
        out["window_shrink_vs_previous_mm"] = shrink
        out["stop_escalating"] = bool(all(v <= 1e-6 for v in shrink.values()))
    return out


def run_profile(ctx: StackContext, level: str, families: bool) -> dict:
    from preprocess.qnp_stacking import escalation_ys, level_sigmas, make_scorer, plane_measure, search_depths

    prof = ctx.cfg["profile"]
    step = float(prof.get("step_mm", 0.5))
    index = ctx.levels.index(level)
    previous = None
    extra: dict[str, list] = {}
    bound = None
    if ctx.slab_prior is not None:
        from preprocess.anatomical_slab import clamp_ys

        bound = ctx.slab_prior["search_interval"]["y_mm"]  # [anterior, posterior]
    if index == 0 and bound is not None:
        # Every plane of the slab interval, on the step lattice (no slab shortlist needed).
        ys = sorted({round(float(y), 3) for y in np.arange(np.ceil(bound[1] / step) * step, bound[0] + 1e-9, step)},
                    reverse=True)
    elif index == 0:
        slabs = json.loads((ctx.out / "slabs.json").read_text())
        pad = float(prof.get("pad_mm", 3.0))
        ys = sorted({round(float(y), 3) for c in slabs["kept_centres_mm"]
                     for y in np.arange(c - pad, c + pad + 1e-9, step)}, reverse=True)
    else:
        prev_level = ctx.levels[index - 1]
        prev_file = ctx.out / f"profile_{prev_level}.json"
        if not prev_file.exists():
            raise SystemExit(f"Run --stage profile --level {prev_level} first (escalation is conditioned on it).")
        previous = json.loads(prev_file.read_text())
        ys = escalation_ys([w for w in previous["anchors"].values() if not w["flat"]], step)
        for a, w in previous["anchors"].items():
            extra[a] = [_transform_from_row({**w["best_transform"]})]
    if bound is not None:
        ys = clamp_ys(ys, bound)
    family_flips = {"current": [True], "flipped": [False]} if families else {"both": None}
    anchors = ctx.anchors() if previous is None else list(previous["anchors"])
    scorers = {}
    for anchor in anchors:
        X, nu, _ = ctx.particles(anchor, level)
        scorers[anchor] = (make_scorer(X, nu, level_sigmas(ctx.sigmas, ctx.h_mm(level))), len(X))
    rows: list[dict] = []

    def profile_planes(planes):
        measures = [plane_measure(ctx.atlas, ctx.scan, y, ctx.prior) for y in planes]
        for anchor, (scorer, count) in scorers.items():
            for family, flips in family_flips.items():
                t0 = time.time()
                results = search_depths(scorer, measures, ctx.cfg["search"], flips=flips,
                                        extra_starts=extra.get(anchor, ()))
                for y, ranked in zip(planes, results):
                    score, t = ranked[0]
                    rows.append({"level": level, "representation": anchor, "family": family, "y0_mm": float(y),
                                 "score": score, "theta_deg": t.theta_deg % 360, "scale": t.scale, "flip": t.flip,
                                 "tau_x": t.tau[0], "tau_y": t.tau[1], "particles": count})
                best = min(r["score"] for r in rows if r["representation"] == anchor and r["family"] == family)
                print(f"{level} {anchor} {family}: {len(planes)} planes in {time.time() - t0:.1f} s; best so far {best:.4f}",
                      flush=True)

    profile_planes(ys)
    extensions = []
    for _ in range(int(prof.get("max_extensions", 8))):
        summary = _level_summary(ctx, level, rows, previous)
        if summary["delta"]["delta"] is None:
            break
        top, bottom = max(ys), min(ys)
        live = [w for w in summary["anchors"].values() if not w["flat"]]
        grow = ([round(top + k * step, 3) for k in (1, 2)] if any(w["window_y"][0] >= top - 1e-6 for w in live) else []) + \
               ([round(bottom - k * step, 3) for k in (1, 2)] if any(w["window_y"][1] <= bottom + 1e-6 for w in live) else [])
        if bound is not None:
            grow = clamp_ys(grow, bound)  # the slab prior is a hard AP bound; touching it is reported
        if not grow:
            break
        extensions += grow
        ys = sorted(set(ys) | set(grow), reverse=True)
        print(f"a window touches the scanned range; extending by {grow}", flush=True)
        profile_planes(grow)
    _write_rows(ctx.out / f"profile_{level}.csv", rows)
    summary = _level_summary(ctx, level, rows, previous)
    summary["range_extensions_mm"] = extensions
    if bound is not None and summary.get("anchors"):
        summary["landmark_slab_bound_y_mm"] = bound
        summary["windows_at_prior_bound"] = [
            a for a, w in summary["anchors"].items()
            if not w["flat"] and (w["window_y"][0] >= bound[0] - step + 1e-6 or w["window_y"][1] <= bound[1] + step - 1e-6)]
    summary.update(ys_mm=ys, particles={a: int(next(r["particles"] for r in rows if r["representation"] == a))
                                        for a in anchors},
                   conditioned_on=None if previous is None else previous["level"],
                   note=("the global search includes both reflections unless --families" if not families else
                         "per-reflection-family profiles: flip fixed per family"))
    (ctx.out / f"profile_{level}.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"delta": summary["delta"]["delta"], "windows": {a: (w["best_y"], w["window_y"], w["flat"])
                                                                     for a, w in summary["anchors"].items()},
                      "stop_escalating": summary.get("stop_escalating")}, indent=1))
    return summary


def latest_level(ctx: StackContext) -> str:
    done = [lv for lv in ctx.levels if (ctx.out / f"profile_{lv}.json").exists()]
    if not done:
        raise SystemExit("Run --stage profile first.")
    return done[-1]


# ---- passengers ----------------------------------------------------------------------

def run_passengers(ctx: StackContext) -> dict:
    """Each passenger is placed through its QNP<->QNP tissue-outline fit to an anchor.

    The alignment stage already fitted every slide to the reference frame (tissue outline for
    non-structural stains, both reflections, checked by HALO ribbon / white-matter Dice), so a
    passenger inherits the chosen anchor's atlas pose and depth window.  Here the passenger is
    also re-fitted directly to that anchor (global GPU search, all rotations, both flips, coarse
    then full level) as a consistency check of the composed placement.
    """

    from preprocess.qnp_stacking import level_sigmas, make_scorer
    from preprocess.section_alignment_gpu import refine_batch, search_gpu

    level = latest_level(ctx)
    summary = json.loads((ctx.out / f"profile_{level}.json").read_text())
    anchors = [a for a, w in summary["anchors"].items() if not w["flat"]]
    roles = ctx.roles()["sections"]
    passengers = [s for s in ctx.stains if s not in anchors]
    host = ctx.reference if ctx.reference in anchors else anchors[0]
    pcfg = ctx.cfg.get("passengers", {})
    coarse, fine = pcfg.get("coarse_level", ctx.levels[1] if len(ctx.levels) > 1 else ctx.levels[0]), pcfg.get("fine_level", ctx.levels[-1])
    Xa, nua, _ = ctx.particles(host, fine)
    Xc, nuc, _ = ctx.particles(host, coarse)
    sc_fine = make_scorer(Xa, nua.sum(1, keepdims=True), level_sigmas(ctx.sigmas, ctx.h_mm(fine)))
    sc_coarse = make_scorer(Xc, nuc.sum(1, keepdims=True), level_sigmas(ctx.sigmas, ctx.h_mm(coarse)))
    out = {"host_anchor": host, "host_level": level, "host_window_y": summary["anchors"][host]["window_y"],
           "host_best_y": summary["anchors"][host]["best_y"], "passengers": {}}
    for stain in passengers:
        P, mu, _ = ctx.particles(stain, coarse)
        Pf, muf, _ = ctx.particles(stain, fine)
        ranked = search_gpu(sc_coarse, P, mu.sum(1, keepdims=True),
                            thetas=np.arange(0, 360, float(pcfg.get("theta_step_deg", 10))), scales=[1.0],
                            flips=[False, True], scale_bounds=(1.0, 1.0), h=0.5, blur_mm=1.0, refine_top=4)
        score, t = refine_batch(sc_fine, Pf, muf.sum(1, keepdims=True), [ranked[0][1]], (1.0, 1.0), 200)[0]
        # Both are in the local frame, so the composed placement is the identity: report how far
        # the direct fit moves the passenger's particles from it.
        moved = t.moving_to_section(Pf)
        displacement = np.linalg.norm(moved - Pf, axis=1)
        out["passengers"][stain] = {
            "role_reason": roles.get(stain, {}).get("failed_checks") or ["flat depth profile"],
            "placement": f"inherits {host}'s atlas pose via the local-frame alignment edge",
            "inherited_window_y": summary["anchors"][host]["window_y"],
            "direct_outline_fit_to_host": {"score": score, "transform": t.as_dict(),
                                           "displacement_from_composed_mm": dict(zip(
                                               ["p50", "p90", "max"], np.percentile(displacement, [50, 90, 100]).tolist()))},
            "alignment_edge": {k: ctx.record["edges"][stain].get(k) for k in ("align_features", "score_fine", "reflection_check")}
            if stain in ctx.record["edges"] else "reference frame",
        }
        print(f"{stain}: outline fit to {host} score {score:.4f}, flip {t.flip}, moves particles "
              f"p50 {np.percentile(displacement, 50):.2f} mm / p90 {np.percentile(displacement, 90):.2f} mm from the composed placement",
              flush=True)
    (ctx.out / "passengers.json").write_text(json.dumps(out, indent=2) + "\n", encoding="utf-8")
    return out


# ---- report --------------------------------------------------------------------------

def _qc_tables(ctx: StackContext) -> dict[str, np.ndarray]:
    """Extra named QC structures (e.g. insula) from ``landmark_slab.figure_label_codes``."""

    n = int(ctx.atlas["labels"].max()) + 1
    out = {}
    for name, codes in (ctx.cfg.get("landmark_slab", {}).get("figure_label_codes") or {}).items():
        table = np.zeros(n, bool)
        table[[int(c) for c in codes if int(c) < n]] = True
        out[name] = table
    return out


def _class_image(ctx: StackContext, y: float, x_range, z_range, res: float = 0.5):
    from preprocess.section_alignment import plane_basis, reslice_labels

    extra = _qc_tables(ctx)
    regions = list(ctx.scan["fine_regions"])
    names = regions + list(extra) + list(FINE_ORDER_TAIL)
    tables = {**ctx.atlas["fine"], **extra}
    table = np.zeros(int(ctx.atlas["labels"].max()) + 1, np.int16)
    # The catch-all tail first, then named regions over it (QC structures such as the insula
    # are part of other gray matter).
    for name in list(FINE_ORDER_TAIL) + regions + list(extra):
        table[tables[name][:len(table)]] = names.index(name) + 1
    u, v, _ = plane_basis(0.0, 0.0)
    cx, cz = np.mean(x_range), np.mean(z_range)
    half = max(np.ptp(x_range), np.ptp(z_range)) / 2
    grid, axis = reslice_labels(ctx.atlas["labels"], ctx.atlas["affine"], np.array([cx, y, cz]), u, v, half, res)
    img = table[np.clip(grid, 0, len(table) - 1)]
    xs, zs = cx + axis, cz + axis
    ix = (xs >= x_range[0]) & (xs <= x_range[1])
    iz = (zs >= z_range[0]) & (zs <= z_range[1])
    return img[np.ix_(iz, ix)], xs[ix], zs[iz], names


def pose_flags(ctx: StackContext, summary: dict, anchor: str, row: dict, transform=None) -> list[str]:
    """Search-boundary flags of one placement: AP optimum on the searched range's edge, scale at a bound."""

    flags = []
    step = float(ctx.cfg["profile"].get("step_mm", 0.5))
    w = summary.get("anchors", {}).get(anchor)
    ys = summary.get("ys_mm") or []
    if w and ys and (w["window_y"][0] >= max(ys) - 1e-6 or w["window_y"][1] <= min(ys) + 1e-6):
        flags.append("window on the edge of the searched AP range")
    if anchor in (summary.get("windows_at_prior_bound") or []):
        flags.append(f"window within {step:g} mm of the slab-prior AP bound")
    lo, hi = (float(s) for s in ctx.cfg["search"].get("scale_bounds", (0.8, 1.5)))
    scale = (transform.scale if transform is not None else float(row["scale"]))
    if scale <= lo * 1.005 or scale >= hi * 0.995:
        flags.append(f"scale {scale:.3f} at its search bound [{lo:g}, {hi:g}]")
    return flags


def _draw_pose(ax, ctx: StackContext, stain: str, level: str, row: dict, x_range, z_range, transform=None,
               support: bool = False):
    """Atlas plane (muted fills, thin grey boundaries) under the transformed QNP section (heavy black/red).

    ``transform`` overrides the row's pose (e.g. a refined one); ``support`` draws the admissible
    atlas support of the region prior (dash-dot green).
    """

    from matplotlib.colors import ListedColormap
    from preprocess.qnp_stacking import splat

    y = row["y0_mm"]
    img, xs, zs, names = _class_image(ctx, y, x_range, z_range)
    colors = ["#ffffff"] + [REGION_COLORS.get(n, "#bdbbb3") for n in names]
    ax.imshow(img, origin="lower", extent=(xs[0] - 0.25, xs[-1] + 0.25, zs[0] - 0.25, zs[-1] + 0.25),
              cmap=ListedColormap(colors), vmin=-0.5, vmax=len(colors) - 0.5, interpolation="nearest", alpha=0.55)
    # Atlas boundaries: thin grey.  Outer surface = tissue / no-label edge (pia, and ventricle walls).
    ax.contour(xs, zs, (img > 0).astype(float), [0.5], colors=ATLAS_LINE, linewidths=0.7)
    white = names.index("white_matter") + 1
    ax.contour(xs, zs, (img == white).astype(float), [0.5], colors=ATLAS_LINE, linewidths=0.6, linestyles=":")
    if support and ctx.prior:
        mask = np.zeros(img.shape, bool)
        for r in ctx.prior["regions"]:
            mask |= img == names.index(r) + 1
        dist = ndi.distance_transform_edt(~mask) * 0.5
        ax.contour(xs, zs, (dist <= float(ctx.prior.get("margin_mm", 6.0))).astype(float), [0.5],
                   colors=SUPPORT_COLOR, linewidths=0.9, linestyles="-.")
    for k, name in enumerate(names[:-2], start=1):
        mask = img == k
        if mask.sum() < 40:
            continue
        lab, n = ndi.label(mask)
        biggest = 1 + int(np.argmax(ndi.sum(mask, lab, range(1, n + 1))))
        iz, ix = np.unravel_index(np.argmax(ndi.distance_transform_edt(lab == biggest)), mask.shape)
        ax.text(xs[ix], zs[iz], name, fontsize=7, ha="center", va="center", color=ATLAS_LINE,
                bbox=dict(boxstyle="round,pad=0.15", fc="white", ec="none", alpha=0.75))
    # Transformed QNP section: heavy black outline, dashed black gray/white, red pia.
    t = transform or _transform_from_row(row)
    origin, _, _, _ = plane_geometry(ctx.atlas, 0.0, 0.0, y)
    X, nu, _ = ctx.particles(stain, ctx.levels[-1])
    P = t.section_to_moving(X) + origin[[0, 2]]
    tissue = splat(P, nu.sum(1), xs, zs, 0.5)
    wm = splat(P, nu[:, 1], xs, zs, 0.5)
    ref = np.percentile(tissue[tissue > 0], 90)
    frac = np.where(tissue > 1e-9, wm / np.maximum(tissue, 1e-9), 0.0)
    ax.contour(xs, zs, tissue / ref, [0.35], colors=INK, linewidths=1.6)
    ax.contour(xs, zs, np.where(tissue / ref > 0.35, frac, 0.0), [0.5], colors=INK, linewidths=1.1, linestyles="--")
    rib, depth = ctx.ribbon_local()
    pia = t.section_to_moving(rib[depth <= 100]) + origin[[0, 2]]
    ax.scatter(pia[::3, 0], pia[::3, 1], s=2.0, c=PIA_COLOR, linewidths=0, rasterized=True)
    ax.set_xlim(x_range)
    ax.set_ylim(z_range)
    ax.set_aspect("equal")
    ax.set_xlabel("MNI x (mm)")
    ax.set_ylabel("MNI z (mm)")


def run_stack_report(ctx: StackContext) -> dict:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.lines import Line2D
    from matplotlib.patches import Patch
    from preprocess.section_alignment import FootprintScorer

    done = [lv for lv in ctx.levels if (ctx.out / f"profile_{lv}.json").exists()]
    if not done:
        raise SystemExit("Run --stage profile first.")
    level = done[-1]
    summaries = {lv: json.loads((ctx.out / f"profile_{lv}.json").read_text()) for lv in done}
    rows = {lv: _read_rows(ctx.out / f"profile_{lv}.csv") for lv in done}
    roles = ctx.roles()["sections"]
    final = summaries[level]
    anchors = list(final["anchors"])
    regions = list(ctx.scan["fine_regions"]) + list(FINE_ORDER_TAIL)
    rib, depth = ctx.ribbon_local()
    rib = rib[:: int(ctx.scan.get("ribbon_subsample", 10))]
    report = {"job": ctx.job["_name"], "final_level": level, "levels_run": done,
              "delta_per_level": {lv: s["delta"]["delta"] for lv, s in summaries.items()},
              "union_window_per_level": {lv: s.get("union_window_y") for lv, s in summaries.items()},
              "priors": ["coronal planes only (tilt not freed)",
                         *([f"dissection-region prior: atlas restricted to within {ctx.prior.get('margin_mm')} mm of "
                            f"{', '.join(ctx.prior['regions'])}"] if ctx.prior else []),
                         ctx.search_y_range()[2]],
              "sections": {}}
    if ctx.slab_prior is not None:
        from preprocess.anatomical_slab import slab_consistency

        sp = ctx.slab_prior
        d = final["delta"]["delta"]
        per_anchor = {}
        for a in anchors:
            prof: dict[float, float] = {}
            for r in rows[level]:
                if r["representation"] == a:
                    prof[r["y0_mm"]] = min(prof.get(r["y0_mm"], np.inf), r["score"])
            res = slab_consistency(prof, sp["candidates"], d)
            per_j = {}
            for s in res["slabs"]:
                cur = per_j.get(str(s["j"]))
                if cur is None or s["best_score"] < cur["best_score"]:
                    per_j[str(s["j"])] = {k: s[k] for k in ("best_score", "best_y_mm", "delta_mm")}
            per_anchor[a] = {"consistent_slabs_j_delta_range_mm": res["consistent"], "best_per_offset_j": per_j}
        report["landmark_slab"] = {"record": "landmark_slab.json", "landmark": {k: sp["landmark"][k] for k in ("name", "y_mm", "s_mm", "method")},
                                   "search_interval_y_mm": sp["search_interval"]["y_mm"],
                                   "windows_at_prior_bound": final.get("windows_at_prior_bound", []),
                                   "slab_consistency": per_anchor,
                                   "note": "consistent = candidate slabs S_j(delta) whose best plane is within delta of the best "
                                           "slab, at the final level; a slab prior is not image evidence"}

    def best_row(lv, a):
        return min((r for r in rows[lv] if r["representation"] == a), key=lambda r: r["score"])

    for a in anchors:
        w = final["anchors"][a]
        r = best_row(level, a)
        origin, u, v, _ = plane_geometry(ctx.atlas, 0.0, 0.0, r["y0_mm"])
        landing = landing_fractions(ctx.atlas, _transform_from_row(r), origin, u, v, rib, regions)
        deciding = next((lv for lv in done if summaries[lv]["anchors"].get(a, {}).get("width_mm") == w["width_mm"]), level)
        report["sections"][a] = {
            "role": "anchor" if not w["flat"] else "passenger (flat depth profile)",
            "role_source": roles[a]["role_source"], "stacking_coordinate_y_mm": w["best_y"],
            "window_y_mm": w["window_y"], "window_contiguous": w["contiguous"],
            "deciding_level": deciding, "transform": {k: r[k] for k in ("theta_deg", "scale", "flip", "tau_x", "tau_y")},
            "score": r["score"], "contrast_in_delta": w["contrast_median_minus_best"] / final["delta"]["delta"],
            "ribbon_landing_qc_only": landing, "particles": final["particles"][a]}
    passengers_file = ctx.out / "passengers.json"
    if passengers_file.exists():
        pas = json.loads(passengers_file.read_text())
        for s, p in pas["passengers"].items():
            report["sections"][s] = {"role": "passenger", "role_source": roles.get(s, {}).get("role_source"),
                                     "failed_checks": p["role_reason"], "stacking_coordinate_y_mm": pas["host_best_y"],
                                     "window_y_mm": p["inherited_window_y"], "deciding_level": f"inherited from {pas['host_anchor']}",
                                     "transform": f"{pas['host_anchor']}'s atlas pose composed with the local-frame edge",
                                     "outline_fit_to_host": p["direct_outline_fit_to_host"]["score"],
                                     "outline_fit_displacement_mm": p["direct_outline_fit_to_host"]["displacement_from_composed_mm"]}
    # Weak ordering (skill step 7): pairwise tissue-outline scores in the local frame.
    full = ctx.levels[-1]
    parts = {s: ctx.particles(s, full) for s in ctx.stains}
    pair = {}
    for s in ctx.stains:
        scorer = FootprintScorer(parts[s][0], parts[s][1].sum(1, keepdims=True), ctx.sigmas)
        pair[s] = {o: scorer.score(parts[o][0], parts[o][1].sum(1, keepdims=True)) for o in ctx.stains if o != s}
    report["pairwise_outline_scores"] = pair
    report["per_slice_z"] = ("not estimated: section order and spacing are below the atlas window; "
                             "pairwise outline scores give at most a weak order")
    (ctx.out / "report.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")

    # ---- figure: depth profiles per anchor, one row per level, delta band --------------
    fig, axes = plt.subplots(len(done), len(anchors), figsize=(4.6 * len(anchors), 3.4 * len(done)),
                             squeeze=False, constrained_layout=True)
    level_name = {lv: (f"~{summaries[lv]['particles'][anchors[0]]} particles" if lv in ctx.compression_levels
                       else f"full {lv} particles") for lv in done}
    for i, lv in enumerate(done):
        d = summaries[lv]["delta"]["delta"]
        for j, a in enumerate(anchors):
            ax = axes[i, j]
            for fam in sorted({r["family"] for r in rows[lv]}):
                sel = sorted((r for r in rows[lv] if r["representation"] == a and r["family"] == fam), key=lambda r: r["y0_mm"])
                yy = np.array([r["y0_mm"] for r in sel])
                ss = np.array([r["score"] for r in sel])
                gap = np.flatnonzero(np.diff(yy) > float(ctx.cfg["profile"].get("step_mm", 0.5)) + 1e-6) + 1
                yy, ss = np.insert(yy, gap, np.nan), np.insert(ss, gap, np.nan)  # no line across unsearched depths
                ax.plot(yy, ss, color="#2a78d6" if fam != "flipped" else "#eb6834", lw=1.6, marker="o", ms=2.5)
            w = summaries[lv]["anchors"][a]
            ax.axhspan(w["best_score"], w["best_score"] + d, color="#eda100", alpha=0.25, lw=0)
            ax.axvspan(w["window_y"][1], w["window_y"][0], color="#c4c2b9", alpha=0.35, lw=0)
            if ctx.slab_prior is not None:
                lm = ctx.slab_prior["landmark"]
                ax.axvline(lm["y_mm"], color="#1baf7a", lw=1.0, ls="--")
                for edge in ctx.slab_prior["search_interval"]["y_mm"]:
                    ax.axvline(edge, color="#52514e", lw=0.8, ls=":")
            ax.set_title(f"{a}, {level_name[lv]}", fontsize=10)
            ax.set_xlabel("coronal plane y (MNI mm)")
            ax.set_ylabel("varifold score (0 = identical)")
            ax.invert_xaxis()
    handles = [Patch(fc="#eda100", alpha=0.25, label="best score + δ"), Patch(fc="#c4c2b9", alpha=0.35, label="window (within δ)")]
    if ctx.slab_prior is not None:
        handles += [Line2D([], [], color="#1baf7a", lw=1.0, ls="--",
                           label=f"{ctx.slab_prior['landmark']['name']} first appearance"),
                    Line2D([], [], color="#52514e", lw=0.8, ls=":", label="slab-prior search bound")]
    fig.legend(handles=handles, loc="outside lower center", ncol=len(handles), frameon=False)
    fig.savefig(ctx.out / "depth_profiles.png", dpi=130)
    plt.close(fig)

    # ---- figure: best pose per anchor over a wide coronal atlas slice ----------------
    x_range, z_range = tuple(ctx.cfg.get("figure_x_range_mm", (-80.0, -10.0))), tuple(ctx.cfg.get("figure_z_range_mm", (-50.0, 30.0)))
    fig, axes = plt.subplots(1, len(anchors), figsize=(6.0 * len(anchors), 6.4), squeeze=False, constrained_layout=True)
    for ax, a in zip(axes[0], anchors):
        r = best_row(level, a)
        _draw_pose(ax, ctx, a, level, r, x_range, z_range, support=bool(ctx.prior))
        flags = pose_flags(ctx, final, a, r)
        report["sections"][a]["flags"] = flags
        ax.set_title(f"{a} best pose, coronal y {r['y0_mm']:+.1f} mm" + ("".join(f"\n⚠ {f}" for f in flags)),
                     fontsize=10, color="#b3261e" if flags else INK)
    handles = _pose_legend_handles(regions + list(_qc_tables(ctx)), support=bool(ctx.prior))
    fig.legend(handles=handles, loc="outside lower center", ncol=4, frameon=False, fontsize=9)
    (ctx.out / "report.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    fig.savefig(ctx.out / "best_poses.png", dpi=130)
    plt.close(fig)

    # ---- markdown report ---------------------------------------------------------------
    lines = [f"# Stacking coordinate: {ctx.job['_name']}", "",
             f"Final level: {level}. δ per level: " + ", ".join(f"{lv} {d:.4f}" for lv, d in report["delta_per_level"].items() if d),
             "", "| Section | Role | y (mm) | Window (mm) | Deciding level | θ (°) | scale | flip | score | MTG landing (QC) |",
             "|---|---|---|---|---|---|---|---|---|---|"]
    target = next(iter(ctx.scan["fine_regions"]))
    for s, e in report["sections"].items():
        t = e["transform"] if isinstance(e["transform"], dict) else {}
        lines.append(f"| {s} | {e['role']} | {e['stacking_coordinate_y_mm']:+.1f} | {e['window_y_mm'][0]:+.1f} … {e['window_y_mm'][1]:+.1f} | "
                     f"{e['deciding_level']} | {t.get('theta_deg', float('nan')):.1f} | {t.get('scale', float('nan')):.3f} | "
                     f"{t.get('flip', '')} | {e.get('score', float('nan')):.4f} | "
                     f"{e.get('ribbon_landing_qc_only', {}).get(target, float('nan')):.2f} |")
    flagged = {s: e["flags"] for s, e in report["sections"].items() if e.get("flags")}
    if flagged:
        lines += ["", "Search-boundary flags: " + "; ".join(f"{s}: {', '.join(f)}" for s, f in flagged.items()) + "."]
    lines += ["", "Priors: " + "; ".join(report["priors"]) + ".", "", report["per_slice_z"] + "."]
    if "landmark_slab" in report:
        ls_ = report["landmark_slab"]
        lines += ["", f"Landmark slab ({ls_['landmark']['name']} y {ls_['landmark']['y_mm']:+.1f} mm; "
                      f"search y {ls_['search_interval_y_mm'][0]:+.1f} … {ls_['search_interval_y_mm'][1]:+.1f}). "
                      "Candidate slabs S_j(δ) consistent with each anchor's final profile "
                      "(j: −1 anterior, 0 landmark slab, +1 posterior; δ = cutting phase, mm):", ""]
        for a, c in ls_["slab_consistency"].items():
            lines.append(f"- {a}: " + ", ".join(f"j {j} (δ {d[0]:g}–{d[1]:g})" for j, d in
                                                 sorted(c["consistent_slabs_j_delta_range_mm"].items(), key=lambda kv: int(kv[0]))))
        if ls_["windows_at_prior_bound"]:
            lines += ["", f"Windows reaching the prior's AP bound (evidence pushes against the prior): "
                          f"{', '.join(ls_['windows_at_prior_bound'])}."]
    (ctx.out / "REPORT.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("\n".join(lines))
    return report


# ---- candidates: unconstrained vs admissible placement, data only ---------------------

def _mm(value) -> str:
    return "n/a" if value is None else f"{value:.1f} mm"


def run_candidates(ctx: StackContext) -> dict:
    """Compare, per anchor, the unconstrained best and the admissible best placement.

    Both are read from the existing profiles at the deepest level run in both folders (the
    admissible run = this run's priors).  The *data-only* score is the stacking score against
    the full, uncropped coronal atlas plane, so the two placements share one objective; the
    admissible pose is also refined locally on that objective (does the data keep it there?).
    The prior enters only as admissibility (AP slab interval, atlas support); its effect on the
    score is the admissible search score minus the data-only score, reported separately.
    Diagnostics (no thresholds decide anything): ribbon landing, distance of the QNP pia to the
    atlas outer surface, of the QNP gray/white boundary to the atlas one, of the ribbon to the
    admissible gray matter, the share of section tissue inside the admissible support, pose,
    and a local pitch x yaw check (the search is coronal).
    """

    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from preprocess.qnp_stacking import (boundary_distance_map, distance_summary, gray_white_boundary_points,
                                         grid_lookup, level_sigmas, make_scorer, placement_status, plane_measure,
                                         region_distance_map, depth_inside_hull)
    from preprocess.section_alignment import reslice_labels
    from preprocess.section_alignment_gpu import pad_measures, refine_batch

    if ctx.out == ctx.base_out:
        raise SystemExit("--stage candidates compares an admissible run (--region-prior and/or --landmark-slab) "
                         "with the unconstrained one")
    common = [lv for lv in ctx.levels if (ctx.out / f"profile_{lv}.json").exists()
              and (ctx.base_out / f"profile_{lv}.json").exists()]
    if not common:
        raise SystemExit("profile both the unconstrained and the admissible run first")
    level = common[-1]
    runs = {"unconstrained": ctx.base_out, "admissible": ctx.out}
    summaries = {k: json.loads((p / f"profile_{level}.json").read_text()) for k, p in runs.items()}
    rows = {k: _read_rows(p / f"profile_{level}.csv") for k, p in runs.items()}
    delta = summaries["unconstrained"]["delta"]["delta"]  # data-objective noise (uncropped atlas)
    ccfg = ctx.cfg.get("candidates", {})
    search = ctx.cfg["search"]
    scale_bounds = tuple(float(s) for s in search.get("scale_bounds", (0.8, 1.5)))
    steps = int(ccfg.get("refine_steps", 200))
    tilts = [float(t) for t in ccfg.get("tilt_deg", (-10, -5, 0, 5, 10))]
    step = float(ctx.cfg["profile"].get("step_mm", 0.5))
    atlas, res = ctx.atlas, 0.5
    extra = _qc_tables(ctx)
    atlas_ext = {**atlas, "fine": {**atlas["fine"], **extra}}
    land_names = list(ctx.scan["fine_regions"]) + list(FINE_ORDER_TAIL) + list(extra)  # later names win
    adm_regions = list(ctx.prior["regions"]) if ctx.prior else list((ctx.slab_cfg or {}).get("sampling_regions", []))
    margin = float(ctx.prior.get("margin_mm", 6.0)) if ctx.prior else None
    interval = ctx.slab_prior["search_interval"]["y_mm"] if ctx.slab_prior else None
    with np.load(ctx.aligned / "multistain_maps_32um_local.npz") as archive:
        ms = {k: archive[k] for k in archive.files}
    ms_stains = [str(s) for s in ms["stains"]]
    rib, depth = ctx.ribbon_local()
    pia_pts, rib_pts = rib[depth <= 100], rib[:: max(1, len(rib) // 4000)]
    maps: dict[float, dict] = {}

    def plane_maps(y: float) -> dict:
        if y not in maps:
            origin, u, v, _ = plane_geometry(atlas, 0.0, 0.0, y)
            grid, axis = reslice_labels(atlas["labels"], atlas["affine"], origin, u, v, float(ctx.scan["half_width_mm"]), res)
            g = np.clip(grid, 0, len(atlas["coarse"]["white_matter"]) - 1)
            gray, white = atlas["coarse"]["gray_matter"][g], atlas["coarse"]["white_matter"][g]
            adm = np.zeros(grid.shape, bool)
            for r in adm_regions:
                adm |= atlas["fine"][r][g]
            maps[y] = {"origin": origin, "u": u, "v": v, "axis": axis,
                       "pial": boundary_distance_map(grid > 0, res),
                       "gray_white": region_distance_map(white & ndi.binary_dilation(gray), res),
                       "admissible_gray": region_distance_map(adm, res),
                       "measure": plane_measure(atlas, ctx.scan, y, None)}
        return maps[y]

    def evaluate(scorer, anchor, y, t, X, nu, gw_pts, sulcal) -> dict:
        m = plane_maps(y)
        P, mu = m["measure"]
        place = t.section_to_moving
        out = {"y0_mm": y, "pose": {"theta_deg": t.theta_deg % 360, "scale": t.scale, "flip": t.flip,
                                    "tau_mm": list(t.tau), "pitch_deg": 0.0, "yaw_deg": 0.0},
               "data_only_score": float(scorer.score_transforms([t], P, mu)[0]),
               "ribbon_landing": landing_fractions(atlas_ext, t, m["origin"], m["u"], m["v"], rib_pts, land_names),
               "qnp_pia_to_atlas_outer_surface": distance_summary(grid_lookup(place(pia_pts), m["pial"], m["axis"], res)),
               # Split: exposed pia (on the section's convex hull) vs pia lining a sulcus (> 2.5 mm inside).
               "qnp_exposed_pia_to_atlas_outer_surface": distance_summary(
                   grid_lookup(place(pia_pts[~sulcal]), m["pial"], m["axis"], res)),
               "qnp_sulcal_pia_to_atlas_outer_surface": distance_summary(
                   grid_lookup(place(pia_pts[sulcal]), m["pial"], m["axis"], res)),
               "qnp_gray_white_to_atlas_gray_white": distance_summary(
                   grid_lookup(place(gw_pts), m["gray_white"], m["axis"], res)),
               "ribbon_to_admissible_gray": {"regions": adm_regions, **distance_summary(
                   grid_lookup(place(rib_pts), m["admissible_gray"], m["axis"], res))}}
        if margin is not None:
            d = grid_lookup(place(X), m["admissible_gray"], m["axis"], res)
            out["tissue_in_admissible_support"] = float(nu.sum(1)[np.nan_to_num(d, nan=np.inf) <= margin].sum() / nu.sum())
        if interval is not None:
            out["in_slab_interval"] = bool(min(interval) - 1e-6 <= y <= max(interval) + 1e-6)
        return out

    def tilt_check(scorer, y, t) -> dict:
        spacing, aggregate = float(ctx.scan["reslice_mm"]), int(round(float(ctx.scan["scan_bin_mm"]) / float(ctx.scan["reslice_mm"])))
        grid, measures = [], []
        for pitch in tilts:
            for yaw in tilts:
                origin, u, v, _ = plane_geometry(atlas, pitch, yaw, y)
                P, nuP = plane_particles(atlas, ctx.scan, origin, u, v, spacing, aggregate, "coarse")
                keep = nuP.sum(1) > 0
                grid.append((pitch, yaw))
                measures.append((P[keep, :2], nuP[keep]))
        Pp, mup = pad_measures(measures)
        refined = refine_batch(scorer, Pp, mup, [t] * len(grid), scale_bounds, steps)
        scores = np.array([s for s, _ in refined])
        k0 = grid.index((0.0, 0.0))
        k = int(np.argmin(scores))
        return {"grid_deg": tilts, "refined_from": "the candidate pose, per tilted plane through the same centre",
                "coronal_refined_score": float(scores[k0]), "best_pitch_yaw_deg": list(grid[k]),
                "best_score": float(scores[k]),
                "gain_in_delta": float((scores[k0] - scores[k]) / delta) if delta else None}

    record = {"job": ctx.job["_name"], "level": level, "delta_data_only": delta,
              "admissible_run": str(ctx.out.relative_to(ctx.base_out.parent)),
              "admissibility": {"ap_interval_y_mm": interval, "support_regions": adm_regions if ctx.prior else None,
                                "support_margin_mm": margin,
                                "how": "the admissible search sees only atlas tissue in the support and the AP interval; "
                                       "no overlap threshold"},
              "data_only": "stacking score vs the full uncropped coronal atlas plane (same scorer, same level)",
              "anchors": {}}
    figure_rows = []
    for anchor in [a for a, w in summaries["admissible"]["anchors"].items() if not w["flat"]]:
        X, nu, _ = ctx.particles(anchor, level)
        scorer = make_scorer(X, nu, level_sigmas(ctx.sigmas, ctx.h_mm(level)))
        k = ms_stains.index(anchor)
        gw_pts = gray_white_boundary_points(ms["p_wm"][k], ms["tissue"][k], ms["origin_mm"], ms["px_mm"])
        sulcal = depth_inside_hull(pia_pts, X) > 2.5
        entry, poses = {}, {}
        for name in runs:
            best = min((r for r in rows[name] if r["representation"] == anchor), key=lambda r: r["score"])
            t = _transform_from_row(best)
            P, mu = plane_maps(best["y0_mm"])["measure"]
            (ref_score, t_ref), = refine_batch(scorer, P, mu, [t], scale_bounds, steps)
            if ref_score > float(scorer.score_transforms([t], P, mu)[0]):
                t_ref = t  # refine keeps its best iterate; never worse than the start
            e = {"search_score": best["score"],
                 "search_objective": "uncropped atlas" if name == "unconstrained" else "admissible (cropped) atlas",
                 "search_pose": evaluate(scorer, anchor, best["y0_mm"], t, X, nu, gw_pts, sulcal),
                 "refined_on_full_atlas": evaluate(scorer, anchor, best["y0_mm"], t_ref, X, nu, gw_pts, sulcal),
                 "flags": pose_flags(ctx, summaries[name], anchor, best)}
            e["refined_on_full_atlas"]["tilt_check"] = tilt_check(scorer, best["y0_mm"], t_ref)
            # Prior's share of the admissible score: search score (cropped) minus data-only score.
            e["prior_effect_on_score"] = best["score"] - e["search_pose"]["data_only_score"]
            entry[name] = e
            poses[name] = (best, t, t_ref)
        # Same placement: same depth (one step) and ribbon points within 1 mm (2 atlas voxels).
        bu, tu, _ = poses["unconstrained"]
        ba, ta, _ = poses["admissible"]
        wu = plane_maps(bu["y0_mm"])
        wa = plane_maps(ba["y0_mm"])
        world = lambda m, t: m["origin"] + t.section_to_moving(rib_pts)[:, :1] * m["u"] + t.section_to_moving(rib_pts)[:, 1:2] * m["v"]
        shift = float(np.median(np.linalg.norm(world(wu, tu) - world(wa, ta), axis=1)))
        same = abs(bu["y0_mm"] - ba["y0_mm"]) <= step + 1e-6 and shift <= 1.0
        gap = (entry["admissible"]["refined_on_full_atlas"]["data_only_score"]
               - entry["unconstrained"]["refined_on_full_atlas"]["data_only_score"])
        entry["comparison"] = {"ribbon_shift_between_placements_mm": shift, "same_placement": bool(same),
                               "data_only_gap": gap, "data_only_gap_in_delta": gap / delta if delta else None,
                               "status": placement_status(same, gap / delta if delta else None)}
        record["anchors"][anchor] = entry
        figure_rows.append((anchor, poses, entry))
        print(f"{anchor}: unconstrained y {bu['y0_mm']:+.1f} / admissible y {ba['y0_mm']:+.1f}; data-only gap "
              f"{gap:+.4f} ({gap / delta:+.1f} delta); {entry['comparison']['status']}", flush=True)

    # Job verdict: anchors' admissible windows must intersect, and nothing flagged.
    ws = [summaries["admissible"]["anchors"][a]["window_y"] for a in record["anchors"]]
    top, bottom = min(w[0] for w in ws), max(w[1] for w in ws)
    statuses = [e["comparison"]["status"].split(":")[0] for e in record["anchors"].values()]
    flags = {a: e["admissible"]["flags"] for a, e in record["anchors"].items() if e["admissible"]["flags"]}
    reasons = []
    if top < bottom:
        reasons.append("anchors' admissible depth windows do not intersect")
    if flags:
        reasons.append("search-boundary optima: " + "; ".join(f"{a}: {', '.join(f)}" for a, f in flags.items()))
    if any(s == "prior-driven" for s in statuses):
        reasons.append(f"prior-driven for {sum(s == 'prior-driven' for s in statuses)}/{len(statuses)} anchors")
    if all(s in ("prior inactive", "image-supported") for s in statuses) and not reasons:
        verdict = "supported by image geometry"
    elif any(s == "prior-driven" for s in statuses):
        verdict = "primarily prior-driven"
    elif all(s in ("prior inactive", "image-supported", "tie within delta") for s in statuses) and not reasons:
        verdict = "image ties; the prior selects"
    else:
        verdict = "unresolved"
    record["verdict"] = {"summary": verdict, "reasons": reasons, "admissible_window_intersection_y_mm":
                         [top, bottom] if top >= bottom else None, "anchor_statuses": statuses}
    (ctx.out / "candidates.json").write_text(json.dumps(record, indent=2, default=float) + "\n", encoding="utf-8")

    # ---- figure: per anchor, unconstrained | admissible | admissible refined on the full atlas ----
    x_range, z_range = tuple(ctx.cfg.get("figure_x_range_mm", (-80.0, -10.0))), tuple(ctx.cfg.get("figure_z_range_mm", (-50.0, 30.0)))
    fig, axes = plt.subplots(len(figure_rows), 3, figsize=(18.0, 6.0 * len(figure_rows)), squeeze=False,
                             constrained_layout=True)
    target = next(iter(ctx.scan["fine_regions"]))
    for i, (anchor, poses, entry) in enumerate(figure_rows):
        panels = [("unconstrained best", "unconstrained", poses["unconstrained"][1], "search_pose"),
                  ("admissible best (search)", "admissible", poses["admissible"][1], "search_pose"),
                  ("admissible, refined on full atlas", "admissible", poses["admissible"][2], "refined_on_full_atlas")]
        for j, (label, run, t, which) in enumerate(panels):
            ax = axes[i, j]
            row = poses[run][0]
            ev = entry[run][which]
            _draw_pose(ax, ctx, anchor, level, row, x_range, z_range, transform=t, support=bool(ctx.prior))
            flags = entry[run]["flags"] if which == "search_pose" else pose_flags(ctx, summaries[run], anchor, row, t)
            land = ev["ribbon_landing"]
            shown = [n for n in (target, "STG", "ITG", "temporal_plane", "insula") if n in land]
            lines = [f"{anchor} · {label} · y {row['y0_mm']:+.1f} mm",
                     f"data-only {ev['data_only_score']:.4f} · θ {ev['pose']['theta_deg']:.0f}° · s {ev['pose']['scale']:.3f}"
                     f" · flip {ev['pose']['flip']}",
                     "ribbon: " + ", ".join(f"{n.replace('temporal_plane', 'temp. plane')} {land[n]:.2f}" for n in shown),
                     f"pia→atlas surface p50: exposed {_mm(ev['qnp_exposed_pia_to_atlas_outer_surface']['p50_mm'])}, "
                     f"sulcal {_mm(ev['qnp_sulcal_pia_to_atlas_outer_surface']['p50_mm'])} · "
                     f"gray/white p50 {_mm(ev['qnp_gray_white_to_atlas_gray_white']['p50_mm'])}"]
            if j == 2:
                lines.append(entry["comparison"]["status"].split(":")[0]
                             + f" (data-only gap {entry['comparison']['data_only_gap_in_delta']:+.1f} δ)")
            lines += [f"⚠ {f}" for f in flags]
            ax.set_title("\n".join(lines), fontsize=8, loc="left", color="#b3261e" if flags else INK)
    handles = _pose_legend_handles(list(ctx.scan["fine_regions"]) + list(extra) + list(FINE_ORDER_TAIL),
                                   support=bool(ctx.prior))
    fig.legend(handles=handles, loc="outside lower center", ncol=4, frameon=False, fontsize=9)
    fig.suptitle(f"{ctx.job['_name']}, level {level}: data-only placements vs admissible placement. "
                 f"Verdict: {verdict}" + (f" ({'; '.join(reasons)})" if reasons else ""), fontsize=10)
    fig.savefig(ctx.out / "candidates.png", dpi=120)
    plt.close(fig)
    print(json.dumps(record["verdict"], indent=1))
    return record


# ---- landmark slab -------------------------------------------------------------------

def run_landmark(ctx: StackContext) -> dict:
    """Landmark, candidate slabs (``landmark_slab.json``) and the anatomical figures.

    Figures (``visualization/figures_slab.py``): 3-D slab in the brain, labelled coronal montage
    around the landmark, sagittal localisation.  Stacking windows are drawn on the sagittal view
    when a stacking report exists (this prior's folder first, else the unconstrained run), and the
    labelled view of the best poses is ``best_poses.png`` of ``--stage stack-report``.
    """

    from visualization.figures_slab import render_slab_figures

    record = ctx.slab_prior
    lm = record["landmark"]
    print(f"{lm['name']}: y {lm['y_mm']:+.2f} mm (s {lm['s_mm']:.2f}); {lm['method']}", flush=True)
    print(f"search interval y {record['search_interval']['y_mm']}; offsets {record['slab_offsets']}; "
          f"{len(record['candidates'])} candidate slabs", flush=True)
    windows, source = None, None
    for folder in (ctx.out, ctx.base_out):
        if (folder / "report.json").exists():
            report = json.loads((folder / "report.json").read_text())
            windows = {s: e["window_y_mm"] for s, e in report["sections"].items() if "anchor" == e.get("role")}
            source = str(folder.relative_to(ctx.base_out.parent))
            break
    import nibabel as nib

    template = nib.load(str(resolve_path(ctx.config, ctx.scan["template_nifti"])))
    if not np.allclose(template.affine, ctx.atlas["affine"]) or template.shape != ctx.atlas["labels"].shape:
        raise SystemExit("template_nifti and annotation_nifti are not on the same grid")
    paths = render_slab_figures(ctx.atlas, np.asanyarray(template.dataobj), ctx.scan, ctx.slab_cfg, record, ctx.out,
                                windows=windows, windows_source=source)
    for p in paths:
        print(f"wrote {p}")
    return record


def main() -> None:
    args = parse_args()
    config = load_config(args.config)
    job = resolve_qnp_job(config, args.job)
    scan = job["atlas_scan"]
    if args.stage in STACK_STAGES:
        ctx = StackContext(config, job, region_prior=args.region_prior,
                           landmark_slab=args.landmark_slab or args.stage == "landmark")
        if args.stage == "landmark":
            run_landmark(ctx)
        elif args.stage == "candidates":
            run_candidates(ctx)
        elif args.stage == "roles":
            run_roles(ctx)
        elif args.stage == "compress":
            run_compress(ctx, args.overwrite)
        elif args.stage == "slabs":
            run_slabs(ctx)
        elif args.stage == "profile":
            level = args.level or next((lv for lv in ctx.levels if not (ctx.out / f"profile_{lv}.json").exists()), None)
            if level not in ctx.levels:
                raise SystemExit(f"--level must be one of {ctx.levels} (all profiled already?)")
            run_profile(ctx, level, args.families or bool(ctx.cfg.get("families", False)))
        elif args.stage == "passengers":
            run_passengers(ctx)
        else:
            run_stack_report(ctx)
        return
    out_dir = resolve_path(config, scan["output_dir"])
    out_dir.mkdir(parents=True, exist_ok=True)
    if args.stage == "scan":
        run_scan(args, config, job, scan, out_dir)
    elif args.stage == "summarize":
        run_summarize(config, job, scan, out_dir)
    elif args.stage == "export":
        run_export(args, config, job, scan, out_dir)
    elif args.stage == "graph":
        run_graph(config, job, scan, out_dir)
    elif args.stage == "atlas-features":
        run_atlas_features(config, job, scan, out_dir)
    else:
        if not args.fit_dir:
            raise SystemExit("--stage evaluate needs --fit-dir")
        if not args.plane:
            raise SystemExit("--stage evaluate needs --plane (the exported plane id)")
        run_evaluate(args, config, job, scan, out_dir)


if __name__ == "__main__":
    main()
