"""Anatomical slab prior (preprocess.anatomical_slab) and its use by the stacking search."""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pytest

SRC = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(SRC), str(SRC / "preprocess"), str(SRC / "config_setup"), str(SRC / "scripts")]

from preprocess.anatomical_slab import (  # noqa: E402
    build_slab_prior,
    candidate_slabs,
    clamp_ys,
    locate_landmark,
    offset_cover,
    posterior_mm,
    search_interval,
    slab_consistency,
)

LGN = 7


def _volume(flip_j: bool = False):
    """40 x 60 x 30 voxels at 0.5 mm, RAS world; a 'landmark' blob spanning world y -22 ... -28.

    One isolated voxel sits at y -20 (anterior to the blob) to exercise min_area_mm2.
    With ``flip_j`` the voxel j axis runs posterior (negative affine y column): same world.
    """

    labels = np.zeros((40, 60, 30), np.int16)
    affine = np.array([[0.5, 0, 0, -15.0], [0, 0.5, 0, -40.0], [0, 0, 0.5, -10.0], [0, 0, 0, 1]])
    j = lambda y: int(round((y - affine[1, 3]) / 0.5))
    labels[5:10, j(-28.0):j(-22.0) + 1, 10:14] = LGN   # x < 0 (left), 5 x 4 voxels = 5 mm^2 per plane
    labels[30:32, j(-25.0), 10:12] = LGN              # right hemisphere copy, smaller
    labels[6, j(-20.0), 11] = LGN                      # stray voxel: 0.25 mm^2
    if flip_j:
        labels = labels[:, ::-1, :]
        flip = np.diag([1.0, -1.0, 1.0, 1.0])
        flip[1, 3] = labels.shape[1] - 1
        affine = affine @ flip
    return labels, affine


@pytest.mark.parametrize("flip_j", [False, True])
def test_landmark_first_appearance_uses_world_y_not_voxel_index(flip_j):
    labels, affine = _volume(flip_j)
    lm = locate_landmark(labels, affine, {"name": "LGN", "codes": [LGN], "min_area_mm2": 1.0}, "left")
    assert lm["y_mm"] == pytest.approx(-22.0)          # most anterior plane with >= 1 mm^2
    assert lm["first_any_voxel_y_mm"] == pytest.approx(-20.0)  # the stray voxel, rejected by area
    assert lm["s_mm"] == pytest.approx(22.0)            # s = -y increases posteriorly
    assert lm["area_at_landmark_mm2"] == pytest.approx(5.0)
    assert lm["centroid_mm"][0] < 0 and lm["centroid_mm"][1] == pytest.approx(-22.0)
    ys = [r[0] for r in lm["profile_y_area_mm2"]]
    assert ys == sorted(ys, reverse=True)               # reported anterior -> posterior


def test_manual_landmark_and_missing_label():
    labels, affine = _volume()
    lm = locate_landmark(labels, affine, {"name": "LGN", "codes": [LGN], "y_mm": -24.5}, "left")
    assert lm["y_mm"] == -24.5 and lm["method"].startswith("manual")
    assert lm["label_first_appearance_y_mm_for_comparison"] == pytest.approx(-20.0)
    with pytest.raises(ValueError, match="manually"):
        locate_landmark(labels, affine, {"name": "X", "codes": [99]}, "left")


def test_posterior_coordinate_direction():
    assert posterior_mm(-30.0) > posterior_mm(-20.0)   # more negative MNI y = more posterior


def test_slab_construction_4mm_and_offsets():
    s_L, h = 22.0, 4.0
    slabs = candidate_slabs(s_L, h, [-1, 0, 1], 0.5)
    assert len(slabs) == 3 * 8
    for c in slabs:
        s0, s1 = c["s_mm"]
        assert s1 - s0 == pytest.approx(h)
        assert c["y_mm"] == [pytest.approx(-s0), pytest.approx(-s1)]  # [anterior, posterior]
        assert 0.0 <= c["delta_mm"] < h
        if c["j"] == 0:
            assert s0 <= s_L <= s1                                     # the landmark slab contains s_L
        elif c["j"] == -1:
            assert s1 <= s_L + 1e-9                                    # anterior neighbour
        else:
            assert s0 >= s_L - 1e-9 and s0 > s_L - h                   # posterior neighbour
    assert offset_cover(s_L, h, 0) == (18.0, 26.0)
    assert offset_cover(s_L, h, -1) == (14.0, 22.0)
    assert offset_cover(s_L, h, 1) == (22.0, 30.0)


def test_search_interval_union_and_extension():
    iv = search_interval(22.0, 4.0, [-1, 0, 1], extension_mm=1.0)
    assert iv["s_mm"] == [13.0, 31.0]
    assert iv["y_mm"] == [-13.0, -31.0]
    assert search_interval(22.0, 4.0, [0])["y_mm"] == [-18.0, -26.0]  # narrowed: landmark slab only
    assert clamp_ys([-12.5, -13.0, -20.0, -31.0, -31.5], iv["y_mm"]) == [-13.0, -20.0, -31.0]


def test_slab_consistency_identifies_containing_slabs():
    rec = build_slab_prior({"name": "LGN", "y_mm": -22.0, "s_mm": 22.0}, {"slab_offsets": [-1, 0, 1]})
    ys = np.arange(-31.0, -12.9, 0.5)
    profile = {float(y): 0.2 + 0.01 * abs(y + 28.0) for y in ys}       # minimum at y = -28 (s = 28)
    res = slab_consistency(profile, rec["candidates"], delta_noise=0.0)
    # s = 28 lies only in posterior-neighbour slabs: j = +1 for delta <= 2 (s1 = 30 - delta >= 28)
    assert set(res["consistent"]) == {"1"}
    assert res["consistent"]["1"] == [0.0, 2.0]


def test_stacking_search_range_with_and_without_prior():
    from scan_atlas_planes_for_qnp import StackContext

    ctx = object.__new__(StackContext)
    ctx.cfg = {"slabs": {"y_pad_mm": 5.0}}
    ctx.scan = {"fine_regions": {"MTG": {}}}
    ctx._atlas = {"region_extent_y": [-72.5, 19.5]}
    ctx.slab_cfg, ctx._slab_prior = None, None
    lo, hi, note = ctx.search_y_range()
    assert (lo, hi) == (-77.5, 24.5) and "MTG y-extent" in note   # unchanged unconstrained range
    ctx.slab_cfg = {"slab_offsets": [-1, 0, 1], "extension_mm": 1.0}
    ctx._slab_prior = build_slab_prior({"name": "LGN", "y_mm": -22.0, "s_mm": 22.0, "method": "test: x"},
                                       ctx.slab_cfg)
    lo, hi, note = ctx.search_y_range()
    assert (lo, hi) == (-31.0, -13.0) and "LGN" in note


def test_slab_figures_render(tmp_path):
    pytest.importorskip("matplotlib")
    from visualization.figures_slab import coronal_montage, sagittal_view

    labels, affine = _volume()
    labels[labels == 0] = 1                                 # 'brain' everywhere
    labels[0:20, 20:40, 0:5] = 30                           # a left 'MTG' block
    n = int(labels.max()) + 1
    mtg = np.zeros(n, bool)
    mtg[30] = True
    atlas = {"labels": labels.astype(np.int32), "affine": affine, "fine": {"MTG": mtg},
             "centroid": np.array([-8.0, -25.0, -8.0])}
    scan = {"fine_regions": {"MTG": {}}, "hemisphere": "left"}
    cfg = {"slab_offsets": [-1, 0, 1], "extension_mm": 1.0, "figure_label_codes": {"LGN": [LGN]}}
    lm = locate_landmark(labels, affine, {"name": "LGN", "codes": [LGN], "min_area_mm2": 1.0}, "left")
    record = build_slab_prior(lm, cfg)
    template = np.full(labels.shape, 100, np.int16)
    a = coronal_montage(atlas, template, scan, cfg, record, tmp_path)
    b = sagittal_view(atlas, template, scan, cfg, record, tmp_path, windows={"NEUN": [-27.0, -28.0]}, windows_source="t")
    assert a.stat().st_size > 10_000 and b.stat().st_size > 10_000
