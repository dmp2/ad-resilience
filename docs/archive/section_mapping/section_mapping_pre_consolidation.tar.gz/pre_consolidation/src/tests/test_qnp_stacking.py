"""Stacking-coordinate building blocks (preprocess.qnp_stacking) on tiny synthetic inputs."""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pytest

SRC = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(SRC), str(SRC / "preprocess"), str(SRC / "config_setup")]

from preprocess.qnp_particles import remove_border_bands  # noqa: E402
from preprocess.qnp_stacking import (  # noqa: E402
    RoleThresholds,
    assign_role,
    compress,
    distinct_minima,
    escalation_ys,
    grid_initialization,
    level_sigmas,
    noise_delta,
    otsu_separability,
    stripe_index,
    window,
)


def _section(spacing: float = 0.5):
    """Gray/white masses on a lattice: a 12 x 8 mm block with a white core."""

    xs, ys = np.meshgrid(np.arange(0, 12, spacing), np.arange(0, 8, spacing))
    X = np.column_stack([xs.ravel(), ys.ravel()])
    white = ((X[:, 0] > 4) & (X[:, 0] < 9) & (X[:, 1] > 2) & (X[:, 1] < 6)).astype(float)
    area = spacing ** 2
    return X, np.column_stack([(1 - white) * area, white * area])


def test_grid_initialization_conserves_mass_and_centroid():
    X, nu = _section()
    Z, nuZ = grid_initialization(X, nu, 1.5)
    assert len(Z) < len(X)
    np.testing.assert_allclose(nuZ.sum(0), nu.sum(0))
    np.testing.assert_allclose((Z * nuZ.sum(1, keepdims=True)).sum(0), (X * nu.sum(1, keepdims=True)).sum(0))


def test_compress_reduces_error_and_keeps_mass():
    pytest.importorskip("torch")
    X, nu = _section()
    Z, nuZ, info = compress(X, nu, 1.5, outer_steps=5)
    assert info["count"] == len(Z) < len(X)
    assert info["final_squared_error"] < info["initial_squared_error"]
    assert abs(info["total_mass_deviation_percent"]) < 2.0
    assert np.all(nuZ >= 0) and info["sigma_mm"] == 1.5


def test_otsu_separability_bimodal_vs_unimodal():
    rng = np.random.default_rng(0)
    bimodal = np.concatenate([rng.normal(0.2, 0.02, 500), rng.normal(0.8, 0.02, 500)])
    assert otsu_separability(bimodal) > 0.95
    assert otsu_separability(rng.normal(0.5, 0.1, 1000)) < 0.75
    assert otsu_separability(np.ones(10)) == 0.0


def test_stripe_index_detects_periodic_scanner_stripes_only():
    px = 0.032
    yy, xx = np.mgrid[0:600, 0:700] * px
    mask = (xx - 11) ** 2 / 100 + (yy - 9.5) ** 2 / 64 < 1
    p_wm = ((xx > 9) & (xx < 14) & (yy > 6)).astype(float)  # a straight gray/white boundary
    clean = stripe_index(p_wm, mask, px)
    striped = stripe_index(np.clip(p_wm + 0.3 * np.sin(2 * np.pi * xx / 1.0), 0, 1), mask, px)
    assert clean["max"] < 0.1
    assert striped["columns"] > 0.3 and abs(striped["columns_period_mm"] - 1.0) < 0.05


def test_assign_role_names_each_failed_check():
    t = RoleThresholds(0.75, 0.3, 0.5, ("GFAP",))
    good = {"otsu_separability": 0.85, "stripe_index": 0.02, "layer1_mean_p_wm": 0.1}
    assert assign_role("NEUN", good, t) == ("anchor", [])
    role, reasons = assign_role("GFAP", {**good, "stripe_index": 0.7, "layer1_mean_p_wm": 0.8}, t)
    assert role == "passenger" and len(reasons) == 3
    assert assign_role("LFB", {**good, "layer1_mean_p_wm": None}, t)[0] == "anchor"


def test_noise_delta_window_and_escalation():
    ys = [float(y) for y in np.arange(-20, -9.9, 0.5)]
    base = {y: 0.1 + 0.01 * (y + 15) ** 2 for y in ys}
    profiles = {"A": base, "B": {y: v + 0.002 * (y == -15.5) for y, v in base.items()},
                "C": {y: v + 0.001 for y, v in base.items()}}
    noise = noise_delta(profiles, top=5)
    assert noise["delta"] is not None and noise["delta"] >= 0
    assert noise_delta({"A": base}, 5)["delta"] is None
    w = window(base, 0.01, 0.5)
    assert w["best_y"] == -15.0 and w["window_y"] == [-14.0, -16.0] and w["contiguous"]
    assert not w["flat"]
    nxt = escalation_ys([w], 0.5)
    assert max(nxt) == -13.5 and min(nxt) == -16.5


def test_distinct_minima_and_level_sigmas():
    assert distinct_minima([0, 3, 6, 9], [0.1, 0.2, 0.05, 0.3], 2, 6) == [6.0, 0.0]
    assert level_sigmas([2, 1, 0.5], 1.5) == [2.0, 1.0]
    assert level_sigmas([2, 1, 0.5], None) == [2.0, 1.0, 0.5]


def test_remove_border_bands_only_clears_full_lines():
    mask = np.zeros((60, 40), bool)
    mask[10:55, 5:30] = True
    banded = mask.copy()
    banded[-5:, :] = True
    out, removed = remove_border_bands(banded, 0.1, 1.0)
    assert removed == {"top": 0, "bottom": 5, "left": 0, "right": 0}
    np.testing.assert_array_equal(out, mask)
    untouched, none = remove_border_bands(mask, 0.1, 1.0)
    assert not any(none.values()) and np.array_equal(untouched, mask)


def test_search_depths_recovers_the_matching_depth():
    """The driver's per-depth fresh search ranks the depth whose atlas shape matches the section."""

    torch = pytest.importorskip("torch")
    from preprocess.qnp_stacking import make_scorer, search_depths
    from preprocess.section_alignment import Similarity2D

    def shape(depth):  # an L whose arm length changes with depth (1 mm grid, gray/white)
        X, nu = [], []
        for x in range(-8, 9):
            for y in range(-8, 9):
                arm = (abs(y) <= 2 and -8 <= x <= 8) or (abs(x) <= 2 and 0 <= y <= 2 + 2 * depth)
                if arm:
                    X.append((x, y))
                    nu.append((0.0, 1.0) if abs(x) <= 1 and abs(y) <= 1 else (1.0, 0.0))
        return np.asarray(X, float), np.asarray(nu, float)

    truth = Similarity2D(30.0, 1.0, False, (0.5, -0.3))
    P, mu = shape(2)
    section = truth.moving_to_section(P)
    scorer = make_scorer(section, mu, [2.0, 1.0])
    measures = [shape(d) for d in range(5)]
    results = search_depths(scorer, measures, {"theta_step_deg": 15, "scale_grid": [1.0], "scale_bounds": [0.9, 1.1],
                                               "fft_grid_mm": 1.0, "fft_blur_mm": 1.0, "refine_top": 2, "steps": 60})
    best = int(np.argmin([r[0][0] for r in results]))
    assert best == 2


# ---- placement comparison diagnostics -------------------------------------------------

def test_boundary_and_region_distances_on_a_plane_grid():
    from preprocess.qnp_stacking import boundary_distance_map, grid_lookup, region_distance_map

    res = 0.5
    axis = np.arange(-10, 10 + 1e-9, res)
    aa, bb = np.meshgrid(axis, axis, indexing="xy")
    disk = aa ** 2 + bb ** 2 <= 5.0 ** 2                      # 'brain' of radius 5 mm
    pts = np.array([[0.0, 0.0], [4.0, 0.0], [8.0, 0.0], [30.0, 0.0]])
    to_edge = grid_lookup(pts, boundary_distance_map(disk, res), axis, res)
    assert to_edge[0] == pytest.approx(5.0, abs=0.6) and to_edge[1] == pytest.approx(1.0, abs=0.6)
    assert to_edge[2] == pytest.approx(3.0, abs=0.6) and np.isnan(to_edge[3])   # outside the grid
    inside = grid_lookup(pts[:3], region_distance_map(disk, res), axis, res)
    assert inside[0] == 0 and inside[1] == 0 and inside[2] == pytest.approx(3.0, abs=0.6)


def test_gray_white_boundary_points_lie_on_the_split_not_the_tissue_edge():
    from preprocess.qnp_stacking import gray_white_boundary_points

    tissue = np.zeros((60, 80), bool)
    tissue[10:50, 10:70] = True
    p = np.where(np.arange(80)[None, :] >= 40, 0.9, 0.1) * np.ones((60, 1))   # white right of column 40
    pts = gray_white_boundary_points(p, tissue, origin_mm=(1.0, 2.0), px_mm=(0.1, 0.1), smooth_px=0.5)
    assert len(pts) > 0
    np.testing.assert_allclose(pts[:, 0], 1.0 + 40 * 0.1, atol=0.15)          # x = origin + col * px
    assert pts[:, 1].min() >= 2.0 + 10 * 0.1 - 1e-9 and pts[:, 1].max() <= 2.0 + 49 * 0.1 + 1e-9


def test_placement_status_separates_prior_from_data():
    from preprocess.qnp_stacking import placement_status

    assert placement_status(True, 5.0).startswith("prior inactive")
    assert placement_status(False, -0.2).startswith("image-supported")
    assert placement_status(False, 0.7).startswith("tie within delta")
    assert placement_status(False, 3.0).startswith("prior-driven")


def test_depth_inside_hull_separates_exposed_and_sulcal_pia():
    from preprocess.qnp_stacking import depth_inside_hull

    xs, ys = np.meshgrid(np.arange(0, 20.1, 0.5), np.arange(0, 10.1, 0.5))
    tissue = np.column_stack([xs.ravel(), ys.ravel()])
    pia = np.array([[10.0, 10.0], [10.0, 5.0], [0.0, 5.0]])      # top edge, centre, left edge
    d = depth_inside_hull(pia, tissue)
    np.testing.assert_allclose(d, [0.0, 5.0, 0.0], atol=1e-9)
