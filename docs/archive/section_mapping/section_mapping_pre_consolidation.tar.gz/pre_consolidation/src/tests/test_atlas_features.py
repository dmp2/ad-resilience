"""Canonical one-hot anatomical atlas features and their fixed projections.

    PYTHONPATH=src:src/config_setup:src/preprocess pytest -q src/tests/test_atlas_features.py
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import pytest

SRC = Path(__file__).resolve().parents[1]
REPO = SRC.parent
sys.path[:0] = [str(SRC), str(SRC / "config_setup"), str(SRC / "preprocess")]

from preprocess.atlas_features import (  # noqa: E402
    PROJECTIONS,
    anatomical_tables,
    check_gmwm_reproduces,
    label_channel_index,
    project,
    projection_matrix,
    projection_metadata,
)
from preprocess.particle_utils import FeatureDefinition, save_particle_archive  # noqa: E402
from preprocess.section_alignment import label_class_masses, lookup_tables  # noqa: E402

# Toy atlas codes: 1 STG, 2 MTG, 3 ITG, 4 FuG, 5 insula, 6 WM, 7 ventricle, 8 WM tract,
# 9 an unlisted gray code (like the unnamed AHRAv2 codes 32 and 248).
FINE = {"MTG": [2], "STG": [1], "ITG": [3], "FuG": [4]}
WM, DROP = [6, 8], [7]
NAMES = ["STG_gray_matter", "MTG_gray_matter", "ITG_gray_matter", "other_gray_matter", "white_matter"]


def toy_tables(max_label=9):
    return anatomical_tables(max_label, WM, DROP, FINE)


def test_channels_are_ordered_one_hot_and_keep_other_gray():
    tables = toy_tables()
    assert list(tables) == NAMES
    index = label_channel_index(tables)
    #                 0   1  2  3  4  5  6   7  8  9
    assert index.tolist() == [-1, 0, 1, 2, 3, 3, 4, -1, 4, 3]
    # FuG and the insula-like code 5 are kept, as other gray matter, not excluded.
    assert tables["other_gray_matter"][[4, 5]].all()


def test_region_codes_listed_as_white_stay_white():
    tables = anatomical_tables(9, [6, 8, 2], DROP, FINE)
    assert not tables["MTG_gray_matter"].any()
    assert tables["white_matter"][2]


def test_unknown_gray_region_is_an_error():
    with pytest.raises(KeyError):
        anatomical_tables(9, WM, DROP, FINE, gray_regions=("STG", "MTG", "TP"))


def test_projection_matrices():
    names, M = projection_matrix("gmwm", NAMES)
    assert names == ("gray_matter", "white_matter")
    assert M.tolist() == [[1, 1, 1, 1, 0], [0, 0, 0, 0, 1]]
    names, M = projection_matrix("mtg_gm", NAMES)
    assert names == ("MTG_gray_matter",) and M.tolist() == [[0, 1, 0, 0, 0]]
    names, M = projection_matrix("anatomical", NAMES)
    assert list(names) == NAMES and np.array_equal(M, np.eye(5))
    with pytest.raises(ValueError):
        projection_matrix("learned", NAMES)
    with pytest.raises(ValueError):
        projection_matrix("mtg_gm", [n for n in NAMES if n != "MTG_gray_matter"])
    assert set(projection_metadata(NAMES)) == set(PROJECTIONS)


def test_gmwm_projection_reproduces_original_tables():
    tables = toy_tables()
    coarse, _ = lookup_tables(9, WM, DROP, FINE)
    check_gmwm_reproduces(tables, coarse)
    broken = dict(tables)
    broken["white_matter"] = tables["white_matter"].copy()
    broken["white_matter"][6] = False
    with pytest.raises(ValueError):
        check_gmwm_reproduces(broken, coarse)


def test_plane_masses_project_to_the_original_features():
    rng = np.random.default_rng(0)
    grid = rng.integers(0, 10, size=(12, 12))
    axis = np.arange(12) * 0.5
    tables = toy_tables()
    coarse, fine = lookup_tables(9, WM, DROP, FINE)
    for aggregate in (1, 2, 3):
        X, nu_anat = label_class_masses(grid, axis, 0.5, tables, aggregate)
        Xc, nu_coarse = label_class_masses(grid, axis, 0.5, coarse, aggregate)
        Xf, nu_fine = label_class_masses(grid, axis, 0.5, fine, aggregate)
        assert np.array_equal(X, Xc) and np.array_equal(X, Xf)
        assert np.array_equal(project(nu_anat, projection_matrix("gmwm", NAMES)[1]), nu_coarse)
        assert np.array_equal(project(nu_anat, projection_matrix("mtg_gm", NAMES)[1]), nu_fine[:, [0]])
        assert np.array_equal(project(nu_anat, projection_matrix("anatomical", NAMES)[1]), nu_anat)
    # Pixel level: one-hot, and the argmax recovers each pixel's channel from the labels.
    X, nu = label_class_masses(grid, axis, 0.5, tables, 1)
    assert np.all((nu > 0).sum(1) == 1)
    expected = label_channel_index(tables)[grid.ravel()]
    assert np.array_equal(nu.argmax(1), expected[expected >= 0])


def test_archive_carries_anatomical_features(tmp_path):
    X = np.zeros((3, 3))
    nu_anat = np.array([[0.25, 0, 0, 0, 0], [0, 0, 0, 0.25, 0], [0, 0, 0, 0, 0.25]])
    nu_sub = project(nu_anat, projection_matrix("gmwm", NAMES)[1])
    features = FeatureDefinition((0, 1), ("gray_matter", "white_matter"), ("gray_matter", "white_matter"), (0, 1))
    path = tmp_path / "plane.npz"
    save_particle_archive(path, X, nu_sub, nu_sub, features, {"coordinate_space": "mni_icbm2009b_symmetric_plane"},
                          write_vtk=False, extra_arrays={"nu_Anat": nu_anat.astype(np.float32),
                                                         "anatomical_feature_names": np.asarray(NAMES)})
    with np.load(path) as archive:
        assert archive.files[:3] == ["X", "nu_Sub", "nu_All"]
        assert archive["anatomical_feature_names"].tolist() == NAMES
        assert np.array_equal(archive["nu_Anat"], nu_anat.astype(np.float32))
    with pytest.raises(ValueError):
        save_particle_archive(path, X, nu_sub, nu_sub, features, {}, write_vtk=False, extra_arrays={"nu_Sub": nu_sub})


def test_xiv_source_projection(tmp_path):
    pytest.importorskip("torch")
    pytest.importorskip("pykeops")
    from scripts.framework_script_AtlasToSectionCrossModalBoundary import project_source_features

    rng = np.random.default_rng(1)
    nu_anat = (rng.integers(0, 5, size=(20, 5)) * 0.25).astype(np.float32)
    nu_sub = project(nu_anat, projection_matrix("gmwm", NAMES)[1])
    path = tmp_path / "plane.npz"
    np.savez(path, nu_Anat=nu_anat, nu_Sub=nu_sub, anatomical_feature_names=np.asarray(NAMES))
    with np.load(path) as archive:
        nu, names = project_source_features(archive, "gmwm")
        assert names == ["gray_matter", "white_matter"] and np.array_equal(nu, nu_sub) and nu.dtype == np.float32
        nu, names = project_source_features(archive, "mtg_gm")
        assert names == ["MTG_gray_matter"] and np.array_equal(nu[:, 0], nu_anat[:, 1])
        nu, names = project_source_features(archive, "anatomical")
        assert names == NAMES and np.array_equal(nu, nu_anat)
    np.savez(path, nu_Anat=nu_anat, nu_Sub=nu_sub + 1, anatomical_feature_names=np.asarray(NAMES))
    with np.load(path) as archive, pytest.raises(ValueError):
        project_source_features(archive, "gmwm")


def test_xiv_load_inputs_projection_keeps_particles_with_mass(tmp_path):
    pytest.importorskip("torch")
    pytest.importorskip("pykeops")
    from scripts.framework_script_AtlasToSectionCrossModalBoundary import load_inputs

    # Pixel-level one-hot source: 2 MTG, 1 STG, 1 other gray, 2 white particles.
    nu_anat = np.zeros((6, 5), np.float32)
    nu_anat[[0, 1], 1] = nu_anat[2, 0] = nu_anat[3, 3] = nu_anat[[4, 5], 4] = 0.25
    S = np.column_stack([np.arange(6.0), np.zeros(6), np.zeros(6)])
    gmwm = projection_matrix("gmwm", NAMES)[1]
    np.savez(tmp_path / "source.npz", X=S, nu_Sub=project(nu_anat, gmwm), nu_Anat=nu_anat,
             anatomical_feature_names=np.asarray(NAMES), coarse_feature_names=np.asarray(["gray_matter", "white_matter"]),
             metadata_json=np.asarray(json.dumps({"coordinate_space": "mni_icbm2009b_symmetric_plane"})))
    np.savez(tmp_path / "target.npz", X=S[:3], nu_Sub=np.full((3, 2), 0.1, np.float32),
             coarse_feature_names=np.asarray(["gray_matter", "white_matter"]),
             metadata_json=np.asarray(json.dumps({"coordinate_space": "qnp_local_in_atlas_plane_mm"})))
    np.savez(tmp_path / "qc.npz", X=np.zeros((1, 3)), depth_from_pia_um=np.zeros(1))
    config = {"_project_root": str(tmp_path)}
    record = {"source_particles": "source.npz", "target_particles": "target.npz", "qc_strip_cells": "qc.npz",
              "target_coordinate_space": "qnp_local_in_atlas_plane_mm", "center_mode": "shared_target"}
    base = load_inputs(config, record)
    assert base["source_feature_projection"] is None and base["source_names"] == ["gray_matter", "white_matter"]
    same = load_inputs(config, {**record, "source_feature_projection": "gmwm"})
    assert np.array_equal(same["S"], base["S"]) and np.array_equal(same["nu_S"], base["nu_S"])
    full = load_inputs(config, {**record, "source_feature_projection": "anatomical"})
    assert np.array_equal(full["S"], base["S"]) and full["nu_S"].shape == (6, 5)
    mtg = load_inputs(config, {**record, "source_feature_projection": "mtg_gm"})
    assert mtg["source_names"] == ["MTG_gray_matter"]
    assert np.array_equal(mtg["S"], base["S"][[0, 1]]) and np.all(mtg["nu_S"] > 0)


ATLAS = REPO / "data/raw/allen/ahrav2/2025/ahrav2_gyral_annotations_500um.nii.gz"


@pytest.mark.skipif(not ATLAS.is_file(), reason="AHRAv2 gyral annotation not downloaded")
def test_real_atlas_channels_match_the_segmentation():
    pytest.importorskip("nibabel")
    from config_setup.project_config import load_config
    from config_setup.qnp_jobs import resolve_qnp_job
    from scripts.scan_atlas_planes_for_qnp import _anatomy_checks, atlas_setup

    config = load_config(REPO / "configs/project_config.yaml")
    scan = resolve_qnp_job(config, "H20.33.034_MTG")["atlas_scan"]
    atlas = atlas_setup(config, scan)  # raises if gmwm != the original gray/white tables
    assert list(atlas["anatomical"]) == NAMES
    checks = _anatomy_checks(atlas, scan, config)
    assert checks["unassigned_nonzero_voxels"] == 0
    assert checks["gmwm_projection_voxels_differing"] == 0
    for name, channel in checks["channels"].items():
        assert channel["voxels_differing"] == 0, name
        assert channel.get("allen_parcellation_voxels", channel["voxels"]) == channel["voxels"], name
    assert checks["channels"]["MTG_gray_matter"]["voxels"] == 415406  # Allen parcellation volume, code 30
    json.dumps(checks)
