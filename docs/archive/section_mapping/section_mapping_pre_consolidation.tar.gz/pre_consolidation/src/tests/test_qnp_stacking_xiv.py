"""Tests for preprocess/qnp_stacking_xiv.py: pose composition, the common score's frame consistency, annotation masses."""

import numpy as np
import pytest

from preprocess.qnp_stacking_xiv import (CommonScore, EvaluationSettings, SectionMeasure, compose,
                                         section_annotation_masses, section_frame_atlas, similarity_lsq)
from preprocess.section_alignment import Similarity2D


def _section(rng, n=150, annotated=True):
    X = rng.uniform(-8, 8, (n, 2))
    nu = np.column_stack([np.where(X[:, 1] > 0, 0.2, 0.05), np.where(X[:, 1] > 0, 0.05, 0.2)])
    ann = np.where((X[:, 0] > 0) & (X[:, 1] > 0), nu.sum(1), 0.0)[:, None] if annotated else None
    return SectionMeasure("TEST", X, nu, ann, {"status": "annotated" if annotated else "no_annotation"})


def test_similarity_lsq_recovers_a_rotation_scale_translation():
    rng = np.random.default_rng(0)
    P = rng.normal(size=(200, 2)) * 10
    angle = np.deg2rad(23.0)
    R = np.array([[np.cos(angle), -np.sin(angle)], [np.sin(angle), np.cos(angle)]])
    Q = 1.13 * P @ R.T + np.array([3.0, -2.0])
    fit = similarity_lsq(P, Q)
    assert fit["scale"] == pytest.approx(1.13, rel=1e-10)
    assert fit["rotation_deg"] == pytest.approx(23.0, abs=1e-8)
    assert np.allclose(fit["b"], [3.0, -2.0])


@pytest.mark.parametrize("flip", [False, True])
def test_compose_maps_section_points_onto_the_moved_atlas(flip):
    """start places the section at p = A0(q - tau0); the fit moves the atlas x -> cRx + b onto it."""

    rng = np.random.default_rng(1)
    t_init = Similarity2D(130.0, 1.09, flip, (15.0, 14.0))
    P = rng.normal(size=(100, 2)) * 10                      # atlas plane particles
    angle = np.deg2rad(-7.0)
    R = np.array([[np.cos(angle), -np.sin(angle)], [np.sin(angle), np.cos(angle)]])
    D = 0.92 * P @ R.T + np.array([1.5, 0.5])               # where the fit puts them (target-placed frame)
    q = t_init.moving_to_section(D)                         # the section points they now coincide with
    pose = compose(t_init, similarity_lsq(P, D))
    assert np.allclose(pose.section_to_moving(q), P, atol=1e-9)
    assert pose.scale == pytest.approx(1.09 / 0.92)
    assert pose.flip == flip


def test_common_score_is_zero_for_the_section_itself_and_frame_independent():
    """The same physical configuration reached from starts of different scale scores the same."""

    rng = np.random.default_rng(2)
    sec = _section(rng)
    score = CommonScore(sec, EvaluationSettings())
    results = []
    for scale in (0.9, 1.0, 1.25):
        pose = Similarity2D(40.0, scale, True, (1.0, -2.0))
        P = pose.section_to_moving(sec.X)                   # the atlas plane = the section, pushed into the plane
        nu_P, mtg_P = sec.nu * scale ** 2, sec.annotation * scale ** 2
        Y, (nu, mtg) = section_frame_atlas(pose, P, [nu_P, mtg_P])
        results.append(score.evaluate(Y, nu, mtg))
    for r in results:
        assert r["R_struct"] == pytest.approx(0.0, abs=1e-9)
        assert r["R_anat"] == pytest.approx(0.0, abs=1e-9)
        assert r["anat"]["atlas_self"] - r["anat"]["cross"] + 1 == pytest.approx(0.0, abs=1e-9)


def test_disjoint_atlas_mtg_scores_one_plus_its_self_term():
    rng = np.random.default_rng(3)
    sec = _section(rng)
    score = CommonScore(sec, EvaluationSettings())
    Y = sec.X + np.array([500.0, 0.0])                      # far away
    r = score.evaluate(Y, sec.nu, sec.annotation)
    assert r["anat"]["cross"] == pytest.approx(0.0, abs=1e-12)
    assert r["R_anat"] == pytest.approx(1.0 + r["anat"]["atlas_self"])
    assert r["R_struct"] == pytest.approx(1.0)              # nothing inside the footprint: atlas term 0


def test_unannotated_section_has_no_anatomical_score():
    rng = np.random.default_rng(4)
    sec = _section(rng, annotated=False)
    r = CommonScore(sec, EvaluationSettings()).evaluate(sec.X, sec.nu, sec.nu[:, :1])
    assert r["R_anat"] is None and r["R_combined"] is None and r["R_struct"] == pytest.approx(0.0, abs=1e-9)


def test_annotation_masses_lie_between_zero_and_tissue():
    rng = np.random.default_rng(5)
    px = (0.032, 0.032)
    mask = np.zeros((200, 200), bool)
    mask[20:180, 30:170] = True
    layers = np.zeros((200, 200), np.uint8)
    layers[20:100, 30:170] = 3
    centres = [(x, y) for y in np.arange(0.9, 5.8, 0.5) for x in np.arange(1.2, 5.5, 0.5)]
    X = np.column_stack([np.asarray(centres), np.zeros(len(centres))])
    nu = rng.uniform(0.1, 0.25, (len(X), 2))
    masses, record = section_annotation_masses({"mask": mask, "layers": layers, "px_mm": np.array(px)}, X, nu)
    tissue = nu.sum(1)
    assert np.all(masses[:, 0] >= 0) and np.all(masses[:, 0] <= tissue + 1e-12)
    upper = X[:, 1] < 100 * 0.032 - 0.3                     # well inside the annotated half
    lower = X[:, 1] > 100 * 0.032 + 0.3
    assert np.allclose(masses[upper, 0], tissue[upper]) and np.allclose(masses[lower, 0], 0.0)
    none, rec = section_annotation_masses({"mask": mask, "px_mm": np.array(px)}, X, nu)
    assert none is None and rec["status"] == "no_annotation"
