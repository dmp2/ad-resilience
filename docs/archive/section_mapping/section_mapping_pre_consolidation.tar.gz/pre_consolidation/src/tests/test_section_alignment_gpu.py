"""The batched torch score/search must reproduce the numpy section_alignment path (runs on CPU torch too)."""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pytest

torch = pytest.importorskip("torch")

SRC = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(SRC), str(SRC / "preprocess")]

from preprocess.section_alignment import FootprintScorer, Similarity2D, refine  # noqa: E402
from preprocess.section_alignment_gpu import (  # noqa: E402
    TorchFootprintScorer,
    fft_candidates_gpu,
    pad_measures,
    refine_batch,
    search_gpu,
    search_planes_gpu,
)

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")


def _section(seed: int = 0):
    """An asymmetric two-class 'section' on a 0.5 mm lattice (an L of gray around a white core)."""

    rng = np.random.default_rng(seed)
    a, b = np.meshgrid(np.arange(0, 14, 0.5), np.arange(0, 10, 0.5), indexing="xy")
    X = np.c_[a.ravel(), b.ravel()]
    keep = (X[:, 0] < 5) | (X[:, 1] < 4)
    X = X[keep]
    white = ((X[:, 0] > 1.5) & (X[:, 0] < 3.5)) | ((X[:, 1] > 1.0) & (X[:, 1] < 2.5))
    nu = np.c_[~white, white].astype(float) * 0.25 * (1 + 0.05 * rng.random(len(X)))[:, None]
    return X, nu


def test_gpu_score_matches_numpy_score():
    X, nu = _section()
    cpu = FootprintScorer(X, nu, (2.0, 1.0, 0.5))
    gpu = TorchFootprintScorer(cpu, device=DEVICE)
    truth = Similarity2D(30.0, 1.1, True, (2.0, -1.0))
    P = truth.section_to_moving(X)
    rng = np.random.default_rng(1)
    transforms = [truth] + [Similarity2D(float(rng.uniform(0, 360)), float(rng.uniform(0.8, 1.3)), bool(rng.integers(2)),
                                         tuple(rng.normal(0, 3, 2))) for _ in range(20)]
    mu = nu * truth.scale ** 2  # moving masses are in moving-frame mm^2
    expected = np.array([cpu.score_transform(t, P, mu) for t in transforms])
    got = gpu.score_transforms(transforms, P, mu)
    assert expected[0] < 1e-4
    np.testing.assert_allclose(got, expected, rtol=1e-4, atol=1e-6)


def test_padded_batch_scores_like_individual_measures():
    X, nu = _section()
    cpu = FootprintScorer(X, nu, (2.0, 1.0))
    gpu = TorchFootprintScorer(cpu, device=DEVICE)
    t = Similarity2D(10.0, 1.0, False, (0.5, 0.5))
    measures = [(t.section_to_moving(X), nu), (t.section_to_moving(X[::2]), nu[::2])]
    P, mu = pad_measures(measures)
    to = dict(device=DEVICE, dtype=torch.float32)
    th, tau, ls, fl = gpu._params([t, t])
    with torch.no_grad():
        got = gpu.score_params(torch.as_tensor(P, **to), torch.as_tensor(mu, **to), th, tau, ls, fl).cpu().numpy()
    expected = [cpu.score_transform(t, *m) for m in measures]
    np.testing.assert_allclose(got, expected, rtol=1e-4, atol=1e-6)


def test_fft_candidates_and_search_recover_a_known_pose():
    X, nu = _section()
    cpu = FootprintScorer(X, nu, (2.0, 1.0, 0.5))
    gpu = TorchFootprintScorer(cpu, device=DEVICE)
    truth = Similarity2D(90.0, 1.2, True, (1.0, 2.0))
    P, mu = truth.section_to_moving(X), nu * truth.scale ** 2
    grid = dict(thetas=np.arange(0, 360, 15.0), scales=[1.0, 1.2], flips=[False, True])
    best_value, best = fft_candidates_gpu(gpu, P, mu, h=0.5, blur_mm=1.0, **grid)[0]
    assert best.flip and abs((best.theta_deg - 90.0 + 180) % 360 - 180) < 1e-6 and best.scale == 1.2
    score, found = search_gpu(gpu, P, mu, scale_bounds=(0.8, 1.5), h=0.5, blur_mm=1.0, refine_top=2, steps=100, **grid)[0]
    assert score < 1e-3
    assert found.flip and abs((found.theta_deg - 90.0 + 180) % 360 - 180) < 0.5
    assert np.hypot(*np.subtract(found.tau, truth.tau)) < 0.1 and abs(found.scale - 1.2) < 0.01


def test_refine_batch_is_no_worse_than_its_start_and_matches_nelder_mead():
    X, nu = _section()
    cpu = FootprintScorer(X, nu, (2.0, 1.0, 0.5))
    gpu = TorchFootprintScorer(cpu, device=DEVICE)
    truth = Similarity2D(20.0, 1.0, False, (0.0, 0.0))
    P = truth.section_to_moving(X)
    start = Similarity2D(26.0, 1.0, False, (0.8, -0.6))
    nm_score, _ = refine(cpu, P, nu, start, (1.0, 1.0), 300)
    (score, t), = refine_batch(gpu, P, nu, [start], (1.0, 1.0), steps=150)
    assert score <= cpu.score_transform(start, P, nu)
    assert score <= nm_score + 1e-4
    assert abs(t.theta_deg - 20.0) < 0.5


def test_search_planes_gpu_refines_extra_starts_on_every_measure():
    X, nu = _section()
    cpu = FootprintScorer(X, nu, (2.0, 1.0))
    gpu = TorchFootprintScorer(cpu, device=DEVICE)
    truth = Similarity2D(0.0, 1.0, False, (0.0, 0.0))
    measures = [(truth.section_to_moving(X), nu), (truth.section_to_moving(X) + 0.3, nu)]
    out = search_planes_gpu(gpu, measures, thetas=[0.0, 180.0], scales=[1.0], flips=[False], scale_bounds=(1.0, 1.0),
                            h=0.5, blur_mm=1.0, refine_top=1, steps=50, extra_starts=[truth])
    assert len(out) == 2 and all(len(r) == 2 for r in out)
    assert out[0][0][0] < 1e-3 and out[1][0][0] < 1e-3
