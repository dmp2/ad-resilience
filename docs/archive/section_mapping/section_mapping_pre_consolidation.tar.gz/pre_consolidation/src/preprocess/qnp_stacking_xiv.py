"""Stacking coordinate of QNP sections by xIV similarity fits, with and without HALO MTG supervision.

Computations for ``src/scripts/estimate_qnp_stacking_xiv.py`` (docs/qnp_stacking_xiv_anatomical.md).
Nothing here changes the xIV objective: fits are built and run by the registration driver's own
``build_model`` / ``run_stages``.  This module provides

* the per-section target measures: each anchor's own 500 um gray/white particles in the donor's
  local QNP frame, and, where the slide's own HALO layer annotation fits its tissue, the
  positive-only annotated area per particle (unannotated tissue is unknown, mass 0);
* the atlas plane measures: a coronal plane's whole in-plane window as particles carrying gray/white
  and the one-hot anatomical channels (``preprocess/atlas_features.py``);
* the pose bookkeeping: the xIV similarity read off the shot atlas particles, composed with the
  start into one ``Similarity2D`` (QNP local -> atlas plane);
* the **common evaluation score**, computed after the fit in the fixed QNP local frame, so that every
  candidate of one section is compared with the *same* target measure (the native xIV loss is
  normalised per start and per plane; docs/qnp_loss_normalisation_audit.md).

Common score (all quantities in QNP local mm; atlas masses are pushed forward as areas, i.e. divided
by the composed scale^2, exactly as the rigid scan's ``FootprintScorer.score_transform``)::

    R_term = sum_s w_s |mu_A^term - mu_T^term|^2_s / |mu_T^term|^2_s  /  sum_s w_s,   w_s = 1 / sigma_s
    R      = lambda_struct R_struct + lambda_anat R_anat

* ``R_struct``: gray/white with the fixed identity correspondence; the atlas measure is weighted by the
  section's *fixed* footprint (``FootprintScorer.footprint``, as ``scores.json``), not by the model's
  min-max support (which is relative to the current atlas particles).
* ``R_anat``: atlas MTG gray (fixed ``mtg_gm`` projection) against the annotated tissue, uncensored
  (the censoring used by the supervised condition).  0 = annotation fully explained; a disjoint atlas
  MTG gives 1 + |mu_A^MTG|^2 / |mu_T|^2.
* Kernels: Gaussian exp(-d^2 / 2 sigma^2) with the objective's varifold widths, features linear.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping, Sequence

import numpy as np

ANNOTATION_FEATURE = "HALO_MTG_cortex_all_layers"
MTG_CHANNEL = "MTG_gray_matter"


# --------------------------------------------------------------------------------------
# Section measures
# --------------------------------------------------------------------------------------


def section_annotation_masses(maps: Mapping[str, np.ndarray], X_slide: np.ndarray, nu: np.ndarray,
                              ) -> tuple[np.ndarray | None, dict[str, Any]]:
    """Annotated tissue area (mm^2) per particle of one slide, from the slide's own HALO layers.

    ``maps`` is the slide's ``*_maps_32um.npz`` (``mask``, ``layers``, ``px_mm``; slide frame, rows =
    y); ``X_slide`` / ``nu`` its 500 um particles in the slide frame.  The particles were binned at
    full resolution, which the 32 um maps cannot reproduce exactly, so each 32 um tissue pixel is
    given to its nearest particle and a particle's annotated mass is

        (annotated tissue pixels / tissue pixels assigned to it) x the particle's exact tissue mass,

    which lies in [0, tissue mass] by construction.  Returns ``(None, record)`` without layers.
    """

    from scipy.spatial import cKDTree

    if "layers" not in maps:
        return None, {"status": "no_annotation", "rule": "the slide has no HALO layer raster fitting its tissue"}
    mask = np.asarray(maps["mask"], bool)
    ribbon = np.asarray(maps["layers"]) > 0
    px = np.asarray(maps["px_mm"], float)  # (row, col) = (y, x) pixel size
    rows, cols = np.nonzero(mask)
    centres = np.column_stack([(cols + 0.5) * px[1], (rows + 0.5) * px[0]])
    tree = cKDTree(np.asarray(X_slide, float)[:, :2])
    distance, owner = tree.query(centres)
    n = len(X_slide)
    tissue_px = np.bincount(owner, minlength=n).astype(float)
    annotated_px = np.bincount(owner, weights=ribbon[rows, cols].astype(float), minlength=n)
    fraction = np.divide(annotated_px, tissue_px, out=np.zeros(n), where=tissue_px > 0)
    tissue = np.asarray(nu, float).sum(1)
    annotated = (fraction * tissue)[:, None]
    pixel_area = float(px[0] * px[1])
    record = {
        "status": "annotated", "feature": ANNOTATION_FEATURE,
        "rule": "the slide's own HALO layers (union L1..L5-6) on its own tissue; per particle: annotated share of "
                "the 32 um tissue pixels nearest to it x its exact tissue mass; unannotated tissue is unknown (0)",
        "ribbon_on_tissue_area_mm2_32um": float((ribbon & mask).sum() * pixel_area),
        "annotated_tissue_area_mm2": float(annotated.sum()),
        "tissue_area_mm2": float(tissue.sum()),
        "annotated_tissue_fraction": float(annotated.sum() / tissue.sum()),
        "particles_with_annotation": int((annotated[:, 0] > 0).sum()), "particles": int(n),
        "pixel_to_particle_distance_mm_p99": float(np.percentile(distance, 99)),
        "mass_units": "mm^2 (QNP slide area; rigid slide -> local transform keeps it)",
    }
    return annotated, record


@dataclass
class SectionMeasure:
    """One QNP section in the donor's local frame (the fixed target of every candidate)."""

    stain: str
    X: np.ndarray                 # (N, 2) local mm
    nu: np.ndarray                # (N, 2) gray, white area mm^2
    annotation: np.ndarray | None  # (N, 1) annotated area mm^2, or None
    annotation_record: dict

    @property
    def annotated(self) -> bool:
        return self.annotation is not None and bool(np.any(self.annotation > 0))


# --------------------------------------------------------------------------------------
# Atlas plane measures (whole window)
# --------------------------------------------------------------------------------------


def atlas_plane(atlas: Mapping, scan: Mapping, y: float, bin_mm: float) -> dict[str, Any]:
    """Coronal plane at y: particles of the whole ``half_width_mm`` window at ``bin_mm``.

    Gray/white (``coarse``) and one-hot anatomical masses (``anatomical``) come from the same
    nearest-neighbour reslice and aggregation, so positions coincide; the gmwm projection of the
    anatomical masses equals the gray/white masses (checked).
    """

    from preprocess.atlas_features import project, projection_matrix
    from preprocess.section_alignment import label_class_masses, plane_basis, reslice_labels

    spacing = float(scan["reslice_mm"])
    aggregate = int(round(float(bin_mm) / spacing))
    if abs(aggregate * spacing - float(bin_mm)) > 1e-9:
        raise ValueError(f"atlas_bin_mm {bin_mm} is not a multiple of reslice_mm {spacing}")
    u, v, n = plane_basis(0.0, 0.0)
    origin = np.array([atlas["centroid"][0], float(y), atlas["centroid"][2]])
    grid, axis = reslice_labels(atlas["labels"], atlas["affine"], origin, u, v, float(scan["half_width_mm"]), spacing)
    P, nu_gmwm = label_class_masses(grid, axis, spacing, atlas["coarse"], aggregate)
    P2, nu_anat = label_class_masses(grid, axis, spacing, atlas["anatomical"], aggregate)
    names = list(atlas["anatomical"])
    if not np.array_equal(P, P2) or not np.array_equal(project(nu_anat, projection_matrix("gmwm", names)[1]), nu_gmwm):
        raise RuntimeError("anatomical plane particles do not reproduce the gray/white particles")
    return {"y_mm": float(y), "X": P[:, :2].astype(np.float64), "nu": nu_gmwm, "nu_anat": nu_anat,
            "anat_names": names, "mtg": nu_anat[:, names.index(MTG_CHANNEL)][:, None],
            "origin": origin, "u": u, "v": v, "normal": n, "bin_mm": float(bin_mm),
            "plane_meta": {"origin_mm": origin.tolist(), "u_axis": u.tolist(), "v_axis": v.tolist(),
                           "normal": n.tolist(), "pitch_deg": 0.0, "yaw_deg": 0.0, "y0_mm": float(y),
                           "plane_id": f"p+000_w+000_y{float(y):+06.1f}",
                           "inverse": "world = origin + plane_X[:, 0] * u_axis + plane_X[:, 1] * v_axis"}}


# --------------------------------------------------------------------------------------
# Poses
# --------------------------------------------------------------------------------------


def similarity_lsq(P0: np.ndarray, P1: np.ndarray, w: np.ndarray | None = None) -> dict[str, Any]:
    """Weighted least-squares P1 ~ c R P0 + b (rotation only: the flow cannot reflect)."""

    w = np.ones(len(P0)) if w is None else np.asarray(w, float).ravel()
    w = w / w.sum()
    m0, m1 = w @ P0, w @ P1
    A0, A1 = P0 - m0, P1 - m1
    H = (A0 * w[:, None]).T @ A1
    U, S, Vt = np.linalg.svd(H)
    d = np.sign(np.linalg.det(Vt.T @ U.T))
    D = np.diag([1.0, d])
    R = Vt.T @ D @ U.T
    var0 = float((w * (A0 ** 2).sum(1)).sum())
    c = float((S * np.diag(D)).sum() / var0)
    b = m1 - c * R @ m0
    residual = np.sqrt(((P1 - (c * P0 @ R.T + b)) ** 2).sum(1))
    return {"scale": c, "rotation_deg": float(np.degrees(np.arctan2(R[1, 0], R[0, 0]))), "R": R, "b": b,
            "residual_mm": {"p50": float(np.percentile(residual, 50)), "max": float(residual.max())}}


def compose(t_init, fit: Mapping[str, Any]):
    """The fitted pose as one ``Similarity2D`` (QNP local -> atlas plane).

    The start places the section at p = A0 (q - tau0); the fit moves the atlas x -> c R x + b onto
    it.  So q = A0^-1 (c R x + b) + tau0, i.e. x = A (q - tau) with A = (c R)^-1 A0 and
    tau = tau0 + A0^-1 b.
    """

    from preprocess.section_alignment import Similarity2D

    A0 = t_init.matrix
    tau = np.asarray(t_init.tau, float) + np.linalg.solve(A0, fit["b"])
    return Similarity2D((t_init.theta_deg - fit["rotation_deg"]) % 360.0, t_init.scale / fit["scale"], t_init.flip,
                        (float(tau[0]), float(tau[1])))


def pose_distance(a, b, X: np.ndarray) -> float:
    """Median displacement (mm, section frame) between two poses applied to section points X."""

    return float(np.median(np.linalg.norm(a.section_to_moving(X) - b.section_to_moving(X), axis=1)))


def distinct_poses(ranked: Sequence, k: int, min_shift_mm: float, min_angle_deg: float) -> list:
    """The first k (score, Similarity2D) that differ in flip, translation or rotation (scan rule)."""

    from preprocess.section_alignment import _distinct

    return _distinct(list(ranked), int(k), min_shift_mm, min_angle_deg)


# --------------------------------------------------------------------------------------
# Common evaluation score (fixed QNP local frame)
# --------------------------------------------------------------------------------------


def gauss_inners(X: np.ndarray, a: np.ndarray, Y: np.ndarray, b: np.ndarray, sigmas: Sequence[float]) -> np.ndarray:
    """<mu_X, mu_Y>_sigma = sum_ij exp(-|x_i - y_j|^2 / 2 sigma^2) <a_i, b_j>, for every sigma (float64)."""

    if len(X) == 0 or len(Y) == 0:
        return np.zeros(len(sigmas))
    out = np.zeros(len(sigmas))
    feature = np.asarray(a, float) @ np.asarray(b, float).T
    keep_rows = np.abs(feature).sum(1) > 0
    X, Y_, F = np.asarray(X, float)[keep_rows], np.asarray(Y, float), feature[keep_rows]
    for start in range(0, len(X), 2048):
        d2 = ((X[start:start + 2048, None, :] - Y_[None, :, :]) ** 2).sum(-1)
        f = F[start:start + 2048]
        for k, s in enumerate(sigmas):
            out[k] += float((np.exp(-d2 / (2.0 * s * s)) * f).sum())
    return out


@dataclass
class EvaluationSettings:
    sigmas_mm: tuple[float, ...] = (8.0, 4.0, 2.0, 1.0)
    footprint_sigma_mm: float = 0.5
    lambda_struct: float = 1.0
    lambda_anat: float = 1.0

    @classmethod
    def from_config(cls, block: Mapping[str, Any]) -> "EvaluationSettings":
        if str(block.get("sigma_weights", "inverse")) != "inverse":
            raise ValueError("evaluation.sigma_weights: only 'inverse' (1/sigma) is implemented")
        return cls(tuple(float(s) for s in block.get("sigmas_mm", (8.0, 4.0, 2.0, 1.0))),
                   float(block.get("footprint_sigma_mm", 0.5)), float(block.get("lambda_struct", 1.0)),
                   float(block.get("lambda_anat", 1.0)))

    @property
    def weights(self) -> np.ndarray:
        w = 1.0 / np.asarray(self.sigmas_mm)
        return w / w.sum()


class CommonScore:
    """Post-fit score of atlas poses against one section, in the section's fixed local frame."""

    def __init__(self, section: SectionMeasure, settings: EvaluationSettings):
        from preprocess.section_alignment import FootprintScorer

        self.section, self.settings = section, settings
        self.footprint = FootprintScorer(section.X, section.nu, [1.0], footprint_sigma_mm=settings.footprint_sigma_mm)
        s = settings.sigmas_mm
        self.target_self_struct = gauss_inners(section.X, section.nu, section.X, section.nu, s)
        self.target_self_anat = (gauss_inners(section.X, section.annotation, section.X, section.annotation, s)
                                 if section.annotated else None)

    def _relative(self, aa, ab, bb) -> dict[str, Any]:
        w = self.settings.weights
        per_sigma = (aa + bb - 2.0 * ab) / bb
        return {"R": float(w @ per_sigma), "per_sigma": per_sigma.tolist(),
                "atlas_self": float(w @ (aa / bb)), "target_self": 1.0, "cross": float(w @ (2.0 * ab / bb))}

    def evaluate(self, Y: np.ndarray, nu_gmwm: np.ndarray, nu_mtg: np.ndarray) -> dict[str, Any]:
        """``Y``: atlas particles in the section frame (mm); masses already pushed forward (mm^2)."""

        s, sec = self.settings.sigmas_mm, self.section
        weight = self.footprint.footprint(Y)[:, None]
        cut = weight[:, 0] > 1e-3
        Ys, mus = Y[cut], (nu_gmwm * weight)[cut]
        struct = self._relative(gauss_inners(Ys, mus, Ys, mus, s), gauss_inners(Ys, mus, sec.X, sec.nu, s),
                                self.target_self_struct)
        out: dict[str, Any] = {
            "R_struct": struct["R"], "struct": struct,
            "atlas_area_in_footprint_mm2": float((nu_gmwm * weight).sum()),
            "atlas_mtg_mass_mm2": float(nu_mtg.sum()),
            "atlas_mtg_mass_in_footprint_mm2": float((nu_mtg * weight).sum()),
            "section_area_mm2": float(sec.nu.sum()),
        }
        if sec.annotated:
            anat = self._relative(gauss_inners(Y, nu_mtg, Y, nu_mtg, s), gauss_inners(Y, nu_mtg, sec.X, sec.annotation, s),
                                  self.target_self_anat)
            out.update(R_anat=anat["R"], anat=anat, annotated_area_mm2=float(sec.annotation.sum()),
                       R_combined=self.settings.lambda_struct * struct["R"] + self.settings.lambda_anat * anat["R"])
        else:
            out.update(R_anat=None, anat=None, annotated_area_mm2=None, R_combined=None)
        return out


def section_frame_atlas(pose, P_plane: np.ndarray, masses: Sequence[np.ndarray]) -> tuple[np.ndarray, list[np.ndarray]]:
    """Atlas plane particles carried to the section frame by ``pose`` (QNP -> plane), areas pushed forward."""

    return pose.moving_to_section(P_plane), [np.asarray(m, float) / pose.scale ** 2 for m in masses]


# --------------------------------------------------------------------------------------
# Landing (where target tissue falls on the atlas labels; QC)
# --------------------------------------------------------------------------------------


def landing(plane: Mapping[str, Any], atlas: Mapping, pose, X_section: np.ndarray, masses: np.ndarray,
            channel_tables: Mapping[str, np.ndarray]) -> dict[str, float]:
    """Mass fractions of section particles landing on each anatomical channel (nearest 0.5 mm voxel).

    ``outside`` = label 0 (no tissue) or a dropped code (ventricle ...).
    """

    P = pose.section_to_moving(X_section)
    world = plane["origin"] + P[:, :1] * plane["u"] + P[:, 1:2] * plane["v"]
    labels, affine = atlas["labels"], atlas["affine"]
    ijk = np.rint((world - affine[:3, 3]) @ np.linalg.inv(affine[:3, :3]).T).astype(int)
    inside = np.all((ijk >= 0) & (ijk < np.array(labels.shape)), axis=1)
    codes = np.zeros(len(world), int)
    codes[inside] = labels[tuple(ijk[inside].T)]
    names = list(channel_tables)
    index = np.full(len(world), len(names))
    for k, name in enumerate(names):
        table = channel_tables[name]
        valid = codes < len(table)
        member = np.zeros(len(world), bool)
        member[valid] = table[codes[valid]]
        index[member] = k
    m = np.asarray(masses, float).ravel()
    total = m.sum()
    return {n: float(m[index == k].sum() / total) if total > 0 else 0.0 for k, n in enumerate([*names, "outside"])}
