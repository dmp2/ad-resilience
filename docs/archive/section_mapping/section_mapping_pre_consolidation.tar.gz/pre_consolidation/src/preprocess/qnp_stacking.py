"""Stacking coordinate of QNP sections in a 3-D atlas: compression, roles, slabs, depth profiles.

Implements steps 1-7 of the ``section-to-template-mapping`` skill for one donor's sections,
with no donor-specific values: everything comes from the resolved job
(``config_setup.qnp_jobs.resolve_qnp_job``) and its ``atlas_scan.stacking`` block.  The
stages that read and write files live in ``src/scripts/scan_atlas_planes_for_qnp.py``
(``--stage roles|compress|slabs|profile|passengers|stack-report``); this module holds the
computations, so they can be tested on tiny synthetic inputs.

Roles: template (moving) = atlas plane, target (fixed) = the QNP section, as in the rigid
scan.  A coronal plane's stacking coordinate is its MNI y.  Scores are the footprint-
restricted multi-scale varifold score (0 = identical); lower is better.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Iterable, Mapping, Sequence

import numpy as np
from scipy import ndimage as ndi

# --------------------------------------------------------------------------------------
# Compression (joint positions + masses)
# --------------------------------------------------------------------------------------


def grid_initialization(X: np.ndarray, nu: np.ndarray, h_mm: float) -> tuple[np.ndarray, np.ndarray]:
    """Particles summed into h-mm blocks: mass-weighted centroid, summed per-feature masses."""

    X = np.asarray(X, float)[:, :2]
    nu = np.asarray(nu, float)
    keys = np.floor((X - X.min(0)) / float(h_mm)).astype(np.int64)
    _, index = np.unique(keys, axis=0, return_inverse=True)
    index = index.ravel()
    groups = index.max() + 1
    mass = nu.sum(1)
    weight = np.bincount(index, mass, groups)
    centre = np.column_stack([np.bincount(index, mass * X[:, k], groups) for k in range(2)])
    plain = np.column_stack([np.bincount(index, X[:, k], groups) for k in range(2)]) / np.bincount(index, None, groups)[:, None]
    centre = np.where(weight[:, None] > 0, centre / np.maximum(weight, 1e-300)[:, None], plain)
    masses = np.column_stack([np.bincount(index, nu[:, c], groups) for c in range(nu.shape[1])])
    keep = masses.sum(1) > 0
    return centre[keep], masses[keep]


def compression_sigma(h_mm: float) -> float:
    """Kernel width of the joint compression: sigma = max(1, h) mm (kernel exp(-d^2/sigma^2))."""

    return max(1.0, float(h_mm))


def compress(X: np.ndarray, nu: np.ndarray, h_mm: float, *, outer_steps: int = 30,
             max_pairs: int = 16_000_000) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    """Jointly optimised positions and masses at spacing ~h (``optimize_particles``), planar XY.

    Returns (Z[:, :2], nu_Z, info).  CPU float64, as validated in the particle-approximation
    pilot; the pair guard is ``max_pairs`` (one float64 N x N matrix of 4000 particles is 128 MB).
    """

    from preprocess.particle_approximation import optimize_particles, varifold_squared
    import torch

    X2 = np.asarray(X, float)[:, :2]
    nu = np.asarray(nu, float)
    Z0, nu0 = grid_initialization(X2, nu, h_mm)
    sigma = compression_sigma(h_mm)
    pad = lambda P: np.column_stack([P, np.zeros(len(P))])
    result = optimize_particles(pad(X2), nu, pad(Z0), nu0, sigma_mm=sigma, optimize_positions=True,
                                outer_steps=int(outer_steps), max_pairs=int(max_pairs))
    with torch.no_grad():
        err = lambda P, m: float(varifold_squared(*[torch.tensor(v, dtype=torch.float64)
                                                     for v in (pad(X2), nu, pad(P), m)], sigma))
        initial, final = err(Z0, nu0), err(result.X[:, :2], result.nu)
    info = {"h_mm": float(h_mm), "sigma_mm": sigma, "kernel": "exp(-d^2/sigma^2)", "count": int(len(Z0)),
            "reference_count": int(len(X2)), "initialization": "h-mm block sums (mass-weighted centroids)",
            "outer_steps": int(outer_steps), "seconds": result.seconds,
            "initial_squared_error": initial, "final_squared_error": final,
            "relative_error_final": final / max(result.reference_self_norm, 1e-300),
            "total_mass": float(result.nu.sum()), "reference_total_mass": float(nu.sum()),
            "total_mass_deviation_percent": float(100 * (result.nu.sum() - nu.sum()) / nu.sum()),
            "compression_method": "image_varifold", "backend": "particle_approximation.optimize_particles (CPU float64)"}
    return result.X[:, :2], result.nu, info


# --------------------------------------------------------------------------------------
# Feature QC -> roles
# --------------------------------------------------------------------------------------


def otsu_separability(values: np.ndarray, bins: int = 256) -> float:
    """Otsu's eta: between-class / total variance at the optimal threshold (0..1)."""

    values = np.asarray(values, float)
    values = values[np.isfinite(values)]
    if values.size < 2 or values.std() == 0:
        return 0.0
    hist, edges = np.histogram(values, bins=bins)
    p = hist / hist.sum()
    centres = (edges[:-1] + edges[1:]) / 2
    w0 = np.cumsum(p)
    mu0 = np.cumsum(p * centres)
    mu_t = mu0[-1]
    w1 = 1 - w0
    with np.errstate(divide="ignore", invalid="ignore"):
        between = (mu_t * w0 - mu0) ** 2 / (w0 * w1)
    between = np.nan_to_num(between[:-1])
    total = float((p * (centres - mu_t) ** 2).sum())
    return float(between.max() / total) if total > 0 else 0.0


def stripe_index(p_wm: np.ndarray, mask: np.ndarray, px_mm: float, detrend_mm: float = 1.0,
                 period_mm: tuple[float, float] = (0.4, 1.5), min_line_fraction: float = 0.2) -> dict[str, Any]:
    """Periodic scanner-stripe energy in the gray/white map, along image columns and rows.

    Scanner stripes are periodic bands aligned with the image axes (1.0 mm apart on the
    SEA-AD Aperio scans).  After removing structure larger than ``detrend_mm`` (normalised
    Gaussian smoothing inside tissue), the residual is averaged along each column (row);
    the index is the share of that profile's spectral power in the strongest peak (+-1 bin)
    at periods in ``period_mm``.  Gray/white boundaries give broad spectra and long-period
    peaks (excluded by the band), stripes a sharp short-period peak.
    """

    mask = np.asarray(mask, bool)
    p = np.where(mask, np.asarray(p_wm, float), 0.0)
    sigma = detrend_mm / px_mm
    smooth = ndi.gaussian_filter(p, sigma) / np.maximum(ndi.gaussian_filter(mask.astype(float), sigma), 1e-6)
    residual = np.where(mask, p - smooth, 0.0)
    out: dict[str, Any] = {}
    for name, axis in (("columns", 0), ("rows", 1)):
        count = mask.sum(axis)
        lines = count >= min_line_fraction * max(count.max(), 1)
        if lines.sum() < 8:
            out[name], out[f"{name}_period_mm"] = 0.0, None
            continue
        profile = np.where(lines, residual.sum(axis) / np.maximum(count, 1), 0.0)
        profile = np.where(lines, profile - profile[lines].mean(), 0.0)
        power = np.abs(np.fft.rfft(profile * np.hanning(len(profile)))) ** 2
        freq = np.fft.rfftfreq(len(profile), d=px_mm)
        band = (freq >= 1 / period_mm[1]) & (freq <= 1 / period_mm[0])
        total = power[freq > 0].sum()
        if not band.any() or total <= 0:
            out[name], out[f"{name}_period_mm"] = 0.0, None
            continue
        k = int(np.argmax(np.where(band, power, 0.0)))
        out[name] = float(power[max(k - 1, 0):k + 2].sum() / total)
        out[f"{name}_period_mm"] = float(1 / freq[k])
    out["max"] = max(out["columns"], out["rows"])
    return out


@dataclass
class RoleThresholds:
    otsu_separability_min: float = 0.75
    stripe_index_max: float = 0.15
    layer1_p_wm_max: float = 0.5
    glial_stains: tuple[str, ...] = ("GFAP",)

    @classmethod
    def from_config(cls, roles: Mapping[str, Any]) -> "RoleThresholds":
        return cls(float(roles.get("otsu_separability_min", 0.75)), float(roles.get("stripe_index_max", 0.15)),
                   float(roles.get("layer1_p_wm_max", 0.5)), tuple(roles.get("glial_stains", ("GFAP",))))


def assign_role(stain: str, metrics: Mapping[str, Any], thresholds: RoleThresholds) -> tuple[str, list[str]]:
    """Anchor when every check passes; otherwise passenger, with the failed checks named."""

    reasons = []
    if metrics["otsu_separability"] < thresholds.otsu_separability_min:
        reasons.append(f"Otsu separability {metrics['otsu_separability']:.2f} < {thresholds.otsu_separability_min}")
    if metrics["stripe_index"] > thresholds.stripe_index_max:
        reasons.append(f"stripe index {metrics['stripe_index']:.2f} > {thresholds.stripe_index_max}")
    l1 = metrics.get("layer1_mean_p_wm")
    if l1 is not None and l1 > thresholds.layer1_p_wm_max:
        reasons.append(f"layer 1 read as white matter (mean p(WM) {l1:.2f} > {thresholds.layer1_p_wm_max})")
    if stain in thresholds.glial_stains:
        reasons.append("glial stain")
    return ("passenger" if reasons else "anchor"), reasons


# --------------------------------------------------------------------------------------
# Atlas measures on coronal planes and slabs
# --------------------------------------------------------------------------------------


def _grid_masses(atlas: Mapping, scan: Mapping, y: float, spacing: float, aggregate: int, table: str = "coarse"):
    """Full-grid (unfiltered) class masses of the coronal plane at y: (X[n, 2], nu[n, C])."""

    from preprocess.section_alignment import plane_basis, reslice_labels

    u, v, _ = plane_basis(0.0, 0.0)
    origin = np.array([atlas["centroid"][0], float(y), atlas["centroid"][2]])
    grid, axis = reslice_labels(atlas["labels"], atlas["affine"], origin, u, v, float(scan["half_width_mm"]), spacing)
    n = (len(axis) // aggregate) * aggregate
    grid = grid[:n, :n]
    masses = []
    for lookup in atlas[table].values():
        member = lookup[np.clip(grid, 0, len(lookup) - 1)] & (grid < len(lookup))
        masses.append(member.reshape(n // aggregate, aggregate, n // aggregate, aggregate).sum((1, 3)))
    nu = np.stack(masses, -1).reshape(-1, len(atlas[table])).astype(np.float64) * spacing ** 2
    centres = axis[:n].reshape(-1, aggregate).mean(1)
    aa, bb = np.meshgrid(centres, centres, indexing="xy")
    return np.column_stack([aa.ravel(), bb.ravel()]), nu


def _prior_mask(atlas: Mapping, scan: Mapping, y: float, spacing: float, aggregate: int,
                prior: Mapping[str, Any]) -> np.ndarray:
    """Grid cells within ``margin_mm`` of the prior's atlas regions (dissection-region prior)."""

    _, fine = _grid_masses(atlas, scan, y, spacing, aggregate, table="fine")
    names = list(atlas["fine"])
    present = fine[:, [names.index(r) for r in prior["regions"]]].sum(1) > 0
    side = int(round(np.sqrt(len(present))))
    grid = present.reshape(side, side)
    cell = spacing * aggregate
    distance = ndi.distance_transform_edt(~grid) * cell
    return (distance <= float(prior.get("margin_mm", 6.0))).ravel()


def plane_measure(atlas: Mapping, scan: Mapping, y: float, prior: Mapping[str, Any] | None = None):
    """Coronal plane at y as atlas particles (``scan_bin_mm``), gray/white area masses.

    ``prior`` ({regions, margin_mm}) keeps only atlas cells within margin_mm of those fine
    regions: an explicit dissection-region prior (the section can only be placed there).
    """

    spacing = float(scan["reslice_mm"])
    aggregate = int(round(float(scan["scan_bin_mm"]) / spacing))
    X, nu = _grid_masses(atlas, scan, y, spacing, aggregate)
    keep = nu.sum(1) > 0
    if prior:
        keep &= _prior_mask(atlas, scan, y, spacing, aggregate, prior)
    return X[keep], nu[keep]


def slab_measure(atlas: Mapping, scan: Mapping, y_centre: float, half_thickness_mm: float,
                 plane_step_mm: float, prior: Mapping[str, Any] | None = None) -> tuple[np.ndarray, np.ndarray]:
    """Mean class masses over the parallel coronal planes y_centre +- half_thickness."""

    spacing = float(scan["reslice_mm"])
    aggregate = int(round(float(scan["scan_bin_mm"]) / spacing))
    ys = np.arange(y_centre - half_thickness_mm, y_centre + half_thickness_mm + 1e-9, plane_step_mm)
    total, X, inside = None, None, None
    for y in ys:
        X, nu = _grid_masses(atlas, scan, y, spacing, aggregate)
        total = nu if total is None else total + nu
        if prior:
            m = _prior_mask(atlas, scan, y, spacing, aggregate, prior)
            inside = m if inside is None else inside | m
    total = total / len(ys)
    keep = total.sum(1) > 0
    if prior:
        keep &= inside
    return X[keep], total[keep]


def region_y_extent(atlas: Mapping) -> tuple[float, float]:
    return tuple(float(v) for v in atlas["region_extent_y"])


# --------------------------------------------------------------------------------------
# GPU search over many depths
# --------------------------------------------------------------------------------------


def level_sigmas(sigmas: Sequence[float], h_mm: float | None) -> list[float]:
    """Score SDs for particles at spacing h: drop SDs < h/2 (skill default)."""

    kept = [float(s) for s in sigmas if h_mm is None or float(s) >= float(h_mm) / 2]
    return kept or [max(float(s) for s in sigmas)]


def make_scorer(X: np.ndarray, nu: np.ndarray, sigmas: Sequence[float]):
    from preprocess.section_alignment import FootprintScorer
    from preprocess.section_alignment_gpu import TorchFootprintScorer

    return TorchFootprintScorer(FootprintScorer(np.asarray(X, float)[:, :2], np.asarray(nu, float), list(sigmas)))


def search_depths(scorer, measures: Sequence[tuple[np.ndarray, np.ndarray]], search: Mapping[str, Any], *,
                  flips: Sequence[bool] | None = None, extra_starts: Sequence = (), chunk: int = 8,
                  min_particles: int = 10):
    """Fresh global 2-D search (FFT candidates over rotations x scales x flips, then batched
    refinement) at every measure; returns per measure (score, Similarity2D) best first."""

    from preprocess.section_alignment_gpu import search_planes_gpu

    out = []
    kwargs = dict(thetas=np.arange(0, 360, float(search.get("theta_step_deg", 15))),
                  scales=[float(s) for s in search.get("scale_grid", (0.9, 1.05, 1.2, 1.35))],
                  flips=list(search.get("flips", (False, True)) if flips is None else flips),
                  scale_bounds=tuple(float(s) for s in search.get("scale_bounds", (0.8, 1.5))),
                  h=float(search.get("fft_grid_mm", 1.0)), blur_mm=float(search.get("fft_blur_mm", 1.5)),
                  refine_top=int(search.get("refine_top", 4)), steps=int(search.get("steps", 150)))
    from preprocess.section_alignment import Similarity2D

    extra = [t for t in extra_starts if t.flip in kwargs["flips"]]
    # Planes with (almost) no atlas tissue, e.g. outside a region prior, score 1 (no overlap),
    # as empty planes do in the coarse scan.
    usable = [k for k, (P, _) in enumerate(measures) if len(P) >= min_particles]
    found: dict[int, list] = {}
    for start in range(0, len(usable), chunk):
        batch = usable[start:start + chunk]
        for k, ranked in zip(batch, search_planes_gpu(scorer, [measures[k] for k in batch], extra_starts=extra, **kwargs)):
            found[k] = ranked
    empty = [(1.0, Similarity2D(0.0, 1.0, False, (0.0, 0.0)))]
    return [found.get(k, empty) for k in range(len(measures))]


# --------------------------------------------------------------------------------------
# Profiles, noise scale and windows
# --------------------------------------------------------------------------------------


def distinct_minima(ys: Sequence[float], scores: Sequence[float], keep: int, min_separation_mm: float) -> list[float]:
    """The ``keep`` best ys, greedily, at least ``min_separation_mm`` apart."""

    chosen: list[float] = []
    for k in np.argsort(scores):
        if all(abs(ys[k] - c) >= min_separation_mm for c in chosen):
            chosen.append(float(ys[k]))
        if len(chosen) == keep:
            break
    return chosen


def noise_delta(profiles: Mapping[str, Mapping[float, float]], top: int = 20) -> dict[str, Any]:
    """delta: median over the best planes of the across-anchor SD of each anchor's score
    relative to its own best (planes ranked by the mean relative score; population SD).

    ``profiles``: anchor -> {y: score}, on a shared set of ys.  Needs >= 2 anchors.
    """

    anchors = list(profiles)
    if len(anchors) < 2:
        return {"delta": None, "reason": "fewer than 2 anchors: no across-anchor noise scale"}
    ys = sorted(set.intersection(*[set(p) for p in profiles.values()]))
    rel = {a: np.array([profiles[a][y] - min(profiles[a].values()) for y in ys]) for a in anchors}
    stack = np.vstack([rel[a] for a in anchors])
    order = np.argsort(stack.mean(0))[: max(1, min(int(top), len(ys)))]
    sds = stack[:, order].std(0)
    return {"delta": float(np.median(sds)), "planes_used": [float(ys[k]) for k in order],
            "definition": "median over the planes with the lowest mean relative score of the population SD "
                          "across anchors of (anchor score - that anchor's best score)"}


def window(profile: Mapping[float, float], delta: float, step_mm: float) -> dict[str, Any]:
    """All ys within delta of the best; the window, its contiguity and the best y."""

    ys = np.array(sorted(profile))
    scores = np.array([profile[y] for y in ys])
    best = int(np.argmin(scores))
    inside = ys[scores <= scores[best] + delta]
    gaps = np.diff(np.sort(inside))
    return {"best_y": float(ys[best]), "best_score": float(scores[best]),
            "window_y": [float(inside.max()), float(inside.min())],
            "width_mm": float(inside.max() - inside.min()),
            "contiguous": bool(np.all(gaps <= step_mm + 1e-6)), "planes_within_delta": int(len(inside)),
            "contrast_median_minus_best": float(np.median(scores) - scores[best]),
            "flat": bool(np.median(scores) - scores[best] <= 2 * delta)}


def escalation_ys(windows: Iterable[Mapping[str, Any]], step_mm: float, pad_steps: int = 1) -> list[float]:
    """Depths for the next level: the union of the previous windows, padded by one step."""

    ys = set()
    for w in windows:
        hi, lo = w["window_y"]
        for y in np.arange(lo - pad_steps * step_mm, hi + pad_steps * step_mm + 1e-9, step_mm):
            ys.add(round(float(y), 3))
    return sorted(ys, reverse=True)


# --------------------------------------------------------------------------------------
# Boundary correspondence and support diagnostics (placement comparison; no fitting)
# --------------------------------------------------------------------------------------


def grid_lookup(points: np.ndarray, values: np.ndarray, axis: np.ndarray, res: float) -> np.ndarray:
    """Nearest-pixel values of a square plane grid (grid[b, a], ``axis`` for both) at points (a, b);
    NaN outside the grid."""

    ia = np.rint((points[:, 0] - axis[0]) / res).astype(int)
    ib = np.rint((points[:, 1] - axis[0]) / res).astype(int)
    ok = (ia >= 0) & (ia < values.shape[1]) & (ib >= 0) & (ib < values.shape[0])
    out = np.full(len(points), np.nan)
    out[ok] = values[ib[ok], ia[ok]]
    return out


def boundary_distance_map(mask: np.ndarray, res: float) -> np.ndarray:
    """Distance (mm) from every pixel to the nearest boundary pixel of ``mask`` (inner edge)."""

    mask = np.asarray(mask, bool)
    edge = mask & ~ndi.binary_erosion(mask)
    if not edge.any():
        return np.full(mask.shape, np.inf)
    return ndi.distance_transform_edt(~edge) * float(res)


def region_distance_map(mask: np.ndarray, res: float) -> np.ndarray:
    """Distance (mm) to the nearest pixel of ``mask`` (0 inside)."""

    mask = np.asarray(mask, bool)
    if not mask.any():
        return np.full(mask.shape, np.inf)
    return ndi.distance_transform_edt(~mask) * float(res)


def gray_white_boundary_points(p_wm: np.ndarray, tissue: np.ndarray, origin_mm, px_mm, smooth_px: float = 2.0,
                               max_points: int = 4000) -> np.ndarray:
    """Local-frame points on a section's gray/white boundary (p(WM) = 0.5 inside the tissue).

    Pixels on the white side that touch gray tissue, after smoothing p(WM) within the tissue
    (normalised convolution); the tissue edge itself is excluded.  x = origin_x + col * px_x,
    y = origin_y + row * px_y (the multistain-map convention).
    """

    tissue = np.asarray(tissue, bool)
    p = np.where(tissue, np.asarray(p_wm, float), 0.0)
    w = ndi.gaussian_filter(tissue.astype(float), smooth_px)
    p = np.where(tissue, ndi.gaussian_filter(p, smooth_px) / np.maximum(w, 1e-6), 0.0)
    white = tissue & (p > 0.5)
    gray = tissue & (p <= 0.5)
    rows, cols = np.nonzero(white & ndi.binary_dilation(gray))
    if len(rows) > max_points:
        keep = np.linspace(0, len(rows) - 1, max_points).astype(int)
        rows, cols = rows[keep], cols[keep]
    origin, px = np.asarray(origin_mm, float), np.asarray(px_mm, float)
    return np.column_stack([origin[0] + cols * px[1], origin[1] + rows * px[0]])


def depth_inside_hull(points: np.ndarray, outline_points: np.ndarray) -> np.ndarray:
    """Distance (mm) of each point to the boundary of the convex hull of ``outline_points``.

    For pia points (which lie on the tissue): far from the hull = lining a sulcus; near it =
    the exposed surface."""

    from scipy.spatial import ConvexHull

    hull = outline_points[ConvexHull(outline_points).vertices]
    a, b = hull, np.roll(hull, -1, axis=0)
    ab = b - a
    t = np.clip(((points[:, None, :] - a[None]) * ab[None]).sum(-1) / np.maximum((ab ** 2).sum(-1), 1e-12), 0, 1)
    nearest = a[None] + t[..., None] * ab[None]
    return np.linalg.norm(points[:, None, :] - nearest, axis=-1).min(1)


def distance_summary(d: np.ndarray) -> dict[str, float | int | None]:
    d = np.asarray(d, float)
    d = d[np.isfinite(d)]
    if not len(d):
        return {"p50_mm": None, "p90_mm": None, "points": 0}
    return {"p50_mm": float(np.median(d)), "p90_mm": float(np.percentile(d, 90)), "points": int(len(d))}


def placement_status(same_placement: bool, gap_in_delta: float | None) -> str:
    """How the admissible placement relates to the data-only optimum (lower score = better).

    ``gap_in_delta`` = (data-only score of the admissible placement - data-only score of the
    unconstrained best) / delta.
    """

    if same_placement:
        return "prior inactive: the admissible and unconstrained best placements coincide"
    if gap_in_delta is None:
        return "unresolved: no noise scale"
    if gap_in_delta <= 0:
        return "image-supported: the admissible placement fits at least as well (data only)"
    if gap_in_delta <= 1:
        return "tie within delta: the image does not discriminate; the prior selects"
    return f"prior-driven: the data prefer the excluded placement by {gap_in_delta:.1f} delta"


# --------------------------------------------------------------------------------------
# Section rasters on the atlas plane (QC figures)
# --------------------------------------------------------------------------------------


def splat(points: np.ndarray, weights: np.ndarray, xs: np.ndarray, zs: np.ndarray, res: float,
          sigma_px: float = 1.0) -> np.ndarray:
    H = np.zeros((len(zs), len(xs)))
    ix = np.rint((points[:, 0] - xs[0]) / res).astype(int)
    iz = np.rint((points[:, 1] - zs[0]) / res).astype(int)
    ok = (ix >= 0) & (ix < len(xs)) & (iz >= 0) & (iz < len(zs))
    np.add.at(H, (iz[ok], ix[ok]), weights[ok])
    return ndi.gaussian_filter(H, sigma_px)
