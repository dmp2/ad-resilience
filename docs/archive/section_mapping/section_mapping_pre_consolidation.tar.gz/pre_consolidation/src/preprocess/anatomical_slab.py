"""Anatomical slab prior on a section's stacking coordinate (SEA-AD tissue-slab sampling).

Three concepts are kept apart:

1. a *tissue slab*: a nominal ``thickness`` coronal slab of the dissection protocol, whose
   cutting phase relative to the atlas is unknown;
2. the atlas *sampling region* inside it (e.g. MTG/STG gray matter): display and QC only;
3. the actual QNP block: never constructed here; its position is what registration estimates.

Coordinates.  Atlas world coordinates are NIfTI/MNI RAS mm, so +y is anterior regardless of
the voxel-index direction (the affine maps voxels to world; nothing here reads index order).
The posterior coordinate used for slabbing is ``s = -y``: it increases posteriorly, the
direction of SEA-AD slabbing (anterior to posterior).

Landmark.  ``locate_landmark`` returns the first meaningful appearance of an atlas label
moving anterior -> posterior: the most anterior coronal plane whose label cross-section is at
least ``min_area_mm2`` (one hemisphere).  A manual ``y_mm`` replaces the label rule.

Slabs.  With landmark ``s_L``, thickness ``h``, phase ``delta`` in [0, h) and offset ``j``::

    S_j(delta) = [s_L - delta + j h,  s_L - delta + (j + 1) h]

``j = 0`` is the landmark-containing slab, ``j = -1 / +1`` its anterior / posterior
neighbours.  Over all phases, ``S_j`` covers (s_L + (j-1)h, s_L + (j+1)h]; the search interval
is the union over the chosen offsets, widened by ``extension_mm`` on both sides.

ROI-specific values (label codes, thickness, offsets, extension) come from the caller's
config (``atlas_scan.stacking.landmark_slab``); nothing here is specific to MTG or LGN.
"""

from __future__ import annotations

from typing import Any, Mapping, Sequence

import numpy as np

AP_CONVENTION = ("atlas world mm, NIfTI/MNI RAS (+y anterior); slab coordinate s = -y "
                 "(increases posteriorly, the slabbing direction)")


def posterior_mm(y_mm):
    """Slab coordinate s (posterior-increasing) of an atlas world y (anterior-increasing)."""

    return -np.asarray(y_mm, float)


def world_y_mm(s_mm):
    return -np.asarray(s_mm, float)


# --------------------------------------------------------------------------------------
# Landmark
# --------------------------------------------------------------------------------------


def label_coronal_profile(labels: np.ndarray, affine: np.ndarray, codes: Sequence[int],
                          hemisphere: str | None = None, plane_step_mm: float | None = None) -> dict[str, Any]:
    """Cross-sectional area (mm^2) of the label set per coronal plane, in world y.

    Voxel centres are binned by world y into planes ``plane_step_mm`` apart on the voxel
    lattice (default: the voxel spacing along world y); area = voxels x voxel volume / step.
    ``hemisphere`` ('left' / 'right') keeps world x < 0 / > 0.
    """

    affine = np.asarray(affine, float)
    ijk = np.argwhere(np.isin(labels, np.asarray(codes, int)))
    if not len(ijk):
        return {"y_mm": np.zeros(0), "area_mm2": np.zeros(0), "world": np.zeros((0, 3)), "step_mm": None}
    world = ijk @ affine[:3, :3].T + affine[:3, 3]
    if hemisphere is not None:
        world = world[np.sign(world[:, 0]) == (-1.0 if hemisphere == "left" else 1.0)]
    # World-y spacing between adjacent voxel planes: the largest |dy| of one index step.
    step = float(plane_step_mm or np.abs(affine[1, :3]).max())
    origin = float(affine[1, 3])
    plane = np.round((world[:, 1] - origin) / step).astype(np.int64)
    keys, counts = np.unique(plane, return_counts=True)
    voxel_volume = abs(float(np.linalg.det(affine[:3, :3])))
    return {"y_mm": origin + keys * step, "area_mm2": counts * voxel_volume / step,
            "world": world, "plane_index": plane, "keys": keys, "step_mm": step}


def locate_landmark(labels: np.ndarray, affine: np.ndarray, spec: Mapping[str, Any],
                    hemisphere: str | None = None) -> dict[str, Any]:
    """The landmark plane from ``spec``: manual ``y_mm``, or the label's first appearance.

    ``spec``: {name, codes, rule: "first_appearance", min_area_mm2, [y_mm]}.  Returns world y,
    slab coordinate s, how it was obtained, the area profile (most anterior first) and the
    centroid of the landmark cross-section on that plane (for figures).
    """

    name = spec.get("name", "landmark")
    profile = (label_coronal_profile(labels, affine, spec["codes"], hemisphere)
               if spec.get("codes") else None)
    rows = []
    if profile is not None and len(profile["y_mm"]):
        order = np.argsort(-profile["y_mm"])  # anterior -> posterior
        rows = [[float(profile["y_mm"][k]), float(profile["area_mm2"][k])] for k in order]
    if spec.get("y_mm") is not None:
        y = float(spec["y_mm"])
        out = {"name": name, "y_mm": y, "s_mm": float(posterior_mm(y)), "method": "manual (landmark.y_mm)",
               "codes": list(spec.get("codes", [])), "hemisphere": hemisphere}
        if rows:
            out["label_first_appearance_y_mm_for_comparison"] = rows[0][0]
        out["profile_y_area_mm2"] = rows
        out["centroid_mm"] = None
        return out
    rule = spec.get("rule", "first_appearance")
    if rule != "first_appearance":
        raise NotImplementedError(f"landmark rule {rule!r}: only 'first_appearance' or a manual y_mm")
    if not rows:
        raise ValueError(f"{name}: label codes {list(spec.get('codes', []))} are absent from the atlas "
                         f"({hemisphere or 'both'} hemisphere); set landmark.y_mm manually")
    min_area = float(spec.get("min_area_mm2", 1.0))
    first = next((r for r in rows if r[1] >= min_area), None)
    if first is None:
        raise ValueError(f"{name}: no coronal plane reaches {min_area} mm^2")
    y = first[0]
    key = profile["keys"][np.argmin(np.abs(profile["y_mm"] - y))]
    centroid = profile["world"][profile["plane_index"] == key].mean(0)
    return {"name": name, "y_mm": y, "s_mm": float(posterior_mm(y)),
            "method": f"first appearance of atlas label(s) {list(spec['codes'])} moving anterior -> posterior: "
                      f"most anterior coronal plane with cross-section >= {min_area} mm^2",
            "codes": list(spec["codes"]), "hemisphere": hemisphere, "min_area_mm2": min_area,
            "first_any_voxel_y_mm": rows[0][0], "area_at_landmark_mm2": first[1],
            "precision_mm": profile["step_mm"], "centroid_mm": centroid.tolist(),
            "profile_y_area_mm2": rows}


# --------------------------------------------------------------------------------------
# Slabs
# --------------------------------------------------------------------------------------


def phases(thickness_mm: float, step_mm: float) -> np.ndarray:
    """delta in [0, h) on a step grid (the unknown cutting phase)."""

    return np.round(np.arange(0.0, float(thickness_mm) - 1e-9, float(step_mm)), 6)


def slab_bounds(s_landmark: float, thickness_mm: float, j: int, delta_mm: float) -> tuple[float, float]:
    """[s0, s1] of S_j(delta)."""

    s0 = float(s_landmark) - float(delta_mm) + int(j) * float(thickness_mm)
    return s0, s0 + float(thickness_mm)


def candidate_slabs(s_landmark: float, thickness_mm: float, offsets: Sequence[int], phase_step_mm: float) -> list[dict]:
    """Every S_j(delta): offset, phase, s bounds and world-y bounds [anterior, posterior]."""

    out = []
    for j in offsets:
        for delta in phases(thickness_mm, phase_step_mm):
            s0, s1 = slab_bounds(s_landmark, thickness_mm, j, delta)
            out.append({"j": int(j), "delta_mm": float(delta), "s_mm": [s0, s1],
                        "y_mm": [float(world_y_mm(s0)), float(world_y_mm(s1))]})
    return out


def offset_cover(s_landmark: float, thickness_mm: float, j: int) -> tuple[float, float]:
    """s range covered by S_j over all phases: (s_L + (j-1)h, s_L + (j+1)h]."""

    h = float(thickness_mm)
    return float(s_landmark) + (int(j) - 1) * h, float(s_landmark) + (int(j) + 1) * h


def search_interval(s_landmark: float, thickness_mm: float, offsets: Sequence[int],
                    extension_mm: float = 0.0) -> dict[str, list[float]]:
    """Union of the candidate slabs over all phases and offsets, widened by ``extension_mm``."""

    lo = offset_cover(s_landmark, thickness_mm, min(offsets))[0] - float(extension_mm)
    hi = offset_cover(s_landmark, thickness_mm, max(offsets))[1] + float(extension_mm)
    return {"s_mm": [lo, hi], "y_mm": [float(world_y_mm(lo)), float(world_y_mm(hi))]}


def build_slab_prior(landmark: Mapping[str, Any], cfg: Mapping[str, Any]) -> dict[str, Any]:
    """Landmark + candidate slabs + search interval: the JSON-ready record."""

    h = float(cfg.get("slab_thickness_mm", 4.0))
    offsets = [int(j) for j in cfg.get("slab_offsets", (-1, 0, 1))]
    step = float(cfg.get("phase_step_mm", 0.5))
    ext = float(cfg.get("extension_mm", 0.0))
    s_L = float(landmark["s_mm"])
    return {"ap_convention": AP_CONVENTION, "landmark": dict(landmark), "slab_thickness_mm": h,
            "slab_offsets": offsets, "phase_step_mm": step, "extension_mm": ext,
            "slab_formula": "S_j(delta) = [s_L - delta + j h, s_L - delta + (j+1) h], 0 <= delta < h",
            "offset_cover_y_mm": {str(j): [float(world_y_mm(v)) for v in offset_cover(s_L, h, j)] for j in offsets},
            "search_interval": search_interval(s_L, h, offsets, ext),
            "candidates": candidate_slabs(s_L, h, offsets, step)}


def clamp_ys(ys: Sequence[float], interval_y: Sequence[float], tol: float = 1e-6) -> list[float]:
    """Planes inside the search interval ([anterior y, posterior y])."""

    hi, lo = max(interval_y), min(interval_y)
    return [y for y in ys if lo - tol <= y <= hi + tol]


def slab_consistency(profile: Mapping[float, float], candidates: Sequence[Mapping[str, Any]],
                     delta_noise: float | None) -> dict[str, Any]:
    """Best profile score inside each candidate slab and the slabs within ``delta_noise`` of the best.

    ``profile``: {y: score} of one section (lower is better).  A plane on a shared boundary
    belongs to both slabs (closed intervals): at atlas resolution it cannot be assigned.
    """

    ys = np.array(sorted(profile), float)
    scores = np.array([profile[y] for y in ys])
    rows = []
    for c in candidates:
        lo, hi = min(c["y_mm"]), max(c["y_mm"])
        inside = (ys >= lo - 1e-6) & (ys <= hi + 1e-6)
        if not inside.any():
            continue
        k = np.flatnonzero(inside)[np.argmin(scores[inside])]
        rows.append({"j": c["j"], "delta_mm": c["delta_mm"], "best_y_mm": float(ys[k]), "best_score": float(scores[k]),
                     "planes_scored": int(inside.sum())})
    if not rows:
        return {"slabs": [], "consistent": {}}
    best = min(r["best_score"] for r in rows)
    tol = 0.0 if delta_noise is None else float(delta_noise)
    consistent: dict[str, list[float]] = {}
    for r in rows:
        r["within_delta"] = bool(r["best_score"] <= best + tol + 1e-12)
        if r["within_delta"]:
            consistent.setdefault(str(r["j"]), []).append(r["delta_mm"])
    return {"slabs": rows, "consistent": {j: [min(d), max(d)] for j, d in consistent.items()},
            "rule": "candidate slabs whose best plane scores within delta of the best slab"}
