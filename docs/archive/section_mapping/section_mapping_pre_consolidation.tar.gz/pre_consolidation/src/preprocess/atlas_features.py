"""Canonical one-hot anatomical atlas features and their fixed projections.

Representation
==============
Every AHRAv2 label code is assigned to at most one *anatomical channel*, in this order:

    STG_gray_matter, MTG_gray_matter, ITG_gray_matter, other_gray_matter, white_matter

(the gray regions are configurable, ``atlas_scan.anatomical_features.gray_regions``,
naming entries of ``atlas_scan.fine_regions``).  The partition is the one
``section_alignment.lookup_tables`` already defines for the plane scan: gray matter is
every non-zero code that is neither white matter nor dropped (ventricles, choroid
plexus); a named region keeps only its gray codes; ``other_gray_matter`` is all
remaining gray, insula, opercula, fusiform, superior-temporal-plane gyri and deep gray
included; ``white_matter`` is the configured white-matter code list (one shared channel).
Dropped codes and background belong to no channel.

A particle's anatomical masses are the areas (mm^2) of each channel's pixels inside it,
so for a pixel-level plane the vectors are one-hot and their sum is the tissue area.

Projections
===========
A projection is a fixed 0/1 matrix ``M`` [C_out, C_anat]; projected masses are
``nu @ M.T``.  Nothing is learned.

``gmwm``        gray_matter = sum of every gray channel, white_matter = white_matter.
                Reproduces the original two-channel atlas features exactly (the default).
``mtg_gm``      MTG_gray_matter alone (one channel).
``anatomical``  identity (all five channels).

Matching a projected atlas measure to a target with another feature space (e.g. 5 atlas
channels vs QNP gray/white) is the job of the registration's own cross-modal model
(xIV ``pi_ST``); this module does not choose or fit that correspondence.
"""

from __future__ import annotations

from typing import Mapping, Sequence

import numpy as np

from preprocess.section_alignment import lookup_tables

DEFAULT_GRAY_REGIONS = ("STG", "MTG", "ITG")
OTHER_GRAY = "other_gray_matter"
WHITE = "white_matter"
GMWM_NAMES = ("gray_matter", "white_matter")
PROJECTIONS = ("gmwm", "mtg_gm", "anatomical")
DEFAULT_PROJECTION = "gmwm"


def channel_name(region: str) -> str:
    return f"{region}_gray_matter"


def anatomical_tables(max_label: int, white_matter: Sequence[int], drop: Sequence[int],
                      fine_regions: Mapping[str, Sequence[int]],
                      gray_regions: Sequence[str] = DEFAULT_GRAY_REGIONS) -> dict[str, np.ndarray]:
    """Ordered boolean lookup tables (label value -> member) for the anatomical channels.

    ``fine_regions`` maps region names to codes (as in ``atlas_scan.fine_regions``);
    only ``gray_regions`` become their own channels, every other fine region is part of
    ``other_gray_matter``.  Built with ``lookup_tables`` so the gray/white/dropped rule is
    the one the plane scan uses.
    """

    missing = [r for r in gray_regions if r not in fine_regions]
    if missing:
        raise KeyError(f"anatomical gray regions {missing} are not in fine_regions {list(fine_regions)}")
    _, fine = lookup_tables(max_label, white_matter, drop, {r: fine_regions[r] for r in gray_regions})
    tables = {channel_name(r): fine[r] for r in gray_regions}
    tables[OTHER_GRAY] = fine[OTHER_GRAY]
    tables[WHITE] = fine[WHITE]
    check_partition(tables)
    return tables


def check_partition(tables: Mapping[str, np.ndarray]) -> None:
    """Every label value belongs to at most one channel (one-hot)."""

    counts = np.sum([np.asarray(t, bool) for t in tables.values()], axis=0)
    overlap = np.flatnonzero(counts > 1)
    if overlap.size:
        raise ValueError(f"label codes in more than one anatomical channel: {overlap[:20].tolist()}")


def label_channel_index(tables: Mapping[str, np.ndarray]) -> np.ndarray:
    """Label value -> channel index (-1: background or dropped)."""

    index = np.full(len(next(iter(tables.values()))), -1, np.int16)
    for k, table in enumerate(tables.values()):
        index[np.asarray(table, bool)] = k
    return index


def projection_matrix(name: str, channel_names: Sequence[str]) -> tuple[tuple[str, ...], np.ndarray]:
    """``(output_names, M)`` with ``M`` [C_out, C_in] for a named fixed projection."""

    names = list(channel_names)
    if name not in PROJECTIONS:
        raise ValueError(f"unknown feature projection {name!r}; choose one of {PROJECTIONS}")
    if WHITE not in names:
        raise ValueError(f"anatomical channels {names} have no {WHITE!r}")
    if name == "anatomical":
        return tuple(names), np.eye(len(names))
    if name == "gmwm":
        M = np.zeros((2, len(names)))
        M[0, [k for k, n in enumerate(names) if n != WHITE]] = 1.0
        M[1, names.index(WHITE)] = 1.0
        return GMWM_NAMES, M
    target = channel_name("MTG")
    if target not in names:
        raise ValueError(f"projection 'mtg_gm' needs a {target!r} channel; channels are {names}")
    M = np.zeros((1, len(names)))
    M[0, names.index(target)] = 1.0
    return (target,), M


def project(nu: np.ndarray, matrix: np.ndarray) -> np.ndarray:
    """Projected masses ``nu @ M.T`` (keeps the input dtype)."""

    nu = np.asarray(nu)
    return nu @ np.asarray(matrix, dtype=nu.dtype).T


def projected_tables(tables: Mapping[str, np.ndarray], name: str) -> dict[str, np.ndarray]:
    """Label-level projection: the boolean table of each projected channel."""

    out_names, M = projection_matrix(name, list(tables))
    stacked = np.stack([np.asarray(t, bool) for t in tables.values()])
    return {n: (row[:, None] * stacked).sum(0) > 0 for n, row in zip(out_names, M)}


def check_gmwm_reproduces(tables: Mapping[str, np.ndarray], coarse: Mapping[str, np.ndarray]) -> None:
    """The ``gmwm`` projection equals the original gray/white tables code for code."""

    projected = projected_tables(tables, "gmwm")
    if list(projected) != list(coarse):
        raise ValueError(f"gmwm channels {list(projected)} != original {list(coarse)}")
    for name in coarse:
        differ = np.flatnonzero(projected[name] != np.asarray(coarse[name], bool))
        if differ.size:
            raise ValueError(f"gmwm projection differs from the original {name} table at codes {differ[:20].tolist()}")


def projection_metadata(channel_names: Sequence[str]) -> dict[str, dict]:
    """JSON-ready record of every projection for archive metadata."""

    out = {}
    for name in PROJECTIONS:
        names, M = projection_matrix(name, channel_names)
        out[name] = {"output_names": list(names), "matrix": M.astype(int).tolist()}
    return out
