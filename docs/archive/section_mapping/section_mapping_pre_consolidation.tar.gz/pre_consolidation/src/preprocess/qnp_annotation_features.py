"""Positive-only HALO cortical annotations as masses on the QNP consensus particles.

Scientific role
===============
The NeuN slide's HALO layer polygons mark MTG cortex (layers 1 to 5-6).  For the xIV
anatomical term they are *positive-only* evidence: annotated tissue is MTG gray matter,
while unannotated tissue is **unknown**, not "not MTG" (annotation is incomplete: on
H20.33.034 the ribbon covers about half of the consensus tissue).  The per-particle
feature is therefore one mass: the area of annotated tissue in the particle.  Unannotated
tissue contributes 0 here, and the xIV term censors the atlas to the annotated region.
Nothing marks unannotated tissue as negative.

Source of the mask
==================
``align_qnp_multistain.py`` writes ``multistain_maps_32um_local.npz`` with
``consensus_mask`` (the consensus tissue) and ``reference_ribbon`` (the union of the
reference stain's HALO layers, resampled onto the same 32 um grid by the reference
stain's own transform, i.e. none).  Annotated tissue = ``consensus_mask & reference_ribbon``:
ribbon pixels off the consensus tissue are not evidence about tissue and are dropped
(their area is reported).

The masses come from the same block aggregation as the consensus particles
(``qnp_particles.tissue_class_particles`` with the ribbon as a 0/1 value), so positions
and particle order are identical by construction.  This is checked, not assumed:
:func:`annotated_tissue_masses` refuses a target whose positions or tissue masses
differ.

All annotated layers are combined into one feature (``ANNOTATION_FEATURE``).  Per-layer
features would need the layer index resampled onto the consensus grid; the saved maps
carry only the union.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np

from preprocess.qnp_particles import tissue_class_particles

ANNOTATION_FEATURE = "HALO_MTG_cortex_all_layers"
NO_ANNOTATION = "no_annotation"


def annotated_tissue_masses(maps_file: str | Path, target_X: np.ndarray, target_nu: np.ndarray,
                            downsample_factor: int) -> tuple[np.ndarray | None, dict[str, Any]]:
    """Annotated tissue area (mm^2, QNP local frame) for each consensus particle.

    ``target_X`` / ``target_nu`` are the consensus particles in the local frame (as
    written by ``align_qnp_multistain.py``) and ``downsample_factor`` is their block size
    in 32 um map pixels (``metadata["particles"]["downsample_factor"]``).

    Returns ``(masses, record)``: ``masses`` is (N, 1) float64 with
    0 <= masses <= tissue area per particle, or ``None`` when the maps carry no annotation
    (``record["status"] == NO_ANNOTATION``).
    """

    with np.load(maps_file, allow_pickle=False) as maps:
        if "reference_ribbon" not in maps.files or not maps["reference_ribbon"].any():
            return None, {"status": NO_ANNOTATION, "maps": str(maps_file),
                          "rule": "the reference stain has no HALO layer annotation on the consensus grid"}
        mask = maps["consensus_mask"].astype(bool)
        ribbon = maps["reference_ribbon"].astype(bool)
        px = tuple(float(v) for v in maps["px_mm"])
        origin = np.asarray(maps["origin_mm"], dtype=np.float64)

    bin_mm = int(downsample_factor) * float(np.mean(px))
    X, nu, _ = tissue_class_particles(px, mask, ribbon.astype(np.float64), bin_mm)
    X = X + np.array([origin[0], origin[1], 0.0], dtype=np.float32)
    if X.shape != target_X.shape or not np.array_equal(X, np.asarray(target_X, dtype=np.float32)):
        raise ValueError("annotation particles do not reproduce the target positions; were the consensus particles "
                         f"built from {maps_file} with downsample factor {downsample_factor}?")
    tissue = np.asarray(target_nu, dtype=np.float64).sum(axis=1)
    rebuilt = nu.astype(np.float64).sum(axis=1)
    if not np.allclose(rebuilt, tissue, rtol=1e-5, atol=1e-9):
        raise ValueError("annotation particles do not reproduce the target tissue masses (max |diff| "
                         f"{float(np.max(np.abs(rebuilt - tissue))):.3g} mm^2)")
    annotated = np.minimum(nu[:, 1].astype(np.float64), tissue)[:, None]  # float32 binning noise only
    pixel_area = px[0] * px[1]
    record = {
        "status": "annotated",
        "feature": ANNOTATION_FEATURE,
        "rule": "annotated tissue = consensus_mask & reference_ribbon (union of the reference stain's HALO layers); "
                "unannotated tissue is unknown (mass 0 here), not negative evidence",
        "maps": str(maps_file),
        "layers": "all (union of HALO layers L1..L5-6)",
        "ribbon_area_mm2": float(ribbon.sum() * pixel_area),
        "ribbon_on_consensus_tissue_fraction": float((ribbon & mask).sum() / ribbon.sum()),
        "annotated_tissue_area_mm2": float(annotated.sum()),
        "tissue_area_mm2": float(tissue.sum()),
        "annotated_tissue_fraction": float(annotated.sum() / tissue.sum()),
        "particles_with_annotation": int((annotated[:, 0] > 0).sum()),
        "particles": int(len(annotated)),
        "mass_units": "mm^2 (QNP local frame)",
    }
    return annotated, record
