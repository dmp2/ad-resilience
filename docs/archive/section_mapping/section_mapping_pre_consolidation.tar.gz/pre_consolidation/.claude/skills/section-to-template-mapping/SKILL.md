---
name: section-to-template-mapping
description: Map 2-D tissue sections (QNP histology now, spatial-omics sections later) onto a 3-D template atlas such as AHRAv2. Covers the particle/image-varifold representation, locating each section's stacking coordinate, tie and prior rules, GPU scoring, and the hand-off to deformable xIV. Use when registering a new donor's sections to the atlas or estimating where sections sit in it.
---

# Section → template mapping

**Do no harm.** Add a parameter, feature, or decision only when the data justify it. Otherwise keep the simpler model and report a range. The defaults below were calibrated on one donor (H20.33.034 MTG); the numbers behind them are in [evidence.md](evidence.md).

## Representation defaults

| Choice | Default | Change only if |
|---|---|---|
| Features | **2 channels**: gray- and white-matter area (mm²) per particle. Atlas side: label tables (gray = labels that are neither white matter nor dropped); gray/white is the fixed `gmwm` projection of the canonical one-hot anatomical channels (STG/MTG/ITG gray, other gray, white; `nu_Anat`, [docs/qnp_atlas_anatomical_features.md](../../../docs/qnp_atlas_anatomical_features.md)). Choose dimensions and correspondence with the feature-matching policy below. | Stay with label/cluster features (user's scope). Add channels only as further labels or clusters, not as continuous fields such as cortical depth. |
| Roles | **Template (source, S) = atlas**: it is moved, π-mapped and censored. **Target (T) = the data section** (QNP, omics): it stays fixed and defines the support. Section ↔ section: target = the anchor. | Never swap them: the support censoring exists to protect incomplete data. |
| Score | Multi-scale Gaussian varifold distance, exp(−d²/2σ²) with SDs 2, 1, 0.5 mm, normalised by the target's self-term. | Particles are compressed to spacing h: drop SDs < h/2. |
| Support (censoring) | Template mass is weighted by the target's own density. Rigid scorer: SD 0.5 mm, saturating at 0.25 × median density, cutoff 10⁻³. xIV: min-max-normalised target density. In 2-D xmodmap this weight is **fixed, not learned** (λ is inert). | Never drop it. It censors **absent** tissue (block edges, holes, tears) but not **present-but-wrong** tissue (stripes, layer 1 read as white matter); handle those with feature QC (anchor/passenger roles) or per-particle target weights. |
| Compression | **Joint** (positions + masses, `particle_approximation.optimize_particles`, kernel exp(−d²/σ²), σ = max(1, h)). Compress once per section, then reuse. | — It costs 5–25 s per section, so it pays off only when the result is reused across searches. |
| Section particle count | Search **~200** (h 1.5 mm) → tie escalation **~450** (h 1.0) → final decisions at **full 500 µm** (~1,700). | Fewer than ~200 breaks the atlas plane ranking and biases it toward one candidate. |
| 3-D atlas → 2-D particles | Reslice the 0.5 mm label volume nearest-neighbour on `origin + a·u + b·v` (70 mm window). Sum 2×2 pixels into **1 mm particles** carrying class areas. | Native 0.5 mm particles changed nothing; use them only as confirmation. |
| Slab (fast pass) | Mean class fraction over parallel planes **±3 mm (6 mm thick, 3 mm stride)**. | Without a dissection prior, add tilted slab families: coronal slabs missed a ~21°-oblique candidate. |
| Sub-voxel depth | Snap the in-plane grid to voxel centres and interpolate class fractions linearly in depth only. | — Interpolation blurs the atlas, so report depth to voxel precision (0.5 mm). |
| Plane orientation | **Coronal (tilt 0)**, so the stacking coordinate is the plane's y. | Freeing tilt improves *every* anchor by more than δ at full resolution (it did not here). |
| In-plane transform | Similarity + flip, scale 0.8–1.5 (a nuisance term: shrinkage plus template size). Rigid for passengers. | A scale is supported by the tissue outline beyond δ (e.g. LFB ~5% larger). |
| Deformable (xIV) | Atlas source **uncompressed**; section target **full**. | — Compressing the source collapses the warp to near-rigid. A compressed target saves little time and was not reliably close. |
| xIV deformation model | **One stage, `transform: affine+diffeo`**, kernels RKHS 8/4/2 mm and varifold 8/4/2/1 mm, `c_nonrigid` 1, `gamma` 0.1, `dens_sigma_mm` 0.5 (variant H, the config default). Kernels are sized to a ~25 mm section with 5–10 mm gyri. | Staged fits (`model.stages`, e.g. rigid → affine+diffeo) show a gain on the same start and score. On the reference case, staging ended near-rigid. |
| Uninformative slices in xIV | Do not warp them on their own evidence. | If one must be mapped directly, use `transform: rigid` (or `affine` when a scale is supported). This is untested; prefer inheriting the anchor's map. |

## Feature-matching policy

π_ST ≥ 0 has shape **d_S × d_T**: each template channel is spread over target channels, and (μ_S π) is compared with ν_T. **d_S ≠ d_T is allowed** (atlas regions → omics cell types is xIV's standard use). Identity means π = I.

1. **Name the modality of each pair.** It is *single-modal* when both sides' channels measure the same quantity: same stain, or tissue occupancy. Then use identity.
2. **Cross-modal: pick the correspondence.**
   - **Identity after an a priori collapse** when the shared meaning is known: atlas labels → gray/white; stain colour → gray/white; cell types → gray/white. This is tested and is the default for rigid and plane search.
   - **Learned π** when it is not. **Required** for arbitrarily indexed channels (OD bins, per-stain clusters): identity failed there. At 2 → 2, learned π matched identity (same plane contrast, same best planes), so it is optional where a collapse exists.
3. **Mismatched dimensions are fine; unexplainable target channels are not free.** Target channels that vary where the template has no matching structure (e.g. laminar types against a gray/white atlas) leave residual that lowers search contrast. Atlas 2 → section K: contrast fell as K rose, but nothing failed outright.
   - For rich targets (omics), **enrich the template side** where possible (fine regions, cortical depth).
   - **Search on the collapsed features.** Use the rectangular π in xIV, then compare contrast, (median − best)/median, between the collapsed and full versions.
4. **QC every learned π for plausible structure:** near-diagonal for 2 → 2; oligodendrocyte types → white matter for omics.
5. **Record per pair:** modality, roles, d_S → d_T, identity or learned, and the fitted π.

## Procedure

1. **Feature QC → roles.** Make the gray/white map for each section and look at it. Mark a section as an **anchor** when the map is clean (Otsu separability ≳ 0.75; no scanner stripes, layer 1 not read as white matter, not a glial stain). Mark it a **passenger** otherwise, or when its depth profile in step 4 is flat.
2. **Compress** each section once (joint, h 1.5 mm).
3. **Fast pass: slabs.** Search coronal slabs along the region's AP range, one 2-D search per slab: FFT candidates over 15° rotations × scales {0.9, 1.05, 1.2, 1.35} × both flips, 1 mm raster, 1.5 mm blur, then refine the top 4 distinct candidates. Keep the top 3 distinct slabs plus the best prior-consistent one.
   - **Anatomical slab prior (opt-in, `--landmark-slab`).** A dissection landmark can restrict the AP range. For SEA-AD MTG, that landmark is the LGN's first appearance (AHRAv2 y −22.0), with 4 mm slabs of unknown phase, j ∈ {−1, 0, +1}, and ±1 mm. This gives y −13…−31. The profile then scans that whole interval.
   - Report the prior as a prior. Read `windows_at_prior_bound` before trusting a placement.
   - The prior constrains depth, not gyrus: H20.33.043 stayed on the insula inside it.
   - Gyrus admissibility comes from `--region-prior` (atlas support within 6 mm of MTG/STG/ITG). Keep ITG: STG/MTG-only support moved H20.33.034 off its candidate.
   - Always follow with `--stage candidates`. It re-scores the admissible and unconstrained bests on the uncropped atlas (data only) and reports whether the placement is image-supported or prior-driven. H20.33.043 is prior-driven (7–14 δ).
   - See `docs/qnp_landmark_slab_prior.md`.
4. **Depth profile per anchor.** Inside the kept slabs, step coronal planes 0.5 mm apart and run a **fresh global 2-D search at every depth**. The window is all depths within δ of the best.
5. **Escalate on ties, conditioned on the previous level.** Re-run only inside the window, adding the previous level's best pose as an extra start. Order: ~200 → ~450 → full section particles; atlas 1 mm → native as confirmation. **Stop when the window stops shrinking** and report it.
6. **Passengers.** Align each to an anchor rigidly on tissue outline (global search over all rotations and both flips; coarse particles, then refine at 500 µm). Add segmentation channels only where they fit their own slide (e.g. HALO cortex outlines). A passenger inherits the anchor's depth window.
7. **Stack.** Pairwise tissue-outline distances give a weak ordering. Per-slice spacing below the window width cannot be estimated from the atlas; say so. Test a shared tilt only after per-slice placement.
8. **Deformable xIV** at the chosen plane, run with `framework_script_AtlasToSectionCrossModalBoundary.py`.
   - **Inputs:** export the plane with `scan_atlas_planes_for_qnp.py --stage export`. Source and target are dense and already in the rigid-scan frame (`center_mode: shared_target`, start `r000_f0`).
   - **Atlas window:** the export crops the atlas to the section's footprint (`support_sigma_mm`). At 2 mm, the crop removes the atlas pia, so no fit can match pial surfaces. At 6 mm, the pia is kept. The support width (`dens_sigma_mm`) then trades pial match against compression; see "Pial correspondence" in `docs/software/xiv_lddmm_upstream.md`. Sulci absent from the population atlas cannot be matched.
   - **Gate:** run `--stage support-check` before `single`.
   - **Ties:** if candidate planes are still tied, fit each one with the identical model and compare them.
   - **Deformation model:** chosen by name. `model.transform` is one of `rigid`, `affine` (a similarity in 2-D), `diffeo`, `rigid+diffeo` or `affine+diffeo` (default). `model.stages` chains them, each from the previous end point.
   - xIV is a single-start local fit without flips. It refines a pose from steps 3–6 and never replaces that search.
9. **Check the xIV fit before using it.**
   - Rank and compare runs with `scores.json`: "tissue mismatch" and "gray/white mismatch" (0 = identical, 1 = no overlap). They use fixed scales and a fixed 0.5 mm section footprint, so they compare across models. Never use the native loss, whose normalisation changes per run.
   - **Judge the fit visually first.** Use `registration_t1.00.png` (upstream's source | target | deformed view; `_pi` = colours mapped through π_ST) and `qc_warp.png` (deformed atlas over the target, shaded by support). Scores rank fits that already look plausible; they cannot certify one.
   - Read the loss trajectory. "Local minimum reached" a few iterations after a large drop can be a float32 plateau, not convergence.
   - Check that π_ST is near-diagonal for gray/white, the mass-ratio p50 is in [0.5, 2], and the support-weighted area ratio is in [0.5, 2].
   - Watch the whole flow with `scripts/view_xiv_trajectory.py <init_dir>` (pyvista; time slider, target overlay and π_ST toggles; `--save DIR` to write images). Look for folding, tissue dragged into empty space, a warp that only translates, or a source left visibly larger or smaller than the target.
10. **Validate** with independent signals: where annotation ribbons land on the atlas region (a consistency check, not ground truth), and a second donor.

## Decision rules

- **δ (noise)**: the median, over anchors, of the across-anchor SD of each anchor's score relative to its own best. It was 0.018 on the reference donor; re-estimate it per case and per level.
- **Tie**: candidates within δ. Decide between distant candidates only at full resolution, never on compressed scores (compression biased the ranking).
- **Priors** (e.g. dissection region) are applied explicitly and reported as priors, not as image evidence.
- **Model changes** (tilt removed, scale fixed, new features): rerun the global search. Never warm-start from the old model's pose.
- **Never inherit a saved pose without checking both flips**: one stored stain-to-stain pose was mirrored and wrong.
- **HALO MTG supervision (xIV anatomical term), tested 2026-11-18 on both donors:**
  - It fixes the gyrus, not the depth. Atlas MTG spans the whole depth range, so R_anat is
    flat over depth.
  - Uncensored, under similarity, it shrinks the atlas (extreme scales, tissue outside the
    brain).
  - Do not use it to pick depth. Rank xIV candidates with the common QNP-frame score and
    report the scale filter. See `docs/qnp_stacking_xiv_anatomical.md`;
    `estimate_qnp_stacking_xiv.py` is the driver.
- **xIV precision: float32.** Float64 went past a float32 noise plateau (native loss 7.66 → 2.81) but looked no different in the registration figure, at ~20× the time. Model settings, not precision, limit fit quality. Do not rank fits on native-loss differences at the plateau scale.

## Compute

GPU first. xIV runs through the vendored bcharlier/xIV-LDDMM-Particle (`docs/software/xiv_lddmm_upstream.md`). One float32 dense fit takes ~2 min on the RTX 2080 SUPER. Float64 is ~20× slower per shooting pass, because GeForce FP64 runs at 1/32 rate. Search: use `preprocess/section_alignment_gpu.py`: `TorchFootprintScorer`, `search_gpu`, `search_planes_gpu` (many depths per batch, with `extra_starts` for conditioning), and `refine_batch`. It is ~25–40× faster per pose than the CPU path and matches it to 2×10⁻⁶. `preprocess/section_alignment.py` is the CPU reference implementation. Helpers: `scan_atlas_planes_for_qnp.py` (atlas setup, plane geometry, landing fractions), `align_qnp_multistain.py` (section ↔ section). There is no single driver for steps 3–5 in the repo yet.

## Report per section

Role (anchor or passenger), stacking coordinate with its window, the level that decided it, in-plane transform, score, landing fractions (QC only), and which priors were used. For xIV fits, also report the deformation model or stages, the dtype, `scores.json`, and how the optimisation stopped.

## Spatial omics (untested here)

The omics section is the target and keeps its cell-type channels (d_T = number of types). Search and stacking use the a priori gray/white collapse (oligodendrocyte share → white, neuronal share → gray) as an anchor check. Deformable xIV uses a rectangular π from atlas regions (and depth, if available) to cell types, QC'd for plausible structure.
